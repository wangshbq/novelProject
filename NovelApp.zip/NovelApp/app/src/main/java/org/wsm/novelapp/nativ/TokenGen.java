package org.wsm.novelapp.nativ;

import java.util.Date;
import java.util.Map;

public class TokenGen {


    static {
        System.loadLibrary("JwtGenJNI");
    }

    public static native Date getExpiration(String token);

    public static native Map<String,String> decodeBase64(String token);

}
