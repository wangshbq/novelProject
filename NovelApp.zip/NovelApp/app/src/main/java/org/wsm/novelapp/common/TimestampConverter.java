package org.wsm.novelapp.common;

import androidx.room.TypeConverter;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimestampConverter {
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    @TypeConverter
    public static Timestamp fromTimestamp(Long value) {
        return value == null ? null : new Timestamp(value);
    }

    @TypeConverter
    public static Long dateToTimestamp(Timestamp date) {
        return date == null ? null : date.getTime();
    }


    @TypeConverter
    public static Long fromDateString(String dateString) {
        if (dateString == null) {
            return null;
        }
        try {
            Date date = dateFormat.parse(dateString);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    @TypeConverter
    public static String toDateString(Long timestamp) {
        if (timestamp == null) {
            return null;
        }
        return dateFormat.format(new Date(timestamp));
    }
}