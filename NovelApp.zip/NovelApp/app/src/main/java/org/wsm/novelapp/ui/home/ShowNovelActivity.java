package org.wsm.novelapp.ui.home;

import static org.wsm.novelapp.common.Constants.FOLLOW;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.SAVE_DRAFT;
import static org.wsm.novelapp.common.Constants.THUMBS_UP_CLICK;
import static org.wsm.novelapp.common.Constants.VISIT_NOVEL;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Person;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.HomeEntryAdapter;
import org.wsm.novelapp.adapter.ShowNovelAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.ui.mine.create.WriteNovelActivity;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ShowNovelActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView rv_novel;
    private List<String> datas = new ArrayList<>();
    private NovelDto novelDto;
    private RequestUtil requestNovel;
    private Thread thread;
    private TextView tv_novel_comment_number;
    private TextView tv_novel_collect_number;
    private TextView tv_novel_thumb_number;
    private ImageView iv_thumb_icon;
    private ImageView iv_collect_icon;
    private ImageView iv_comment_icon;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private TextView tv_author_name;
    private Button btn_subscribe;
    //在HomeFragment中当前内容在datas的位置
    private Integer position;
    private Integer commentNumber;
    //作者的用户id
    private Integer authorUserId;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_novel);

        Toolbar tb_novel = findViewById(R.id.tb_novel);
        tb_novel.setNavigationOnClickListener(view -> {
            setReturnParams();
            finish();
        });

        // 创建 OnBackPressedCallback
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                setReturnParams();
                finish();
            }
        };

        // 将 callback 添加到 Activity 的 OnBackPressedDispatcher
        getOnBackPressedDispatcher().addCallback(this, callback);

        //评论数量
        tv_novel_comment_number = findViewById(R.id.tv_novel_comment_number);
        //收藏数量
        tv_novel_collect_number = findViewById(R.id.tv_novel_collect_number);
        //点赞数量
        tv_novel_thumb_number = findViewById(R.id.tv_novel_thumb_number);
        //点赞icon
        iv_thumb_icon = findViewById(R.id.iv_thumb_icon);
        //收藏icon
        iv_collect_icon = findViewById(R.id.iv_collect_icon);
        //评论icon
        iv_comment_icon = findViewById(R.id.iv_comment_icon);

        tv_author_name = findViewById(R.id.tv_author_name);
        //关注按钮
        btn_subscribe = findViewById(R.id.btn_subscribe);

        findViewById(R.id.ll_leap_person_center).setOnClickListener(this);

        btn_subscribe.setOnClickListener(this);
        iv_thumb_icon.setOnClickListener(this);

        iv_comment_icon.setOnClickListener(this);

        // 注册 ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        //发表过评论返回之后 增加评论数量
//                        int increaseComment = data.getIntExtra("increaseComment",0);

                        int commentNumber = data.getIntExtra("commentNumber", 0);
//                        ;
//                        String text = tv_comment_number.getText().toString();
                        runOnUiThread(() -> tv_novel_comment_number.setText(commentNumber + ""));
                    }
                }
        );

        // 获取传递过来的 NovelDto 对象
        Intent intent = getIntent();
        String novels = intent.getStringExtra("novels");
        String authorName = intent.getStringExtra("authorName");

        authorUserId = intent.getIntExtra("userId",0);
        commentNumber = intent.getIntExtra("commentNumber",0);
        Type novelsType = new TypeToken<NovelDto>() {}.getType();

        novelDto = GSON.fromJson(novels, novelsType);

        tv_author_name.setText(authorName);

        GlobalApplication application = (GlobalApplication) getApplication();

        Integer userId = application.getUser().getId();
        //判断关注按钮的展示
        if(novelDto.getUserId().equals(userId)){//用户点开自己的小说 不用展示
            btn_subscribe.setVisibility(View.GONE);
        }else if(novelDto.getIsSubscribe() == 1){
            btn_subscribe.setBackgroundResource(R.drawable.button_already_subscribe_rounded);
            btn_subscribe.setText("已关注");
        }


        //下拉刷新控件
        SwipeRefreshLayout sr_novel = findViewById(R.id.sr_novel);

        //下拉刷新
        sr_novel.setOnRefreshListener(this::refreshData);

        //列表展示控件
        rv_novel = findViewById(R.id.rv_novel);

        rv_novel.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,false));

        //适配器
        ShowNovelAdapter showNovelAdapter = new ShowNovelAdapter(this, datas);
        //控件绑定适配器
        rv_novel.setAdapter(showNovelAdapter);

        novelDataBind();

        //下拉刷新时请求
        requestNovel = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() != 1){
                    runOnUiThread(() -> Toast.makeText(ShowNovelActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }else{
                    Map<String, String> map = result.getData();
                    String novels = map.get("novelDto");
                    Type novelsType = new TypeToken<NovelDto>() {}.getType();

                    novelDto = GSON.fromJson(novels, novelsType);
                    novelDataBind();
                }

                try {
                    thread.join();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                //停止刷新动画
                sr_novel.setRefreshing(false);
            }
        });


    }

    public void refreshData(){
        datas.clear();
        Map<String, String> map = new HashMap<>();
        map.put("novelId",novelDto.getId() + "");

        thread = new Thread(() -> requestNovel.GetRequest(map, VISIT_NOVEL));

        thread.start();
    }

    @SuppressLint("SetTextI18n")
    public void novelDataBind(){
        if (novelDto != null) {
            datas.add(novelDto.getTitle());
            datas.add(EncryptUtils.AESDecode(novelDto.getContent()));

            runOnUiThread(() -> {
                tv_novel_comment_number.setText(commentNumber + "");
                tv_novel_collect_number.setText(novelDto.getCollect() + "");
                tv_novel_thumb_number.setText(novelDto.getThumbsUp() + "");
            });

            if(novelDto.getIsThumbsUp() == 1){
                iv_thumb_icon.setImageResource(R.drawable.baseline_thumb_up_alt_35);
            }


        }else{
            Log.d("============>","null");
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.iv_thumb_icon && novelDto.getIsThumbsUp() == 0){//点击点赞

            new Thread(() -> {
                GlobalApplication application = (GlobalApplication) getApplication();
                Integer userId = application.getUser().getId();

                Map<String, String> map = new HashMap<>();
                map.put("userId",userId + "");
                map.put("novelId",novelDto.getId() + "");

                new RequestUtil(this, new RequestUtil.ResponseListen() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void handleResponse(Result result) throws IOException {

                        if(result.getCode() == 1){
                            novelDto.setIsThumbsUp(1);
                            iv_thumb_icon.setImageResource(R.drawable.baseline_thumb_up_alt_35);

                            int thumbsUp = novelDto.getThumbsUp();

                            runOnUiThread(() -> tv_novel_thumb_number.setText((thumbsUp + 1) + ""));

                            novelDto.setThumbsUp(thumbsUp + 1);
                        }else{
                            runOnUiThread(() -> Toast.makeText(ShowNovelActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                        }
                    }
                }).GetRequest(map,THUMBS_UP_CLICK);

            }).start();

        }else if(id == R.id.iv_comment_icon){//点击评论
            Intent intent = new Intent(this, CommentActivity.class);
            intent.putExtra("novelId",novelDto.getId() + "");
            intent.putExtra("commentNumber",tv_novel_comment_number.getText().toString());
            activityResultLauncher.launch(intent);

        }else if(id == R.id.btn_subscribe){//点击关注  或 取消关注


            GlobalApplication application = (GlobalApplication) getApplication();
            Integer userId = application.getUser().getId();
            SharedPreferences preferences = getSharedPreferences("userData:" + userId, MODE_PRIVATE);

            String subscribeText = preferences.getString("subscribeText", null);
            String targetUserId = String.valueOf(novelDto.getUserId());

            if(subscribeText == null || !subscribeText.contains(targetUserId)){//关注
                follow();
            }else{//取消关注
                runOnUiThread(this::showDialog);
            }
        }else if(id == R.id.ll_leap_person_center){
            //跳转到对应用户的个人中心
            Intent intent = new Intent(this, PersonCenterActivity.class);
            intent.putExtra("authorUserId",authorUserId);
            intent.putExtra("authorName",tv_author_name.getText().toString());
            startActivity(intent);

        }
    }

    private void setReturnParams(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra("commentNumber", tv_novel_comment_number.getText().toString());
        setResult(RESULT_OK, resultIntent);
    }

    private void follow(){
        new Thread(() -> {
            String targetUserId = String.valueOf(novelDto.getUserId());
            Map<String, String> map = new HashMap<>();
            map.put("targetUserId",targetUserId);

            new RequestUtil(this, new RequestUtil.ResponseListen() {
                @SuppressLint("CommitPrefEdits")
                @Override
                public void handleResponse(Result result) throws IOException {

                    if(result.getCode() == 1){
                        Log.d("===handleResponse","1");
                        GlobalApplication application = (GlobalApplication) getApplication();
                        Integer userId = application.getUser().getId();
                        SharedPreferences preferences = getSharedPreferences("userData:" + userId, MODE_PRIVATE);

                        String subscribeText = preferences.getString("subscribeText", null);
                        int subscribeNumber = preferences.getInt("subscribeNumber", 0);

                        SharedPreferences.Editor edit = preferences.edit();

                        //设置关注数量加1
                        subscribeNumber++;

                        edit.putInt("subscribeNumber",subscribeNumber);

                        //设置新关注的用户
                        if(subscribeText == null || subscribeNumber == 1)
                            subscribeText = targetUserId;
                        else
                            subscribeText +=  "," + targetUserId;


                        edit.putString("subscribeText",subscribeText);

                        runOnUiThread(() -> {
                            btn_subscribe.setBackgroundResource(R.drawable.button_already_subscribe_rounded);
                            btn_subscribe.setText("已关注");
                        });
                        edit.apply();

                    }else{
                        Log.d("===handleResponse","0");
                        Toast.makeText(ShowNovelActivity.this,"异常",Toast.LENGTH_SHORT).show();
                    }
                }
            }).GetRequest(map,FOLLOW);
        }).start();


    }


    private void cancelFollow(){
        new Thread(() -> {
            String targetUserId = String.valueOf(novelDto.getUserId());
            Map<String, String> map = new HashMap<>();
            map.put("targetUserId",targetUserId);

            new RequestUtil(this, new RequestUtil.ResponseListen() {
                @SuppressLint("CommitPrefEdits")
                @Override
                public void handleResponse(Result result) throws IOException {

                    if(result.getCode() == 1){
                        GlobalApplication application = (GlobalApplication) getApplication();
                        Integer userId = application.getUser().getId();
                        SharedPreferences preferences = getSharedPreferences("userData:" + userId, MODE_PRIVATE);

                        String subscribeText = preferences.getString("subscribeText", "");
                        int subscribeNumber = preferences.getInt("subscribeNumber", 0);
                        SharedPreferences.Editor edit = preferences.edit();

                        StringBuilder stringBuilder = new StringBuilder();
                        String[] split = subscribeText.split(",");
                        for(String s: split){
                            if(!s.equals(targetUserId)){
                                stringBuilder.append(s).append(",");
                            }
                        }
                        if(stringBuilder.length() > 0)
                            stringBuilder.deleteCharAt(stringBuilder.length()-1);

                        edit.putString("subscribeText",stringBuilder.toString());

                        subscribeNumber--;

                        edit.putInt("subscribeNumber",subscribeNumber);
                        edit.apply();

                        btn_subscribe.setBackgroundResource(R.drawable.button_subscribe_rounded);
                        btn_subscribe.setText("关注");

                    }else{
                        Toast.makeText(ShowNovelActivity.this,"异常",Toast.LENGTH_SHORT).show();
                    }
                }
            }).GetRequest(map,FOLLOW);
        }).start();
    }



    private void showDialog() {


        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("提示");

        builder.setMessage("取消关注?");


        builder.setNegativeButton("确定取关", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                cancelFollow();
            }
        });

        builder.setPositiveButton("继续关注", new DialogInterface.OnClickListener() {
            @SuppressLint("CommitPrefEdits")
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}