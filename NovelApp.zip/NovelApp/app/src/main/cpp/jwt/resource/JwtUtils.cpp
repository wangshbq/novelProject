#include "JwtUtils.h"

#include <Base64.h>
#include <chrono>
#include <iostream>
#include <sstream>
// URL 解码函数
std::string urlDecode(const std::string& str) {
    std::ostringstream unescaped;
    for (size_t i = 0; i < str.size(); ++i) {
        if (str[i] == '%' && i + 2 < str.size()) {
            int hexValue;
            std::istringstream hexStream(str.substr(i + 1, 2));
            if (hexStream >> std::hex >> hexValue) {
                unescaped << static_cast<char>(hexValue);
                i += 2;
            } else {
                unescaped << str[i];
            }
        }else {
            unescaped << str[i];
        }
    }
    return unescaped.str();
}

// 解析 claims
std::map<std::string, std::string> parseClaims(const std::string& claimsString) {
    std::map<std::string, std::string> claims;
    std::istringstream iss(claimsString);
    std::string token;
    while (std::getline(iss, token, '&')) {
        size_t pos = token.find('=');
        if (pos != std::string::npos) {
            std::string key = token.substr(0, pos);
            std::string value = token.substr(pos + 1);
            claims[key] = value;
        }
    }
    return claims;
}
std::map<std::string, std::string> getClaims(const std::string& token){
    std::string aes_text;

    for(int i = 0;i < token.length();i++){
        if(token[i] == '|'){
            aes_text = urlDecode(token.substr(0,i));
        }
    }

    return parseClaims(aes_text);
}







std::string encode_base64(const std::string& text){
    return Base64::encode(std::vector<uint8_t>(text.begin(),text.end()));
}

std::map<std::string, std::string> decode_base64(const std::string& text){
    size_t pos = text.find('|');
    std::vector<uint8_t> decode_text = Base64::decode(text.substr(0,pos));
    
    std::string str(decode_text.begin(),decode_text.end());
    
    return parseClaims(urlDecode(str));
}