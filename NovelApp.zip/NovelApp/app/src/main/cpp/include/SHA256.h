#ifndef SHA256_H
#define SHA256_H

#include <cstdint>
#include <cstddef>
#include <array>

class SHA256 {
public:
    static const size_t BLOCK_SIZE = 64;  // 64 bytes = 512 bits
    static const size_t HASH_SIZE = 32;   // 32 bytes = 256 bits

    SHA256();
    void update(const uint8_t* data, size_t len);
    void final(uint8_t hash[HASH_SIZE]);
    void reset();

private:
    void transform(const uint8_t data[BLOCK_SIZE]);

    uint8_t data[BLOCK_SIZE];  // current 512-bit chunk of message data
    uint32_t datalen;          // data length of current chunk
    uint64_t bitlen;           // total bit length of the message
    uint32_t state[8];         // intermediate hash state

    static const uint32_t K[64];  // SHA-256 constants
};

#endif // SHA256_H