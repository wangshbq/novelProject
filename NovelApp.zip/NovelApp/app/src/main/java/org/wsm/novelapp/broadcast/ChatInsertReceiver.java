package org.wsm.novelapp.broadcast;

import static androidx.core.content.ContextCompat.getSystemService;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.service.SocketService.CONNECTION;
import static org.wsm.novelapp.service.SocketService.NOTIFICATION;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.ChatAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.dao.ChatDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.service.SocketService;
import org.wsm.novelapp.ui.mine.subscribe.ChatActivity;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.List;

public class ChatInsertReceiver extends BroadcastReceiver {

    @SuppressLint("WrongConstant")
    @Override
    public void onReceive(Context context, Intent intent) {
        String chatStr = intent.getStringExtra("chat");

        Type type = new TypeToken<Chat>() {}.getType();

        Chat chat = GSON.fromJson(chatStr, type);

        if(chat == null) return;
        //设置为接收消息的用户
        chat.setSend(false);

        //将消息内容加密
        chat.setContent(EncryptUtils.AESEncode(chat.getContent()));

        AppDatabase instance = AppDatabase.getInstance(context);

        ChatDao chatDao = instance.chatDao();
        //将接收到的聊天记录存储在sqllite
        new Thread(() -> {
            chatDao.insert(chat);
        }).start();

        //判断是否需要提示用户
        Log.d("===>chat", chat.toString());
        GlobalApplication application = GlobalApplication.getInstance();
        //判断是否在ChatActivity
        if(!application.isChatActivity()){
            Intent socketServiceIntent = new Intent(context, SocketService.class);
            socketServiceIntent.putExtra("action",NOTIFICATION);
            socketServiceIntent.putExtra("chat",chatStr);
            context.startService(socketServiceIntent);
        }
    }

}
