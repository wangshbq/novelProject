package org.wsm.novelapp.broadcast;

import static org.wsm.novelapp.common.Constants.GSON;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.adapter.ChatAdapter;
import org.wsm.novelapp.bean.Chat;

import java.lang.reflect.Type;
import java.util.List;

public class ChatBroadcastReceiver extends BroadcastReceiver {

    private List<Chat> datas;
    private ChatAdapter chatAdapter;
    private RecyclerView rv_chat;
    public ChatBroadcastReceiver(List<Chat> datas, ChatAdapter chatAdapter,RecyclerView rv_chat) {
        this.datas = datas;
        this.chatAdapter = chatAdapter;
        this.rv_chat = rv_chat;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String chatStr = intent.getStringExtra("chat");

        Log.d("====>chatStr", chatStr == null ? "null" : chatStr);
        Type type = new TypeToken<Chat>() {}.getType();
        Chat chat = GSON.fromJson(chatStr, type);
        //设置为接收消息的用户
        if(chat != null) chat.setSend(false);

        datas.add(0,chat);
        //更新界面 显示给用户
        ((Activity)context).runOnUiThread(() -> {
            chatAdapter.notifyItemInserted(0);
            rv_chat.smoothScrollToPosition(0);
            rv_chat.scrollToPosition(0);
        });

        Log.d("======chat", chat == null ? "null" : chat.toString());
    }
}
