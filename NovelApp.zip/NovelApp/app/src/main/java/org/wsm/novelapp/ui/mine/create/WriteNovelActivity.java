package org.wsm.novelapp.ui.mine.create;

import static org.wsm.novelapp.common.Constants.EDIT_NOVEL;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.SAVE_DRAFT;
import static org.wsm.novelapp.common.Constants.SAVE_NOVEL;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.ContentManagerAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.ContentManagerBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dao.NovelDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

public class WriteNovelActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<TextView> tvSigns = new ArrayList<>();
    //草稿展示的数据
    public ArrayList<ContentManagerBean> datas = new ArrayList<>();
    private BottomSheetDialog bottomSheetDialog;
    private View bottomView;
    private Button btn_write_novel_add_sign;
    private EditText et_write_novel_content;
    private TextView tv_write_novel_word;
    private EditText et_write_novel_title;
    //判断用户退出时是否需要弹出框
    private boolean isShowDialog = false;
    private NovelDao novelDao;

    private long lastLoadTime = 0; // 记录上次加载的时间
    private static final long LOAD_THRESHOLD = 1000; // 1秒内只加载一次
    private ContentManagerAdapter contentManagerAdapter;
    private BottomSheetDialog draftDialog;
    //打开草稿的时候展示的当前页
    int currentPage = 1;
    //判断是否草稿还有数据
    boolean isDraftData = true;
    //从哪个界面跳过来的
    private String intentFrom;
    private int novelId;
    private int status;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_novel);

        Toolbar tb_create_center_head = findViewById(R.id.tb_write_novel_head);

        btn_write_novel_add_sign = findViewById(R.id.btn_write_novel_add_sign);
        btn_write_novel_add_sign.setOnClickListener(this);
        TextView btn_write_novel_publish = findViewById(R.id.btn_write_novel_publish);
        btn_write_novel_publish.setOnClickListener(this);
        //小说内容
        et_write_novel_content = findViewById(R.id.et_write_novel_content);
        tv_write_novel_word = findViewById(R.id.tv_write_novel_word);
        et_write_novel_title = findViewById(R.id.et_write_novel_title);
        //sqllite
        AppDatabase instance = AppDatabase.getInstance(this);
        novelDao = instance.novelDao();

        // 获取传递过来的 Intent
        Intent intent = getIntent();

        // 接收参数
        intentFrom = intent.getStringExtra("intentFrom");

        if(Objects.requireNonNull(intentFrom).equals("ContentManagerActivity")){

            btn_write_novel_publish.setText("修改");

            novelId = intent.getIntExtra("novelId", 0);

            status = intent.getIntExtra("status",-1);

            AtomicReference<NovelDto> novelDto = new AtomicReference<>();

            Thread thread = new Thread(() -> novelDto.set(novelDao.queryById(novelId)));

            thread.start();

            try {
                thread.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            String content = novelDto.get().getContent();

            et_write_novel_content.setText(content);
            tv_write_novel_word.setText(content.length() + "");
            et_write_novel_title.setText(novelDto.get().getTitle());

            String signStr = novelDto.get().getSigns();


            //如果有标签则恢复标签位置
            if(signStr != null && !signStr.isEmpty()){
                //创建底部弹出框
                handleBottomSheetDialog();

                LinearLayout ll_bottom_sign_text = bottomView.findViewById(R.id.ll_bottom_sign_text);

                String[] signs = signStr.split(",");
                //恢复底部弹窗的默认标签
                resumeDefaultSigns(ll_bottom_sign_text,signs);

                LinearLayout ll_define_sign = bottomView.findViewById(R.id.ll_define_sign);
                //恢复底部弹窗的自定义标签
                int j = 0;
                for(int i = 0;i < ll_define_sign.getChildCount();i++){
                    TextView childAt = (TextView)ll_define_sign.getChildAt(i);

                    for(;j < signs.length; j++){
                        String sign = signs[j];
                        if(!sign.isEmpty()){
                            tvSigns.add(childAt);
                            childAt.setText(sign);
                            childAt.setOnClickListener(this);
                            j++;
                            break;
                        }
                    }
                }
            }

            btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
        }



        // 监听小说内容输入框
        et_write_novel_content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {}
            @SuppressLint("SetTextI18n")
            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {

                // 在文本改变时调用
                int length = charSequence.length();
                tv_write_novel_word.setText(length + "");

                if(length == 0){
                    isShowDialog = false;
                }else if(!isShowDialog){
                    isShowDialog = true;
                }

            }
            @Override
            public void afterTextChanged(Editable editable) {}
        });

        tb_create_center_head.setNavigationOnClickListener(view -> {
            if(Objects.requireNonNull(intentFrom).equals("ContentManagerActivity") || !isShowDialog)
                finish();
            else
                showDialog();
        });



    }
    @SuppressLint({"ResourceType", "SetTextI18n"})
    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.btn_write_novel_publish){//发布

            String content = et_write_novel_content.getText().toString();
            String title = et_write_novel_title.getText().toString();
            //判断不能为空
            if(content.isEmpty()){
                Toast.makeText(this,"内容不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            if(title.isEmpty()){
                Toast.makeText(this,"标题不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            //标签至少一个
            if(tvSigns.isEmpty()){
                Toast.makeText(this,"至少添加一个标签",Toast.LENGTH_SHORT).show();
                return;
            }

            //准备获取userId
            GlobalApplication application = (GlobalApplication) getApplication();
            User user = application.getUser();

            //填充数据
            NovelDto novel = new NovelDto();
            novel.setContent(content);
            novel.setTitle(title);

            novel.setCreateTime(new Timestamp(System.currentTimeMillis()));

            novel.setSigns(getSignsStr());


            novel.setUserId(user.getId());

            if(Objects.requireNonNull(intentFrom).equals("ContentManagerActivity")){//编辑
                novel.setId(novelId);
                novel.setStatus(status);
                //更新数据
                Thread thread = new Thread(() -> {

                    String string = GSON.toJson(novel);

                    new RequestUtil(this, new RequestUtil.ResponseListen() {
                        @Override
                        public void handleResponse(Result result) throws IOException {
                            runOnUiThread(() -> Toast.makeText(WriteNovelActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());

                            if(result.getCode() == 1){
                                novelDao.update(novel);
                            }
                        }
                    }).PostRequest(string, EDIT_NOVEL);

                });
                thread.start();

                try {
                    thread.join();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
                finish();

            }else{
                novel.setStatus(1);
                novel.setId(0);
                //插入数据
                new Thread(() -> {

                    String string = GSON.toJson(novel);

                    new RequestUtil(this, new RequestUtil.ResponseListen() {
                        @Override
                        public void handleResponse(Result result) throws IOException {
                            runOnUiThread(() -> Toast.makeText(WriteNovelActivity.this,result.getMsg(),Toast.LENGTH_SHORT).show());
                            if(result.getCode() == 1){
                                novelDao.insert(novel);
                                Map<String, String> data = result.getData();
                                String idStr = data.get("id");
                                if(idStr != null && !idStr.isEmpty()){
                                    int id = Integer.parseInt(idStr);
                                    novelDao.updateIdByZeroId(id);
                                }

                            }
                        }
                    }).PostRequest(string,SAVE_NOVEL);

                }).start();
                et_write_novel_content.setText("");
                et_write_novel_title.setText("");
                //清掉标签
                for(TextView textView: tvSigns){
                    View parent = (View)textView.getParent();
                    int parentId = parent.getId();

                    View parent2 = (View)parent.getParent();
                    int parentId2 = parent2.getId();

                    if(parentId2 == R.id.ll_bottom_sign_text) {//恢复默认存在的标签
                        int color = ContextCompat.getColor(this, R.color.middle_gray);
                        textView.setTextColor(color);
                    }else if(parentId == R.id.ll_define_sign){//恢复自定义添加的标签
                        textView.setText("");
                    }
                }
                tvSigns.clear();
                btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
            }



        }else if(id == R.id.btn_write_novel_add_sign){//添加标签
            showBottomSheetDialog();
        }else if(id == R.id.btn_add_sign){//添加自定义标签的按钮
            EditText et_input_sign = bottomView.findViewById(R.id.et_input_sign);
            String inputSign = et_input_sign.getText().toString();

            if(inputSign.isEmpty()){
                Toast.makeText(this,"不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            if(tvSigns.size() >= 5){
                Toast.makeText(this,"最多5个标签",Toast.LENGTH_SHORT).show();
                return;
            }

            if(inputSign.length() >= 5){
                Toast.makeText(this,"最多5个字",Toast.LENGTH_SHORT).show();
                return;
            }
            LinearLayout ll_define_sign = bottomView.findViewById(R.id.ll_define_sign);
            //遍历自定义标签
            for(int i = 0;i < ll_define_sign.getChildCount();i++){
                TextView childAt = (TextView)ll_define_sign.getChildAt(i);
                if(childAt.getText().toString().isEmpty()){
                    childAt.setText(inputSign);
                    //将标签添加到字符串
                    tvSigns.add(childAt);
                    btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
                    et_input_sign.setText("");
                    //当使用到此TextView直接监听
                    childAt.setOnClickListener(this);
                    break;
                }
            }

        }else{// bottom点击的标签
            View parent = (View) v.getParent();
            int parentId = parent.getId();

            View parent2 = (View)parent.getParent();
            int parentId2 = parent2.getId();

            if(parentId2 == R.id.ll_bottom_sign_text){//默认存在的标签

                TextView textView = (TextView) v;
                String text = textView.getText().toString();
                //判断曾经是否点过
                for(int i = 0;i < tvSigns.size();i++){
                    TextView textView1 = tvSigns.get(i);
                    //如果点过则恢复颜色
                    if(textView1.getText().toString().equals(text)){
                        int middle_gray = ContextCompat.getColor(this,R.color.middle_gray);
                        textView1.setTextColor(middle_gray);
                        tvSigns.remove(i);
                        btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
                        return;
                    }
                }
                if(tvSigns.size() >= 5){
                    Toast.makeText(this,"最多5个",Toast.LENGTH_SHORT).show();
                    return;
                }
                tvSigns.add(textView);
                btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
                int color = ContextCompat.getColor(this, R.color.fluorescent_green);
                textView.setTextColor(color);
            }else if(parentId == R.id.ll_define_sign){//取消自定义的标签
                ViewGroup parent1 = (ViewGroup)parent;

                TextView current = (TextView) v;
                tvSigns.remove(current);
                btn_write_novel_add_sign.setText("标签 " + tvSigns.size() +"/5");
                boolean b = true;
                TextView childAt = null;
                for(int i = 0;i < parent1.getChildCount();i++){
                    childAt = (TextView)parent1.getChildAt(i);
                    if(b && !childAt.getText().toString().equals(current.getText().toString())) continue;

                    if(b){
                        b = false;
                        continue;
                    }

                    ((TextView) parent1.getChildAt(i-1)).setText(childAt.getText());

                }
                Objects.requireNonNull(childAt).setText("");

            }

        }
    }

    @SuppressLint({"MissingInflatedId", "InflateParams"})
    private void showBottomSheetDialog() {

        if(bottomSheetDialog != null){
            bottomSheetDialog.show();
            return;
        }
        handleBottomSheetDialog();

        // 显示弹窗
        bottomSheetDialog.show();
    }

    private void handleBottomSheetDialog(){
        // 创建 BottomSheetDialog
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomView = getLayoutInflater().inflate(R.layout.bottom_dialog_add_sign, null);
        bottomSheetDialog.setContentView(bottomView);

        LinearLayout ll_bottom_sign_text = bottomView.findViewById(R.id.ll_bottom_sign_text);
        listenLL(ll_bottom_sign_text);
        //自定义添加标签按钮
        bottomView.findViewById(R.id.btn_add_sign).setOnClickListener(this);
    }

    /**
     * 监听parent下的TextView
     * @param parent
     */
    public void listenLL(ViewGroup parent) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof TextView) {
                child.setOnClickListener(this);
            } else if (child instanceof ViewGroup) {
                // 如果是 ViewGroup，递归遍历子控件
                listenLL((ViewGroup) child);
            }
        }
    }


    public void resumeDefaultSigns(ViewGroup parent,String[] signs) {
        for (int i = 0; i < parent.getChildCount(); i++) {
            View child = parent.getChildAt(i);
            if (child instanceof TextView) {
                TextView child1 = (TextView) child;

                for (int j = 0;j < signs.length;j++){
                    Log.d("========getText", child1.getText().toString());
                    if(signs[j].equals(child1.getText().toString())){
                        Log.d("========signs", "signs");
                        tvSigns.add(child1);
                        int color = ContextCompat.getColor(this, R.color.fluorescent_green);
                        child1.setTextColor(color);
                        signs[j] = "";
                    }
                }

            } else if (child instanceof ViewGroup) {
                // 如果是 ViewGroup，递归遍历子控件
                resumeDefaultSigns((ViewGroup) child,signs);
            }
        }
    }


    public void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("提示");

        builder.setMessage("退出后编辑的内容会保存到草稿");

        builder.setNegativeButton("继续编辑", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        builder.setPositiveButton("保存退出", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                GlobalApplication application = (GlobalApplication) getApplication();
                User user = application.getUser();

                String content = et_write_novel_content.getText().toString();
                String title = et_write_novel_title.getText().toString();
                NovelDto novel = new NovelDto();
                novel.setContent(content);
                novel.setTitle(title);
                novel.setStatus(0);
                novel.setCreateTime(new Timestamp(System.currentTimeMillis()));
                novel.setUserId(user.getId());
                novel.setSigns(getSignsStr());
                novel.setId(0);
                new Thread(() -> {
                    novelDao.insert(novel);

                    String string = GSON.toJson(novel);
                    new RequestUtil(WriteNovelActivity.this, new RequestUtil.ResponseListen() {
                        @Override
                        public void handleResponse(Result result) throws IOException {
                            if(result.getCode() != 1){
                                runOnUiThread(() -> Toast.makeText(WriteNovelActivity.this,result.getMsg(),Toast.LENGTH_SHORT).show());
                            }else{
                                Map<String, String> data = result.getData();
                                String idStr = data.get("id");
                                if(idStr != null && !idStr.isEmpty()){
                                    int id = Integer.parseInt(idStr);
                                    novelDao.updateIdByZeroId(id);
                                }
                            }
                        }
                    }).PostRequest(string,SAVE_DRAFT);

                }).start();

                finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /**
     * 通过tvSigns生成标签的字符串
     * @return
     */
    private String getSignsStr(){
        //生成标签字符串
        StringBuilder signs = new StringBuilder();
        for(TextView textView: tvSigns){
            signs.append(textView.getText().toString()).append(",");
        }
        //删除最后一个逗号
        if (signs.length() > 0) {
            signs.deleteCharAt(signs.length() - 1);
        }
        return signs.toString();
    }
}