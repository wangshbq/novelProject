package org.wsm.novelapp.dto;


import org.wsm.novelapp.bean.Comment;

import java.io.Serializable;
import java.sql.Timestamp;

public class CommentDto extends Comment implements Serializable {

    private String username;

    private Integer thumbsUp;
    private Integer commentNumber;
    //二级评论数量
    private Integer secondCommentNumber;
    private Integer isThumbsUp;
    private float commentHot;
    public CommentDto(){

    }

    public Integer getCommentNumber() {
        return commentNumber;
    }

    public void setCommentNumber(Integer commentNumber) {
        this.commentNumber = commentNumber;
    }

    public float getCommentHot() {
        return commentHot;
    }

    public void setCommentHot(Integer commentHot) {
        this.commentHot = commentHot;
    }

    public Integer getSecondCommentNumber() {
        return secondCommentNumber;
    }

    public void setSecondCommentNumber(Integer secondCommentNumber) {
        this.secondCommentNumber = secondCommentNumber;
    }

    public Integer getThumbsUp() {
        return thumbsUp;
    }

    public void setThumbsUp(Integer thumbsUp) {
        this.thumbsUp = thumbsUp;
    }


    public Integer getIsThumbsUp() {
        return isThumbsUp;
    }

    public void setIsThumbsUp(Integer isThumbsUp) {
        this.isThumbsUp = isThumbsUp;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "CommentDto{" +
                "username='" + username + '\'' +
                ", thumbsUp=" + thumbsUp +
                ", commentNumber=" + commentNumber +
                ", secondCommentNumber=" + secondCommentNumber +
                ", isThumbsUp=" + isThumbsUp +
                ", commentHot=" + commentHot +
                '}';
    }
}
