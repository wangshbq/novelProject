package org.wsm.novelapp.common;


import java.util.HashMap;
import java.util.Map;


public class Result {

    private Integer code; //编码：1成功，0和其它数字为失败

    private String msg; //错误信息

    private Map<String,String> data; //数据

    private Map<Object,Object> map = new HashMap<>(); //动态数据

    public static  Result success(Map<String,String> data,String msg) {
        Result result = new Result();

        result.msg = msg;
        result.data = data;
        result.code = 1;
        return result;
    }

    public static Result error(String msg) {
        Result result = new Result();
        result.msg = msg;
        result.code = 0;
        return result;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Map<String, String> getData() {
        return data;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    public Map<Object, Object> getMap() {
        return map;
    }

    public void setMap(Map<Object, Object> map) {
        this.map = map;
    }

    @Override
    public String toString() {
        return "Result{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                ", map=" + map +
                '}';
    }
}
