package org.wsm.novelapp.bean;

import java.sql.Timestamp;
import java.util.Date;


public class HomeEntryBean {

    private Integer userId;
    private Integer novelId;
    private String title;
    private String content;
    private String authorName;
    private Integer commentNumber;
    //浏览量
    private Integer pageViews;
    private Date time;

    public HomeEntryBean() {
    }

    public HomeEntryBean(Integer novelId, String title, String content, String authorName, Integer commentNumber, Integer pageViews, Date time) {
        this.novelId = novelId;
        this.title = title;
        this.content = content;
        this.authorName = authorName;
        this.commentNumber = commentNumber;
        this.pageViews = pageViews;
        this.time = time;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getNovelId() {
        return novelId;
    }

    public void setNovelId(Integer novelId) {
        this.novelId = novelId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public Integer getCommentNumber() {
        return commentNumber;
    }

    public void setCommentNumber(Integer commentNumber) {
        this.commentNumber = commentNumber;
    }

    public Integer getPageViews() {
        return pageViews;
    }

    public void setPageViews(Integer pageViews) {
        this.pageViews = pageViews;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
