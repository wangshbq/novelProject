package org.wsm.novelapp.service;

import static org.wsm.novelapp.common.Constants.GSON;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.common.Constants;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.ui.mine.subscribe.ChatActivity;

import java.lang.reflect.Type;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * 登录之后 => 调用SocketService连接socket => 初始化属性 并调用connect => 将userId发送给服务器
 *
 * 接收到消息 => 如果是1发送的信息 => 广播到chat_broadcast_receiver => 两个关播接收器接收
 * => ChatInsertReceiver 将消息插入sqllite 并且通知用户
 * => ChatBroadcastReceive 如果在chatActivity就会创建 将数据插入datas 让用户看到
 */
public class SocketService extends Service {
    //建立socket连接
    public static final int CONNECTION = 0;
    //关闭socket连接
    public static final int CLOSE_CONNECTION = 1;
    //发送消息
    public static final int SEND_MESSAGE = 2;
    //发送通知
    public static final int NOTIFICATION = 3;

    public static boolean isSocket = false;//进入界面是否有必要连接socket
    private OkHttpClient client;
    private int retryCount = 0;
    private boolean shouldReconnect = true;

    private volatile WebSocket webSocket;

    private final AtomicBoolean socketIsNull = new AtomicBoolean(true);

    Handler handler; // 主线程Handler

    private int reConCount = 5;

    @SuppressLint("ForegroundServiceType")
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("====>", "onCreate: SocketUtil");
        client = new OkHttpClient.Builder()
                .retryOnConnectionFailure(true) // 初始连接重试
                .pingInterval(30, TimeUnit.SECONDS) // 心跳
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.SECONDS) // WebSocket无读超时
                .build();

        handler = new Handler(Looper.getMainLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what == 0){ //重新连接
                    Log.d("===>thread", Thread.currentThread().toString());
                    connect();
                }
            }
        };

//        startForeground(NOTIFICATION_ID, createNotification());

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int action = intent.getIntExtra("action", -1);
        if(action == CONNECTION){//建立socket连接
            connect();
        }else if(action == CLOSE_CONNECTION){//关闭连接
            webSocket.close(1000, "User initiated closure");
        }else if(action == SEND_MESSAGE){//发送消息
            String message = intent.getStringExtra("message");

            if(message != null) {
                if(webSocket != null){
                    webSocket.send(message);
                }else{
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if(webSocket != null){
                                reConCount = 5;

                                webSocket.send(message);
                            }else{//socket为null 可能是用户刚进app未重连
                                if(reConCount-- > 0){ //最多重连5次
                                    //延迟3秒再尝试发送消息
                                    handler.postDelayed(this, 3000);
                                }else{
                                    Toast.makeText(SocketService.this,
                                            " 消息发送失败",Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }, 3000);
                }

            }
        }else if (action == NOTIFICATION){//发送通知
            send_notification(intent);
        }
        return START_NOT_STICKY;
    }

    private void send_notification(Intent intent){
        String chatStr = intent.getStringExtra("chat");

        Type type = new TypeToken<Chat>() {}.getType();

        Chat chat = GSON.fromJson(chatStr, type);

        if(chat == null) return;

        Intent chatIntent = new Intent(this, ChatActivity.class);

        chatIntent.putExtra("userName", chat.getUserName());

        chatIntent.putExtra("userId", chat.getUserId());
        // 启动Activity或其他操作
        chatIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // 转换为 PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,  // Request code（可自定义）
                chatIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default_channel")
                .setContentTitle("新消息")
                .setContentText(chat.getContent())
                .setContentIntent(pendingIntent)
                .setAutoCancel(true) //用户点击后移除提示
                .setSmallIcon(R.drawable.book);
        manager.notify(1, builder.build());
    }

    private Notification createNotification() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "default_channel",
                    "重要通知",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("应用基础通知");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        return new NotificationCompat.Builder(this, "default_channel")
                .setContentTitle("WebSocket 运行中")
                .setSmallIcon(R.drawable.book)
                .build();
    }

    public void connect() {

        Request request = new Request.Builder()
                .url(Constants.WS_URL)
                .build();
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, okhttp3.Response response) {
                Log.d("WebSocket", "Connected");
                GlobalApplication instance = GlobalApplication.getInstance();

                Integer userId = instance.getUser().getId();
                retryCount = 0; // 重置重试计数器
                webSocket.send(EncryptUtils.AESEncode("0&" + userId));
            }

            @Override
            public void onMessage(WebSocket webSocket, String text) {
                Log.d("WebSocket", "Received: " + text);
                Intent intentBroadcast = new Intent();
                String chat;
                try {
                    chat = EncryptUtils.AESDecode(text);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

                if (chat.charAt(0) == '1'){// 0连接信息  1发送消息
                    intentBroadcast.putExtra("chat",chat.substring(2));

                    intentBroadcast.setAction("chat_broadcast_receiver");
                    GlobalApplication instance = GlobalApplication.getInstance();
                    instance.sendBroadcast(intentBroadcast);
                }


            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                Log.d("WebSocket", "Closed: " + reason + " code:" + code);
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, okhttp3.Response response) {
                Log.e("WebSocket", "Error: ", t);
                //判断登录状态
                if (shouldReconnect) {
                    scheduleReconnect();
                }
            }
        });
    }
    private void scheduleReconnect() {
        long delay = calculateBackoffDelay(retryCount++);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                //发送重新连接的信息给service
                Intent socketServiceIntent = new Intent(SocketService.this, SocketService.class);
                socketServiceIntent.putExtra("action",CONNECTION);
                SocketService.this.startService(socketServiceIntent);
            }
        }, delay);
    }

    private long calculateBackoffDelay(int attempt) {
        return Math.min((long) Math.pow(2, attempt) * 1000, 30000);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    // 指数退避重连
//    private void scheduleReconnect() {
//        handler.postDelayed(() -> {
//            if (shouldReconnect) {
//                connect();
//            }
//        }, 5000); // 5秒后重试
//    }
}
