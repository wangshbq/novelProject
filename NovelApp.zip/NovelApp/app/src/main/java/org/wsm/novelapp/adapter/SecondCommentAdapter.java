package org.wsm.novelapp.adapter;

import static android.content.Context.INPUT_METHOD_SERVICE;
import static org.wsm.novelapp.common.CommonMethod.handleShowTime;
import static org.wsm.novelapp.common.Constants.COMMENT_THUMBS_UP;
import static org.wsm.novelapp.common.Constants.INSERT_COMMENT_A;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.bean.CommentBean;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.home.PersonCenterActivity;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SecondCommentAdapter extends RecyclerView.Adapter<SecondCommentAdapter.CommentViewHolder> implements View.OnClickListener {

    private Context context;
    private List<CommentBean> datas;
    //,getSecondComment,sendComment
    private RequestUtil sendComment;
    private BottomSheetDialog bottomSheetDialog;
    private boolean isClearInputComment = false;
    private EditText et_input_comment_dialog;
    private String inputComment = "";
    public SecondCommentAdapter(Context context,
                                List<CommentBean> datas,
                                RequestUtil sendComment) {
        this.context = context;
        this.datas = datas;
        this.sendComment = sendComment;
    }

    @SuppressLint("MissingInflatedId")
    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.item_second_comment, parent, false);
        inflate.findViewById(R.id.iv_reply_item_second_comment_icon).setOnClickListener(this);
        inflate.findViewById(R.id.iv_item_second_comment_thumb_icon).setOnClickListener(this);

        inflate.findViewById(R.id.iv_head_image).setOnClickListener(this);
        inflate.findViewById(R.id.tv_item_second_comment_user_name).setOnClickListener(this);

        return new SecondCommentAdapter.CommentViewHolder(inflate);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
        CommentBean commentBean = datas.get(position);

        holder.tv_item_second_comment_user_name.setText(commentBean.getUserName());

        holder.tv_item_second_comment_content.setText(commentBean.getCommentContent());
        holder.tv_item_second_comment_time.setText(handleShowTime(commentBean.getPublishTime().toString()));
        holder.tv_item_second_comment_thumb_up.setText(commentBean.getThumbUpNumber() + "");

        String replyUserName = commentBean.getReplyUserName();

        if(replyUserName == null || replyUserName.isEmpty()){
            holder.iv_arrow_icon.setVisibility(View.GONE);
            holder.tv_reply_item_second_comment_user_name.setText("");
        }else{
            holder.iv_arrow_icon.setVisibility(View.VISIBLE);
            holder.tv_reply_item_second_comment_user_name.setText(replyUserName);
        }


        Integer isThumbsUp = commentBean.getIsThumbsUp();

        if(isThumbsUp == null || isThumbsUp == 0)
            holder.iv_item_second_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_border_35);
        else
            holder.iv_item_second_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_35);



        holder.iv_item_second_comment_thumb_icon.setTag(position);
        holder.iv_reply_item_second_comment_icon.setTag(position);

        holder.iv_head_image.setTag(position);
        holder.tv_item_second_comment_user_name.setTag(position);
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.iv_reply_item_second_comment_icon){//回复二级评论

            int position = (int) v.getTag();
            handleBottomSheetDialog(position);

        }else if(id == R.id.iv_item_second_comment_thumb_icon){//点赞二级评论

            int position = (int) v.getTag();

            CommentBean commentBean = datas.get(position);
            Integer novelId = commentBean.getNovelId();
            Integer commentId = commentBean.getCommentId();
            Integer parentId = commentBean.getParentId();
            Integer isThumbsUp = commentBean.getIsThumbsUp();
            if(isThumbsUp == 1) return;
            new Thread(() -> {

                Map<String, String> map = new HashMap<>();
                map.put("novelId",novelId + "");
                map.put("commentId",commentId + "");
                map.put("parentId",parentId + "");
                new RequestUtil((Activity) context, new RequestUtil.ResponseListen() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void handleResponse(Result result) throws IOException {
                        if(result.getCode() != 1){
                            ((Activity) context).runOnUiThread(() -> Toast.makeText(context,result.getMsg(),Toast.LENGTH_SHORT).show());
                        }else{

                            ((Activity) context).runOnUiThread(() -> {
                                commentBean.setThumbUpNumber(commentBean.getThumbUpNumber() + 1);

                                commentBean.setIsThumbsUp(1);

                                notifyItemChanged(position);
                            });
                        }
                    }
                }).GetRequest(map,COMMENT_THUMBS_UP);
            }).start();

        }else if(id == R.id.tv_publish_comment){

            String content = et_input_comment_dialog.getText().toString();
            int position = (int) v.getTag();
            //回复的那条评论的position
            CommentBean commentBean = datas.get(position);

            if(content.isEmpty()){
                ((Activity)context).runOnUiThread(() -> Toast.makeText(context,"不能为空",Toast.LENGTH_SHORT).show());
                return;
            }

            if(content.length() > 1000){
                ((Activity)context).runOnUiThread(() -> Toast.makeText(context,"字数不能超过1000",Toast.LENGTH_SHORT).show());
                return;
            }

            isClearInputComment = true;
            bottomSheetDialog.dismiss();

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("novelId",commentBean.getNovelId());
                jsonObject.put("content",content);
                jsonObject.put("parentId",commentBean.getParentId());
                jsonObject.put("replyCommentId",commentBean.getCommentId());

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            sendComment.PostRequest(jsonObject.toString(),INSERT_COMMENT_A);
        }else if(id == R.id.iv_head_image || id == R.id.tv_item_second_comment_user_name){
            int position = (int) v.getTag();
            CommentBean commentBean = datas.get(position);

            Intent intent = new Intent(context, PersonCenterActivity.class);
            intent.putExtra("authorUserId",commentBean.getUserId());
            intent.putExtra("authorName",commentBean.getUserName());
            context.startActivity(intent);
        }
    }

    private void handleBottomSheetDialog(int position){
        // 创建 BottomSheetDialog
        bottomSheetDialog = new BottomSheetDialog(context);
        View bottom_dialog_input_comment = ((Activity)context).getLayoutInflater().inflate(R.layout.bottom_dialog_input_comment, null);
        bottomSheetDialog.setContentView(bottom_dialog_input_comment);

        bottomSheetDialog.show();
        //用户输入评论框
        et_input_comment_dialog = bottom_dialog_input_comment.findViewById(R.id.et_input_comment_dialog);

        //点击发布的按钮
        TextView tv_publish_comment = bottom_dialog_input_comment.findViewById(R.id.tv_publish_comment);
        tv_publish_comment.setTag(position);
        tv_publish_comment.setOnClickListener(this);
        // 设置销毁监听器
        bottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if(isClearInputComment){
                    inputComment = "";
                    isClearInputComment = false;
                }else{
                    inputComment = et_input_comment_dialog.getText().toString();
                }
            }
        });

        //弹出键盘
        et_input_comment_dialog.post(() -> {
            et_input_comment_dialog.requestFocus();
            et_input_comment_dialog.setText(inputComment);

            InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);

            if (imm != null)
                imm.showSoftInput(et_input_comment_dialog, InputMethodManager.SHOW_IMPLICIT);

        });

    }

    public static class CommentViewHolder extends RecyclerView.ViewHolder{

        TextView tv_item_second_comment_user_name;
        TextView tv_reply_item_second_comment_user_name;
        TextView tv_item_second_comment_content;
        TextView tv_item_second_comment_time;
        TextView tv_item_second_comment_thumb_up;
        ImageView iv_item_second_comment_thumb_icon;
        ImageView iv_arrow_icon;
        ImageView iv_reply_item_second_comment_icon;
        ImageView iv_head_image;
        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_item_second_comment_user_name = itemView.findViewById(R.id.tv_item_second_comment_user_name);
            tv_reply_item_second_comment_user_name = itemView.findViewById(R.id.tv_reply_item_second_comment_user_name);
            tv_item_second_comment_content = itemView.findViewById(R.id.tv_item_second_comment_content);
            tv_item_second_comment_time = itemView.findViewById(R.id.tv_item_second_comment_time);
//            iv_reply_item_second_comment_icon = itemView.findViewById(R.id.iv_reply_item_second_comment_icon);
            iv_item_second_comment_thumb_icon = itemView.findViewById(R.id.iv_item_second_comment_thumb_icon);
            tv_item_second_comment_thumb_up = itemView.findViewById(R.id.tv_item_second_comment_thumb_up);
            iv_arrow_icon = itemView.findViewById(R.id.iv_arrow_icon);
            iv_reply_item_second_comment_icon = itemView.findViewById(R.id.iv_reply_item_second_comment_icon);
            iv_head_image = itemView.findViewById(R.id.iv_head_image);

        }
    }
}
