#include <jni.h>
#include <sstream>
#include <string>
#include <iomanip>
#include <iostream>
#include "./include/SHA256.h"
#include "./include/AES.h"

std::string keyStr = "1mqrecafskey1234"; // 16字节密钥
std::string ivStr = "rajkotivqgsvs678"; // 16字节IV


// 将字符串转换为字节数组
 __attribute__ ((visibility("hidden")))
std::vector<unsigned char> stringToBytes(const std::string& str) {
    return std::vector<unsigned char>(str.begin(), str.end());
}
// 将字节数组转换为 16 进制字符串
 __attribute__ ((visibility("hidden")))
std::string bytesToHexString(const std::vector<unsigned char>& bytes) {
    std::stringstream ss;
    ss << std::hex << std::setfill('0'); // 设置输出为 16 进制，并用 0 填充

    for (unsigned char byte : bytes) {
        ss << std::setw(2) << static_cast<int>(byte); // 每个字节转换为 2 位 16 进制
    }

    return ss.str();
}
// 将字节数组转换为字符串
 __attribute__ ((visibility("hidden")))
std::string bytesToString(const std::vector<unsigned char>& bytes) {
    return std::string(bytes.begin(), bytes.end());
}
// 将 16 进制字符串转换为字节数组
 __attribute__ ((visibility("hidden")))
std::vector<unsigned char> hexStringToBytes(const std::string& hexString) {
    // 检查字符串长度是否为偶数
    if (hexString.length() % 2 != 0) {
        throw std::invalid_argument("Hex string length must be even");
    }

    std::vector<unsigned char> bytes;
    for (size_t i = 0; i < hexString.length(); i += 2) {
        // 提取两个字符
        std::string byteString = hexString.substr(i, 2);

        // 将 16 进制字符串转换为字节
        unsigned char byte = static_cast<unsigned char>(std::stoul(byteString, nullptr, 16));

        // 添加到字节数组
        bytes.push_back(byte);
    }

    return bytes;
}



// 将字符串转换为字节数组
std::vector<unsigned char> key = stringToBytes(keyStr);
std::vector<unsigned char> iv = stringToBytes(ivStr);
//
// Created by 86157 on 2025/3/30.
//

extern "C"
JNIEXPORT jstring JNICALL
Java_org_wsm_novelapp_nativ_EncryptUtils_AESEncode(JNIEnv *env, jclass clazz, jstring plain_text) {
    // TODO: implement AESEncode()
    const char *utfChars = env->GetStringUTFChars(plain_text, nullptr);
    //用户输入的明文字符串
    std::string plainStr(utfChars);
    //转为字节
    std::vector<unsigned char> plainByte = stringToBytes(plainStr);

    AES aes(key);

    // 加密得到密文字节
    std::vector<unsigned char> cipherByte = aes.encrypt(plainByte, iv);
    //将密文字节转16进制字符串
    std::string cipherText = bytesToHexString(cipherByte);

    env->ReleaseStringUTFChars(plain_text, utfChars);

    return env -> NewStringUTF(cipherText.c_str());
}
extern "C"
JNIEXPORT jstring JNICALL
Java_org_wsm_novelapp_nativ_EncryptUtils_AESDecode(JNIEnv *env, jclass clazz, jstring cipher_text) {
    // TODO: implement AESDecode()
    const char *utfChars = env->GetStringUTFChars(cipher_text, nullptr);
    //用户输入的密文字符串
    std::string cipherStr(utfChars);
    //转为字节
    std::vector<unsigned char> cipherByte = hexStringToBytes(cipherStr);

    AES aes(key);

    // 解密得到明文字节
    std::vector<unsigned char> plainByte = aes.decrypt(cipherByte, iv);
    //将明文字节转字符串
    std::string plainText = bytesToString(plainByte);
    env->ReleaseStringUTFChars(cipher_text, utfChars);
    return env -> NewStringUTF(plainText.c_str());
}
extern "C"
JNIEXPORT jstring JNICALL
Java_org_wsm_novelapp_nativ_EncryptUtils_SHA256(JNIEnv *env, jclass clazz, jstring plain_text) {
    // TODO: implement SHA256()
    const char *utfChars = env->GetStringUTFChars(plain_text, nullptr);
    //用户输入的明文字符串
    std::string plainStr(utfChars);

    SHA256 sha256;

    uint8_t hash[SHA256::HASH_SIZE];
    sha256.update(reinterpret_cast<const uint8_t*>(plainStr.data()), plainStr.size());
    sha256.final(hash);

    std::stringstream ss;

    for (int i = 0; i < SHA256::HASH_SIZE; ++i) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }

    std::string cipherText = ss.str();

    env->ReleaseStringUTFChars(plain_text, utfChars);

    return env -> NewStringUTF(cipherText.c_str());
}