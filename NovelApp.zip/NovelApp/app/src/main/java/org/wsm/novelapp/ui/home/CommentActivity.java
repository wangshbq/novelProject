package org.wsm.novelapp.ui.home;

import static org.wsm.novelapp.common.Constants.GET_COMMENT_A;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.INSERT_COMMENT_A;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.CommentAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.CommentBean;
import org.wsm.novelapp.bean.HomeEntryBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dto.CommentDto;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class CommentActivity extends AppCompatActivity implements View.OnClickListener {

    private List<CommentBean> datas = new ArrayList<>();
    private RecyclerView rv_comment_list;
    private CommentAdapter commentAdapter;
    private RequestUtil requestComment;
    private String novelId;
    private Integer currentPage = 0;
    private TextView et_input_comment;
    private EditText et_input_comment_dialog;
    private TextView tv_publish_comment;
    private BottomSheetDialog bottomSheetDialog;
    private TextView tv_comment_number;
//    private int increaseComment = 0;
    private int sort = 0;//0默认  1最新
    private long lastLoadTime = 0; // 记录上次加载的时间
    private static final long LOAD_THRESHOLD = 1000; // 1秒内只加载一次

    private boolean isBottomRemind = false;
    private TextView tv_comment_default_sort;
    private TextView tv_comment_most_new_sort;

    private int black;
    private int middle_gray;
    //键盘输入的内容
    private String inputComment = "";
    //销毁输入评论的弹出框时 是否要清除inputComment
    private boolean isClearInputComment = false;
    private RequestUtil sendComment;

    private List<Integer> commentIds = new ArrayList<>();

    private ActivityResultLauncher<Intent> activityResultLauncher;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);
        Toolbar tb_comment_head = findViewById(R.id.tb_comment_head);
        tb_comment_head.setNavigationOnClickListener(view -> {
            setIncreaseComment();
            finish();
        });

        // 创建 OnBackPressedCallback
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                setIncreaseComment();
                finish();
            }
        };

        // 将 callback 添加到 Activity 的 OnBackPressedDispatcher
        getOnBackPressedDispatcher().addCallback(this, callback);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {

                        Intent data = result.getData();
                        int isThumbUp = data.getIntExtra("isThumbUp",0);
                        int thumbUpNumber = data.getIntExtra("thumbUpNumber", 0);
                        int position = data.getIntExtra("position", 0);
                        int secondCommentNumber = data.getIntExtra("secondCommentNumber", 0);

                        boolean isUpdate = false;

                        CommentBean commentBean = datas.get(position);

                        if(commentBean.getIsThumbsUp() != isThumbUp){
                            isUpdate = true;
                            commentBean.setIsThumbsUp(1);
                            commentBean.setThumbUpNumber(thumbUpNumber);
                        }
                        int sub = secondCommentNumber - commentBean.getSecondCommentNumber();
                        if(sub > 0){
                            isUpdate = true;
                            commentBean.setSecondCommentNumber(secondCommentNumber);
                            int i = Integer.parseInt(tv_comment_number.getText().toString());
                            runOnUiThread(() -> tv_comment_number.setText((i + sub) + ""));
                        }

                        if(isUpdate) commentAdapter.notifyItemChanged(position);
                    }
                }
        );

        black = ContextCompat.getColor(this, R.color.black);
        middle_gray = ContextCompat.getColor(this, R.color.middle_gray);

        tv_comment_default_sort = findViewById(R.id.tv_comment_default_sort);
        tv_comment_most_new_sort = findViewById(R.id.tv_comment_most_new_sort);

        tv_comment_default_sort.setOnClickListener(this);
        tv_comment_most_new_sort.setOnClickListener(this);

        et_input_comment = findViewById(R.id.et_input_comment);
        //显示评论数量
        tv_comment_number = findViewById(R.id.tv_comment_number);
        et_input_comment.setOnClickListener(this);

        novelId = getIntent().getStringExtra("novelId");
        tv_comment_number.setText(getIntent().getStringExtra("commentNumber"));



        //下拉刷新控件
        SwipeRefreshLayout sr_comment_list = findViewById(R.id.sr_comment_list);
        //下拉刷新
        sr_comment_list.setOnRefreshListener(() -> {
            tv_comment_default_sort.setTextColor(black);
            tv_comment_most_new_sort.setTextColor(middle_gray);

            resumeData(0);
            //停止刷新动画
            sr_comment_list.setRefreshing(false);
        });
        //列表展示控件
        rv_comment_list = findViewById(R.id.rv_comment_list);

        rv_comment_list.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,false));


        //发送评论的请求
        sendComment = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
            @Override
            public void handleResponse(Result result) throws IOException {

                if (result.getCode() == 1) {
                    //新发了一条评论
//                    increaseComment++;

                    if(bottomSheetDialog != null) bottomSheetDialog.dismiss();

                    Map<String, String> data = result.getData();
                    String commentDtoStr = data.get("commentDto");
                    Type commentDtoType = new TypeToken<CommentDto>() {
                    }.getType();

                    CommentDto commentDto = GSON.fromJson(commentDtoStr, commentDtoType);
                    GlobalApplication application = (GlobalApplication) getApplication();
                    User user = application.getUser();
                    if (commentDto != null) {
                        commentIds.add(commentDto.getId());
                        CommentBean commentBean = new CommentBean();
                        commentBean.setCommentContent(commentDto.getContent());
                        commentBean.setUserName(user.getUsername());
                        Integer thumbsUp = commentDto.getThumbsUp();
                        commentBean.setThumbUpNumber(thumbsUp == null ? 0 : thumbsUp);

                        commentBean.setPublishTime(commentDto.getCommentTime());

                        commentBean.setNovelId(Integer.parseInt(novelId));

                        commentBean.setCommentId(commentDto.getId());

                        commentBean.setIsThumbsUp(0);

                        commentBean.setSecondCommentNumber(0);

                        Integer parentId = commentDto.getParentId();
                        commentBean.setParentId(parentId);
                        commentBean.setSecondCommentNumber(0);
                        if(parentId == 0){//添加了一条一级评论
                            Integer secPosition = commentAdapter.getSecPosition();

                            datas.add(secPosition,commentBean);

                            commentAdapter.setSecPosition(secPosition + 1);
                        }else{//添加了一条二级评论
//                            String replyUserName = getUserNameByReplyCommentId(commentDtos,commentDto.getReplyCommentId());
                            for(CommentBean commentBean2: datas){
                                Integer commentId = commentBean2.getCommentId();
                                if(commentId.equals(parentId)){
                                    //将此二级评论的父评论的二级评论数加1
                                    commentBean2.setSecondCommentNumber(commentBean2.getSecondCommentNumber() + 1);
                                }

                                if(commentId.equals(commentDto.getReplyCommentId())){
                                    //设置被回复者userName
                                    commentBean.setReplyUserName(commentBean2.getUserName());
                                }
                            }
                            datas.add(commentBean);
                        }
                    }

                    runOnUiThread(() -> {
                        Toast.makeText(CommentActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show();
                        tv_comment_number.setText(Integer.parseInt(tv_comment_number.getText().toString()) + 1 + "");
//                        commentAdapter.notifyDataSetChanged();
                    });
                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(CommentActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });

        //适配器
        commentAdapter = new CommentAdapter(this,activityResultLauncher,datas,sendComment,novelId);
        //控件绑定适配器
        rv_comment_list.setAdapter(commentAdapter);

        //上滑刷新
        rv_comment_list.addOnScrollListener(new RecyclerView.OnScrollListener(){
            @Override
            public void  onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if(dy <= 0) return;
                // 获取布局管理器
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                // 获取当前可见的 item 数量
                int visibleItemCount = Objects.requireNonNull(layoutManager).getChildCount();

                // 获取总的 item 数量
                int totalItemCount = layoutManager.getItemCount();

                // 获取第一个可见的 item 的位置
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

                if ((visibleItemCount + firstVisibleItemPosition) >= (totalItemCount - 1)) {
                    long currentTime = System.currentTimeMillis();
                    // && isScrolled.compareAndSet(true,false)
                    if(currentTime - lastLoadTime > LOAD_THRESHOLD){
                        lastLoadTime = currentTime;
                        // 加载更多数据
                        requestComment();
                    }
                }
            }
        });

        requestComment = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() != 1){
                    runOnUiThread(() -> Toast.makeText(CommentActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }else{
                    Map<String, String> data = result.getData();
                    Log.d("====>data", data == null? "data=null" : data.toString());
                    String comment = data.get("comment");
                    Log.d("====>comment", comment == null? "commment=null" : comment);
                    Type type = new TypeToken<List<CommentDto>>() {}.getType();

                    List<CommentDto> commentDtos = GSON.fromJson(comment, type);


                    if(commentDtos != null){

                        for (CommentDto commentDto : commentDtos){
                            CommentBean commentBean = new CommentBean();
                            commentBean.setUserId(commentDto.getUserId());
                            commentBean.setUserName(commentDto.getUsername());
                            commentBean.setCommentContent(commentDto.getContent());
                            commentBean.setPublishTime(commentDto.getCommentTime());

                            Integer thumbsUp = commentDto.getThumbsUp();
                            commentBean.setThumbUpNumber(thumbsUp == null ? 0 : thumbsUp);

                            commentBean.setNovelId(Integer.parseInt(novelId));
                            commentBean.setCommentId(commentDto.getId());
                            commentBean.setIsThumbsUp(commentDto.getIsThumbsUp());
                            Integer parentId = commentDto.getParentId();
                            commentBean.setParentId(parentId);
                            commentBean.setSecondCommentNumber(commentDto.getCommentNumber());

                            if(parentId == 0){//一级评论
                                Integer secPosition = commentAdapter.getSecPosition();
                                datas.add(secPosition,commentBean);
                                commentAdapter.setSecPosition(secPosition + 1);
                            }else{//二级评论
                                //获取被回复者用户名
                                String replyUserName = null;
                                Integer replyCommentId = commentDto.getReplyCommentId();
                                for(CommentDto commentDto2: commentDtos){
                                    if (commentDto2.getId().equals(replyCommentId)){
                                        replyUserName = commentDto2.getUsername();
                                        break;
                                    }
                                }

                                commentBean.setReplyUserName(replyUserName);

                                datas.add(commentBean);
                            }
                            commentIds.add(commentDto.getId());
                        }

                        if(commentDtos.size() < 8) isBottomRemind = true;

                        runOnUiThread(() -> {
                            Log.d("====>datas", datas.toString());
//                            Log.d("====>commentAdapter", commentAdapter.getDatas().hashCode() + "");
//                            datas.add(new CommentBean());
                            commentAdapter.notifyDataSetChanged();
                            if(isBottomRemind){
                                Toast.makeText(CommentActivity.this,"已经到底了~",Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                }
            }
        });

        requestComment();
    }

    private void requestComment(){
        //若到底则return
        if(isBottomRemind) return;
        currentPage++;

        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("novelId",novelId);
            jsonObject.put("currentPage",((currentPage - 1) * 8) + "");
//            if(sort == 0)
//
//            else
//                jsonObject.put("currentPage","-1");

            jsonObject.put("sort",sort + "");
            jsonObject.put("commentIds",commentIds.toString());
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        new Thread(() -> requestComment.PostRequest(jsonObject.toString(),GET_COMMENT_A)).start();
    }

    private void resumeData(int sort){
        currentPage = 0;
        isBottomRemind = false;
        commentAdapter.setSecPosition(0);
        datas.clear();
        commentIds.clear();
        this.sort = sort;
        requestComment();
    }
    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.et_input_comment){

            handleBottomSheetDialog();
        }else if(id == R.id.tv_publish_comment){//点击发送评论
            String content = et_input_comment_dialog.getText().toString();

            if(content.isEmpty()){
                Toast.makeText(this,"内容不能为空",Toast.LENGTH_SHORT).show();
                return;
            }
            if(content.length() > 1000){
                Toast.makeText(this,"字数不能超过1000",Toast.LENGTH_SHORT).show();
                return;
            }

            isClearInputComment = true;

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("novelId",novelId);
                jsonObject.put("content",content);
                jsonObject.put("parentId","0");
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            //发送评论的请求
            new Thread(() -> {
                sendComment.PostRequest(jsonObject.toString(),INSERT_COMMENT_A);
            }).start();

        }else if(id == R.id.tv_comment_default_sort){//默认排序
            if(sort == 0) return;

            tv_comment_default_sort.setTextColor(black);
            tv_comment_most_new_sort.setTextColor(middle_gray);
            rv_comment_list.scrollToPosition(0);
            resumeData(0);

        }else if(id == R.id.tv_comment_most_new_sort){//最新排序
            if(sort == 1) return;
            rv_comment_list.scrollToPosition(0);
            tv_comment_default_sort.setTextColor(middle_gray);
            tv_comment_most_new_sort.setTextColor(black);

            resumeData(1);

        }
    }

    private void handleBottomSheetDialog(){
        // 创建 BottomSheetDialog
        bottomSheetDialog = new BottomSheetDialog(this);
        View bottom_dialog_input_comment = getLayoutInflater().inflate(R.layout.bottom_dialog_input_comment, null);
        bottomSheetDialog.setContentView(bottom_dialog_input_comment);
        et_input_comment.setVisibility(View.GONE);
        bottomSheetDialog.show();
        //用户输入评论框
        et_input_comment_dialog = bottom_dialog_input_comment.findViewById(R.id.et_input_comment_dialog);
        //点击发布的按钮
        tv_publish_comment = bottom_dialog_input_comment.findViewById(R.id.tv_publish_comment);
        tv_publish_comment.setOnClickListener(this);
        // 设置销毁监听器
        bottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //显示点击评论按钮
                et_input_comment.setVisibility(View.VISIBLE);
                if(isClearInputComment){
                    inputComment = "";
                    isClearInputComment = false;
                }else{
                    inputComment = et_input_comment_dialog.getText().toString();
                }

            }
        });

        //弹出键盘
        et_input_comment_dialog.post(() -> {
            //设置选中焦点
            et_input_comment_dialog.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            et_input_comment_dialog.setText(inputComment);
            if (imm != null) {
                imm.showSoftInput(et_input_comment_dialog, InputMethodManager.SHOW_IMPLICIT);
            }
        });

    }

    private void setIncreaseComment(){
        Intent resultIntent = new Intent();
//        resultIntent.putExtra("increaseComment", increaseComment);
        resultIntent.putExtra("commentNumber", Integer.parseInt(tv_comment_number.getText().toString()));
        setResult(RESULT_OK, resultIntent);
    }

}