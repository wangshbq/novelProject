package org.wsm.novelapp.ui.mine.create;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;

import org.wsm.novelapp.R;

public class CreateCenterActivity extends AppCompatActivity implements View.OnClickListener {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_center);

        Toolbar tb_create_center_head = findViewById(R.id.tb_create_center_head);
        tb_create_center_head.setNavigationOnClickListener(view -> finish());

        findViewById(R.id.btn_create_center_content_manager).setOnClickListener(this);
        findViewById(R.id.btn_create_center_write_novel).setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.btn_create_center_content_manager){
            Intent intent = new Intent(this, ContentManagerActivity.class);
            startActivity(intent);
        }else if(id == R.id.btn_create_center_write_novel){
            Intent intent = new Intent(this, WriteNovelActivity.class);
            intent.putExtra("intentFrom", "CreateCenterActivity");
            startActivity(intent);
        }

    }
}