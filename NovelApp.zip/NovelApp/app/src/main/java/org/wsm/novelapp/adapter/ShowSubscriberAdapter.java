package org.wsm.novelapp.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.wsm.novelapp.R;
import org.wsm.novelapp.bean.ShowSubscriberBean;
import org.wsm.novelapp.ui.mine.subscribe.ChatActivity;

import java.util.List;

public class ShowSubscriberAdapter extends RecyclerView.Adapter<ShowSubscriberAdapter.ContentViewHolder> implements View.OnClickListener  {

    private List<ShowSubscriberBean> datas;
    private Context context;

    public ShowSubscriberAdapter(Context context,List<ShowSubscriberBean> datas){
        this.context = context;
        this.datas = datas;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.iv_subscriber_chat_icon){
            int position = (int) v.getTag();
            ShowSubscriberBean showSubscriberBean = datas.get(position);

            Intent intent = new Intent(context, ChatActivity.class);
            intent.putExtra("userName",showSubscriberBean.getUserName());
            intent.putExtra("userId",showSubscriberBean.getUserId());
            context.startActivity(intent);

        }
    }

    @NonNull
    @Override
    public ContentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_subscriber, parent, false);
        ContentViewHolder contentViewHolder = new ContentViewHolder(view);
        contentViewHolder.iv_subscriber_chat_icon.setOnClickListener(this);
        return contentViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ContentViewHolder holder, int position) {
        ShowSubscriberBean showSubscriberBean = datas.get(position);
        holder.tv_subscriber_user_name.setText(showSubscriberBean.getUserName());
        holder.iv_subscriber_chat_icon.setTag(position);
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public static class ContentViewHolder extends RecyclerView.ViewHolder{
//        ImageView iv_subscriber_chat_icon;
        TextView tv_subscriber_user_name;
        ImageView iv_subscriber_chat_icon;
        public ContentViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_subscriber_user_name = itemView.findViewById(R.id.tv_subscriber_user_name);
            iv_subscriber_chat_icon = itemView.findViewById(R.id.iv_subscriber_chat_icon);
        }
    }
}
