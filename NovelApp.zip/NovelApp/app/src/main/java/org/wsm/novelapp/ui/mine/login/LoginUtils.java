package org.wsm.novelapp.ui.mine.login;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

import static org.wsm.novelapp.common.CommonMethod.stringToUser;

import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.service.SocketService.CONNECTION;
import static org.wsm.novelapp.service.SocketService.SEND_MESSAGE;
import static org.wsm.novelapp.utils.RequestUtil.REFRESH;
import static org.wsm.novelapp.utils.RequestUtil.TOKEN;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.google.gson.reflect.TypeToken;
import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.utils.RequestUtil;
import org.wsm.novelapp.service.SocketService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Response;

public class LoginUtils {

    public static boolean isSavePassword = false;

    public static boolean emailFormVerify(String email){
        //发送邮件
        String regex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.find();
    }

    public static void remindAndFinish(Activity activity,String data){
        activity.runOnUiThread(() -> {
            Toast toast = Toast.makeText(activity, data, Toast.LENGTH_SHORT);
            toast.show();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    toast.cancel();

                    activity.finish();
                }
            }, 800);
        });
    }

    public static Result handleResponse(Response response) throws IOException {
        String string = Objects.requireNonNull(response.body()).string();
        Log.d("==================string", string);
        Result result;
        try {
            Type resultType = new TypeToken<Result>() {}.getType();
            result = GSON.fromJson(string, resultType);
        }catch (Exception e){
            e.printStackTrace();
            return Result.error("异常");
        }
        Log.d("========================result", result.toString());
        return result;
    }

    public void forbidCaptchaButton(Button button){
        // 禁用按钮
        button.setEnabled(false);

        new CountDownTimer(50000, 1000) { // 50 秒，间隔 1 秒
            @SuppressLint("SetTextI18n")
            @Override
            public void onTick(long millisUntilFinished) {
                // 每秒更新 UI
                button.setText(millisUntilFinished / 1000 + "");
            }

            @Override
            public void onFinish() {
                button.setEnabled(true);
                button.setText("发送验证码");
            }
        }.start();
    }

    @SuppressLint("CommitPrefEdits")
    public static void handleLoginSucResp(Context context,Result result){
        //获得响应数据
        Map<String,String> map = result.getData();

        //获得用户信息
        String userStr = Objects.requireNonNull(map.get("user"));

        User user = stringToUser(userStr);

        //将数据加入到application
        GlobalApplication application = (GlobalApplication)((Activity)context).getApplication();

        application.setUser(user);

//        SocketService.isSocket = true;
        //获取token 并处理
        REFRESH = Objects.requireNonNull(map.get("refreshToken"));
        TOKEN = Objects.requireNonNull(map.get("accessToken"));
        //判断是否需要保存token
        if(isSavePassword){
            SharedPreferences preferences = context.getSharedPreferences("config:" + user.getId(), MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("accessToken",TOKEN);
            editor.putString("refreshToken",REFRESH);
            editor.apply();

            SharedPreferences preferences2 = context.getSharedPreferences("config", MODE_PRIVATE);
            SharedPreferences.Editor edit = preferences2.edit();
            edit.putInt("currentUserId",user.getId());
            edit.apply();
        }

        //连接socket
        Intent socketServiceIntent = new Intent(context, SocketService.class);
        socketServiceIntent.putExtra("action",CONNECTION);
        context.startService(socketServiceIntent);

        // 在 finish() 之前返回数据
        Intent resultIntent = new Intent();
        resultIntent.putExtra("logout", context.getString(R.string.quit));
        ((Activity)context).setResult(RESULT_OK, resultIntent);
    }

    @SuppressLint("HardwareIds")
    public static String getEnhancedFingerprint(Context context) {
         List<String> info = Arrays.asList(
                Build.FINGERPRINT,  // 系统构建指纹
                Build.HARDWARE,     // 硬件名称
                Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID)
        );

        String infoString = String.join("|", info);

        return EncryptUtils.SHA256(infoString);
    }

    public RequestUtil handleDefaultResponse(Activity activity){

        return new RequestUtil(activity, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {
                if(result.getCode() == 0){//失败
                    activity.runOnUiThread(() -> Toast.makeText(activity,result.getMsg(),Toast.LENGTH_SHORT).show());

                }else if(result.getCode() == 1){ //成功
                    activity.runOnUiThread(() -> Toast.makeText(activity,result.getMsg(),Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    public static void clearLoginData(Context context){
//        GlobalApplication application = (GlobalApplication) ((Activity)context).getApplication();
//        int userId = application.getUser().getId();
        SharedPreferences preferences1 = context.getSharedPreferences("config", MODE_PRIVATE);
        int currentUserId = preferences1.getInt("currentUserId",0);

        SharedPreferences preferences = context.getSharedPreferences("config:" + currentUserId, Context.MODE_PRIVATE);

        SharedPreferences.Editor edit = preferences.edit();

        edit.putString("accessToken","");
        edit.putString("refreshToken","");
        edit.apply();
        RequestUtil.TOKEN = "";
        RequestUtil.REFRESH = "";
    }
}
