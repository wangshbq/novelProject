package org.wsm.novelapp.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import org.wsm.novelapp.dto.NovelDto;

import java.util.List;


@Dao
public interface NovelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(NovelDto... novels);

    @Update
    int update(NovelDto... novels);

    /**
     * 通过小说id查询数据
     * @param id
     * @return
     */
    @Query("SELECT * FROM noveldto where id = :id")
    NovelDto queryById(Integer id);

    @Query("SELECT * FROM noveldto")
    List<NovelDto> queryAll();

    /**
     * 查询当前用户的八条小说数据
     * @param userId
     * @param offset
     * @return
     */
    @Query("SELECT * FROM noveldto where userId = :userId order by createTime desc limit 8 offset :offset")
    List<NovelDto> queryEight(int userId,int offset);

    /**
     * 修改id为0的数据的id
     * @param id
     */
    @Query("update noveldto set id = :id where id = 0")
    void updateIdByZeroId(int id);

    /**
     * 查询八条未发布 或者已发布的数据
     * @param status
     * @param userId
     * @param offset
     * @return
     */
    @Query("SELECT * FROM noveldto where status = :status and userId = :userId order by createTime desc limit 8 offset :offset")
    List<NovelDto> queryByStatus(int status,int userId,int offset);

    /**
     * 修改status  发布 或 未发布
     * @param status
     * @param userId
     * @return
     */
    @Query("update noveldto set status = :status where userId = :userId and id = :novelId")
    void updateStatus(int status,int novelId,int userId);


    @Query("DELETE FROM noveldto WHERE id IN (:ids)")
    void deleteByIds(List<Integer> ids);


}
