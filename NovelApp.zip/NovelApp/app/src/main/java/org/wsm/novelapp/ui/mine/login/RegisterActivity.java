package org.wsm.novelapp.ui.mine.login;

import static org.wsm.novelapp.common.Constants.REGISTER_URL;
import static org.wsm.novelapp.common.Constants.SEND_CAPTCHA_URL;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.emailFormVerify;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText et_captcha;
    private RequestUtil defaultResponseReq;
    private EditText et_email;
    private Button btn_send_captcha;
    private EditText et_username;
    private EditText et_password;
    private EditText et_repassword;
    private RequestUtil registerReq;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Toolbar tb_register_head = findViewById(R.id.tb_register_head);
        et_captcha = findViewById(R.id.et_captcha);
        et_email = findViewById(R.id.et_email);
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        et_repassword = findViewById(R.id.et_repassword);

        btn_send_captcha = findViewById(R.id.btn_send_captcha);

        findViewById(R.id.btn_sure_register).setOnClickListener(this);

        btn_send_captcha.setOnClickListener(this);

        tb_register_head.setNavigationOnClickListener(view -> finish());

        //发送验证码
        defaultResponseReq = new LoginUtils().handleDefaultResponse(this);

        registerReq = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() == 1){
                    LoginUtils.remindAndFinish(RegisterActivity.this, result.getMsg());
                }else{
                    runOnUiThread(() -> Toast.makeText(RegisterActivity.this,result.getMsg(),Toast.LENGTH_SHORT).show());
                }
            }
        });

    }

    @Override
    public void onClick(View v) {
        //验证邮箱
        String email = et_email.getText().toString().trim();
        String username = et_username.getText().toString().trim();
        String password = et_password.getText().toString().trim();
        String rePassword = et_repassword.getText().toString().trim();

        if(email.isEmpty()){
            Toast.makeText(RegisterActivity.this,"邮箱不能为空",Toast.LENGTH_SHORT).show();
            return;
        }else if(username.isEmpty()){
            Toast.makeText(RegisterActivity.this,"用户名不能为空",Toast.LENGTH_SHORT).show();
            return;
        }else if(password.isEmpty()){
            Toast.makeText(RegisterActivity.this,"密码不能为空",Toast.LENGTH_SHORT).show();
            return;
        }else if(!password.equals(rePassword)){
            Toast.makeText(RegisterActivity.this,"两次秘密不同",Toast.LENGTH_SHORT).show();
            return;
        }

        if(!emailFormVerify(email)){
            Toast.makeText(this,"邮箱格式错误",Toast.LENGTH_SHORT).show();
            return;
        }

        int id = v.getId();
        if(id == R.id.btn_send_captcha){//发送邮箱验证码

            JSONObject emailData = new JSONObject();
            try {
                emailData.put("email",email);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
            new Thread(() -> defaultResponseReq.PostRequest(emailData.toString(),SEND_CAPTCHA_URL)).start();
            //暂时禁用发送验证码的按钮
            new LoginUtils().forbidCaptchaButton(btn_send_captcha);

        }else if(id == R.id.btn_sure_register){
            String captcha = et_captcha.getText().toString().trim();

            if(captcha.isEmpty()){
                Toast.makeText(RegisterActivity.this,"验证码不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            JSONObject registerJson = new JSONObject();
            try {
                registerJson.put("username",username);
                registerJson.put("email",email);
                registerJson.put("password", EncryptUtils.SHA256(password));
                registerJson.put("captcha",captcha);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String registerString = registerJson.toString();

            new Thread(() -> registerReq.PostRequest(registerString,REGISTER_URL)).start();

        }
    }
}