package org.wsm.novelapp.utils;


import static android.content.Context.MODE_PRIVATE;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.getEnhancedFingerprint;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.isSavePassword;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.mine.login.LoginUtils;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.nativ.TokenGen;

import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RequestUtil {

    public static OkHttpClient client = new OkHttpClient();

    public static String TOKEN = "";
    public static String REFRESH = "";

    ResponseListen responseListen;

    Activity context;
    private boolean isAccessToken;

    public RequestUtil(Activity context,ResponseListen responseListen){
        this.context = context;
        this.responseListen = responseListen;
        GlobalApplication application = (GlobalApplication)context.getApplication();

    }

    private static String decodeBase64Url(String str) {
        byte[] decodedBytes = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            decodedBytes = Base64.getUrlDecoder().decode(str);
        }
        return new String(decodedBytes);
    }

    // 发起POST方式的HTTP请求（报文为JSON格式）
    public void PostRequest(String jsonString,String url)  {

        // 创建一个POST方式的请求结构  application/json      text/plain   'Content-Type': 'application/json'
        RequestBody body = RequestBody.create(jsonString, MediaType.parse("application/json;charset=utf-8"));

        Request.Builder builder = new Request.Builder()
                .post(body)
                .addHeader("client", "android")
                .url(url);

        //验证token
        handleTokenVerify(builder);

        Request request = builder.build();

        Call call = client.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) { // 请求失败
                context.runOnUiThread(() -> {
                    Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
                });
                Log.d("=========onFailure=========", "请求失败：" + e.getMessage());

            }
            @Override
            public void onResponse(Call call, final Response response) throws IOException { // 请求成功
                handleOnResponse(response);
            }
        });
    }

    public void GetRequest(Map<String,String> params,String url){

        if(params != null){
            //拼接参数
            StringBuilder stringBuilder = new StringBuilder(url);
            stringBuilder.append("?");
            for (Map.Entry<String,String> entry: params.entrySet()){
                stringBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            url = stringBuilder.toString();
        }

        // 构建请求
        Request.Builder builder = new Request.Builder()
                .url(url)
                .addHeader("client", "android");

        handleTokenVerify(builder);

        Request request = builder.build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                context.runOnUiThread(() -> {
                    Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
                });
                Log.d("=========onFailure=========", "请求失败：" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                handleOnResponse(response);
            }
        });
    }

    public static String getToken(){
        if(TOKEN.isEmpty() || REFRESH.isEmpty()) return null;
        Date claims = TokenGen.getExpiration(TOKEN);
        long timestamp = claims.getTime();
        long l = System.currentTimeMillis();

        if((timestamp - 5000) < l){
            return REFRESH;
        }
        return TOKEN;
    }

    public void handleTokenVerify(Request.Builder builder){
        isAccessToken = true;
        if(!TOKEN.isEmpty()){
            Date claims = TokenGen.getExpiration(TOKEN);
            long timestamp = claims.getTime();
            long l = System.currentTimeMillis();

            if((timestamp - 5000) < l){
                isAccessToken = false;
            }
        }

        if(!TOKEN.isEmpty() && !REFRESH.isEmpty()){
            if(isAccessToken){
                builder.addHeader("token", TOKEN);
            }else{
                builder.addHeader("token",REFRESH);
                //通过设备id生成指纹
                String enhancedFingerprint = getEnhancedFingerprint(context);
                long timestamp = System.currentTimeMillis();
                String fp = EncryptUtils.SHA256(enhancedFingerprint + timestamp);

                builder.addHeader("fp",fp);
                builder.addHeader("ts",timestamp + "");
            }
        }
    }


    public void handleOnResponse(Response response) throws IOException {
        Result result = LoginUtils.handleResponse(response);

        if(result != null){

            if(!isAccessToken){
                String accessToken = response.header("accessToken");
                String refreshToken = response.header("refreshToken");

                TOKEN = accessToken == null ? "" : accessToken;
                REFRESH = refreshToken == null ? "" : refreshToken;

                if(isSavePassword){//保存密码
                    SharedPreferences preferences1 = context.getSharedPreferences("config", MODE_PRIVATE);
                    int currentUserId = preferences1.getInt("currentUserId", 0);

                    SharedPreferences preferences = context.getSharedPreferences("config:" + currentUserId, MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("accessToken",TOKEN);
                    editor.putString("refreshToken",REFRESH);
                    editor.apply();
                }
            }

            responseListen.handleResponse(result);

        }else{
            context.runOnUiThread(() -> {
                Toast.makeText(context,"异常",Toast.LENGTH_SHORT).show();
            });
        }
    }

    public interface ResponseListen{
        void handleResponse(Result result) throws IOException;
    }
}
