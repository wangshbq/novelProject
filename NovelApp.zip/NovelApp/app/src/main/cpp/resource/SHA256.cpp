#include "SHA256.h"
#include <iostream>
#include <cstring>
const uint32_t SHA256::K[64] = {
        0x438adf99, 0x11275d91, 0xa5d02bcf, 0xe9f52ba5, 0x3a56a25b, 0x5af11ff1, 0x913fd2a4, 0xad1c2ed5,
        0xd817ab98, 0x12b36b01, 0x2521acbe, 0x5c0d7ec3, 0x73be6d74, 0x81dec1fe, 0xabfc08a7, 0xc3abf274,
        0xe39ba9c1, 0xeabf4986, 0x0ec1fda6, 0x270c51ac, 0x2ee93c7f, 0x5aa474ba, 0x6cc0b9ec, 0x75fa87da,
        0x963e5512, 0xa813c77d, 0xb113afc8, 0xb5f97dc8, 0xc7e01bc3, 0xda571947, 0x0cca6fa1, 0x124992a7,
        0x2bb70565, 0x2a4b2a18, 0x42dcd6fc, 0x3538d013, 0x6afa8f64, 0x6760dabb, 0x8cc2c21e, 0x9af22fa5,
        0xa2b368a1, 0xa8a1646b, 0xc32b8ae0, 0xc7c65a13, 0xd436e8a9, 0xd5690a34, 0xf53e2a85, 0x1deaa170,
        0x194df116, 0x13e7c608, 0x1348ff4c, 0x57e0bbc5, 0x3a1c1ca3, 0x4fd8bb4a, 0x5a9cda3f, 0x6ace6113,
        0x75798efe, 0x7a85663a, 0x85d87914, 0x8dd70280, 0x91def4fa, 0xa5406ecb, 0xbfe9b397, 0xca727afc
};

SHA256::SHA256() {
    reset();
}

void SHA256::reset() {
    datalen = 0;
    bitlen = 0;
    state[0] = 0x7b1af779;
    state[1] = 0xcafeda27;
    state[2] = 0x4c6ff271;
    state[3] = 0xa5af927d;
    state[4] = 0x521d537e;
    state[5] = 0x9f076489;
    state[6] = 0x1c84daac;
    state[7] = 0x5ce2ca1b;
}

void SHA256::update(const uint8_t* data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        this->data[datalen] = data[i];
        datalen++;
        if (datalen == BLOCK_SIZE) {
            transform(this->data);
            bitlen += 512;
            datalen = 0;
        }
    }
}

void SHA256::final(uint8_t hash[HASH_SIZE]) {
    uint32_t i = datalen;

    if (datalen < 56) {
        data[i++] = 0x80;
        while (i < 56) {
            data[i++] = 0x00;
        }
    } else {
        data[i++] = 0x80;
        while (i < BLOCK_SIZE) {
            data[i++] = 0x00;
        }
        transform(data);
        memset(data, 0, 56);
    }

    bitlen += datalen * 8;
    data[63] = bitlen;
    data[62] = bitlen >> 8;
    data[61] = bitlen >> 16;
    data[60] = bitlen >> 24;
    data[59] = bitlen >> 32;
    data[58] = bitlen >> 40;
    data[57] = bitlen >> 48;
    data[56] = bitlen >> 56;
    transform(data);

    for (i = 0; i < 4; ++i) {
        hash[i]      = (state[0] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 4]  = (state[1] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 8]  = (state[2] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 12] = (state[3] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 16] = (state[4] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 20] = (state[5] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 24] = (state[6] >> (24 - i * 8)) & 0x000000ff;
        hash[i + 28] = (state[7] >> (24 - i * 8)) & 0x000000ff;
    }
}

void SHA256::transform(const uint8_t data[BLOCK_SIZE]) {
    uint32_t a, b, c, d, e, f, g, h, i, j, t1, t2, m[64];

    for (i = 0, j = 0; i < 16; ++i, j += 4) {
        m[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | (data[j + 3]);
    }
    for (; i < 64; ++i) {
        m[i] = (m[i - 2] >> 17 | m[i - 2] << 15) ^ (m[i - 2] >> 19 | m[i - 2] << 13) ^ (m[i - 2] >> 10);
        m[i] += m[i - 7];
        m[i] += (m[i - 15] >> 7 | m[i - 15] << 25) ^ (m[i - 15] >> 18 | m[i - 15] << 14) ^ (m[i - 15] >> 3);
        m[i] += m[i - 16];
    }

    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];
    f = state[5];
    g = state[6];
    h = state[7];

    for (i = 0; i < 64; ++i) {
        t1 = h + ((e >> 6 | e << 26) ^ (e >> 11 | e << 21) ^ (e >> 25 | e << 7)) + ((e & f) ^ (~e & g)) + K[i] + m[i];
        t2 = ((a >> 2 | a << 30) ^ (a >> 13 | a << 19) ^ (a >> 22 | a << 10)) + ((a & b) ^ (a & c) ^ (b & c));
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }

    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
}