#ifndef JWTUTILS
#define JWTUTILS
#include <map>
#include <string>
#include "Base64.h"

std::string urlDecode(const std::string& str);

std::map<std::string, std::string> parseClaims(const std::string& claimsString);

std::string encode_base64(const std::string& text);

std::map<std::string, std::string> decode_base64(const std::string& text);
std::map<std::string, std::string> getClaims(const std::string& token);
#endif