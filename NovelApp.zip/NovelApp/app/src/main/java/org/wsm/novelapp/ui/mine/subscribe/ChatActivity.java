package org.wsm.novelapp.ui.mine.subscribe;

import static org.wsm.novelapp.common.Constants.GET_USER_BY_ID;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.service.SocketService.SEND_MESSAGE;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.ChatAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.broadcast.ChatBroadcastReceiver;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dao.ChatDao;
import org.wsm.novelapp.dao.UserDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.utils.RequestUtil;
import org.wsm.novelapp.service.SocketService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity implements View.OnClickListener {

    private int userId;//聊天对方的用户id
    private EditText et_chat_content;
    //聊天方的用户名
    private String userName;
    private Toolbar tb_subscriber_head;
    private Integer currentUserId;
    public List<Chat> datas = new ArrayList<>();
    private ChatBroadcastReceiver broadcastReceiver;
    private ChatAdapter chatAdapter;
    private ChatDao chatDao;
    private Integer currentPage = 0;
    private boolean isLoading = false;
    private long lastLoadTime = 0;
    private RecyclerView rv_chat;
    private int firstPosition;//recycleView的第一个位置
    //键盘防抖
    private long lastKeyboardEventTime = 0;
    //recycleView滑动防抖
    private long lastScrollerEventTime = 0;
    private static final long DEBOUNCE_TIME = 200; // 200毫秒

    //键盘是否弹出
    private boolean isKeyboardShow = false;
    //手机内是否还有聊天数据可加载
    private boolean isData = true;
    private String currentUserName;
    private GlobalApplication application;

    @SuppressLint({"MissingInflatedId", "NotifyDataSetChanged", "UnspecifiedRegisterReceiverFlag", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        application = (GlobalApplication) getApplication();
        //通知用户已经进入了ChatActivity
        application.setChatActivity(true);

        tb_subscriber_head = findViewById(R.id.tb_chat_head);

        tb_subscriber_head.setNavigationOnClickListener(view -> finish());

        et_chat_content = findViewById(R.id.et_chat_content);
        findViewById(R.id.btn_send_message).setOnClickListener(this);

        //已经获取焦点 再次点击触发点击事件
        et_chat_content.setOnClickListener(this);

        //RecyclerView填充数据
        rv_chat = findViewById(R.id.rv_chat);
        //当键盘弹出时，点击后关闭键盘
        rv_chat.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if(isKeyboardShow){
                    hideKeyboardFrom(this, et_chat_content);
                }
            }
            return false;
        });

        //设置布局
        rv_chat.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,true));
        //创建适配器
        chatAdapter = new ChatAdapter(this, datas);

        rv_chat.setAdapter(chatAdapter);
        rv_chat.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                assert layoutManager != null;
                firstPosition = layoutManager.findFirstVisibleItemPosition();
                int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();

                long now = System.currentTimeMillis();
                //倒数第二个出现的时候开始加载  并且加载时间间隔不超过DEBOUNCE_TIME  并且目前存在聊天数据
                if(lastVisibleItemPosition >= (datas.size() - 2) &&
                now - lastScrollerEventTime > DEBOUNCE_TIME && isData){
                    lastScrollerEventTime = now;
                    new Thread(() -> {
                        List<Chat> chats = chatDao.queryPart((++currentPage - 1) * 16,currentUserId,userId);

                        if(chats != null){
                            //数据少于16说明已经没有聊天数据
                            if(chats.size() < 16) isData = false;

                            for (Chat chat: chats){
                                chat.setContent(EncryptUtils.AESDecode(chat.getContent()));
                                datas.add(chat);
                            }
                            int startPosition = datas.size() - chats.size();
                            runOnUiThread(() -> {
                                chatAdapter.notifyItemRangeInserted(startPosition, chats.size());
                                //调整位置 防止一次刷新很多数据出来
                                layoutManager.scrollToPositionWithOffset(firstPosition, 0);
                            });
                        }else{
                            //chats == null说明已经没有聊天数据
                            isData = false;
                        }
                    }).start();
                }
            }
        });
        //监听键盘弹出
        et_chat_content.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                long now = System.currentTimeMillis();
                if (now - lastKeyboardEventTime < DEBOUNCE_TIME) {
                    return;
                }
                lastKeyboardEventTime = now;

                Rect r = new Rect();
                et_chat_content.getWindowVisibleDisplayFrame(r);

                int screenHeight = et_chat_content.getRootView().getHeight();
                int keypadHeight = screenHeight - r.bottom;
                // 判断键盘是否完全弹出（通常键盘高度大于屏幕高度的15%）
                if (keypadHeight > screenHeight * 0.15) {
                    isKeyboardShow = true;
                    // 键盘已完全弹出
                    rv_chat.scrollToPosition(0);
                }else{//键盘关闭
                    isKeyboardShow = false;
//                    rv_chat.scrollToPosition(0);
                }
            }
        });

        AppDatabase instance = AppDatabase.getInstance(this);

        chatDao = instance.chatDao();
        //首次进入加载16条sqllite里面的聊天记录
        Thread thread = new Thread(() -> {
            Log.d("===>id", "currentUserId: " + currentUserId + " userId:" + userId);
            List<Chat> chats = chatDao.queryPart((++currentPage - 1) * 16, currentUserId, userId);
            if (chats != null) {

                //数据少于16说明已经没有聊天数据
                if (chats.size() < 16) isData = false;

                for (Chat chat : chats) {
                    chat.setContent(EncryptUtils.AESDecode(chat.getContent()));
                    datas.add(chat);
                }
                runOnUiThread(() -> {
                    chatAdapter.notifyDataSetChanged();
                    if (chatAdapter.getItemCount() > 0) {
                        rv_chat.scrollToPosition(0);
                    }
                });
            } else {
                //chats == null说明已经没有聊天数据
                isData = false;
            }
        });

        User user = application.getUser();
        currentUserId = user.getId();
        //获取当前操作的用户id
        currentUserName = user.getUsername();

        //获取跳转过来传递的用户名
        userName = getIntent().getStringExtra("userName");
        //聊天对象的userId
        userId = getIntent().getIntExtra("userId", 0);

        thread.start();

        //注册广播
        broadcastReceiver = new ChatBroadcastReceiver(datas,chatAdapter,rv_chat);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("chat_broadcast_receiver");
        registerReceiver(broadcastReceiver,intentFilter);


        if(userName == null){//从服务器取出用户名   如果是弹窗点进来的userName是从sqllite查取的
            new Thread(() -> {
                requestUserData(currentUserId);
            }).start();
        }
        tb_subscriber_head.setTitle(userName == null ? "null" : userName);

    }

//    private void startTimer(){
//        new Timer().schedule(new TimerTask() {
//            @Override
//            public void run() {
//                Chat chat = new Chat();
//                chat.setContent("asddsa");
//
//            }
//        },1000,2000);
//    }
    private void requestUserData(Integer currentUserId){
        Map<String, String> map = new HashMap<>();
        map.put("userId",String.valueOf(userId));

        new RequestUtil(this, new RequestUtil.ResponseListen() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void handleResponse(Result result) throws IOException {

                if (result.getCode() == 1) {
                    Map<String, String> data = result.getData();
                    String userStr = data.get("user");

                    Type type = new TypeToken<User>(){}.getType();

                    User user = GSON.fromJson(userStr, type);

                    if(user != null){
                        //！！！！！！！！！！！！将请求到的用户数据放入sqllite!!!!!!!!!!!!!!
                        new Thread(() -> {
                            //加入到sqllite
                            UserDao userDao = AppDatabase.getInstance(ChatActivity.this).userDao();
                            user.setLoginUserId(currentUserId);
                            userDao.insert(user);
                        }).start();
                        userName = user.getUsername();
                        runOnUiThread(() -> tb_subscriber_head.setTitle(userName == null ? "null" : userName));
                    }
                }
            }
        }).GetRequest(map,GET_USER_BY_ID);
    }


    @SuppressLint("WrongConstant")
    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.btn_send_message){//发送消息

            String chatContent = et_chat_content.getText().toString();

            if(chatContent.isEmpty()) return;

            //对消息加密存储到sqllite
            String cipherContent = EncryptUtils.AESEncode(chatContent);

            et_chat_content.setText("");
            //将聊天的消息加入sqllite

            Chat chat = new Chat();
            chat.setContent(cipherContent);
            chat.setSend(true);
            chat.setSendTime(new Timestamp(System.currentTimeMillis()));
            chat.setUserId(currentUserId);//发送者id
            chat.setTargetId(userId);//接收放id
            chat.setUserName(currentUserName);
            new Thread(() -> chatDao.insert(chat)).start();

            Chat chat1 = new Chat(chat);
            chat1.setContent(chatContent);

            //将chat转为字符串然后aes加密
//            String cipher = EncryptUtils.AESEncode(CommonMethod.chatToString(chat1));
            String cipher = EncryptUtils.AESEncode("1&" + chat1);

//            webSocket.send(cipher);
            Log.d("====>", "发送消息");
            Intent socketServiceIntent = new Intent(this, SocketService.class);
            socketServiceIntent.putExtra("action",SEND_MESSAGE);
            socketServiceIntent.putExtra("message",cipher);
            startService(socketServiceIntent);

//            //发送消息出去
//            ChatViewModel.sendMessage(String.valueOf(userId),cipher);
            datas.add(0,chat1);
            chatAdapter.notifyItemInserted(0);
            rv_chat.smoothScrollToPosition(0);
        }else if(id == R.id.rv_chat && isKeyboardShow){//若键盘打开则关闭键盘
            hideKeyboardFrom(this, et_chat_content);
        }

    }

    /**
     * 关闭键盘
     * @param context
     * @param view
     */
    public void hideKeyboardFrom(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private RecyclerView.OnScrollListener scrollListener(){
        return new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (System.currentTimeMillis() - lastLoadTime < 1000) {
                    Log.d("======lastLoadTime", "return");
                    return;
                }

                isLoading = true;
                lastLoadTime = System.currentTimeMillis();

                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                if (layoutManager != null) {
                    int visibleItemCount = layoutManager.getChildCount();
                    int totalItemCount = layoutManager.getItemCount();
                    int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

                    Log.d("======visibleItemCount", visibleItemCount + "");
                    Log.d("======totalItemCount", totalItemCount + "");
                    Log.d("======firstVisibleItemPosition", firstVisibleItemPosition + "");
//                    if (!isLoading && !isLastPage) {
//                        if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount
//                                && firstVisibleItemPosition >= 0) {
//                            loadMoreData();
//                            // 加载完成后
//
//                        }
//                    }
                    isLoading = false;
                }

            }
        };
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("=====>", "ChatActivity onDestroy");
        unregisterReceiver(broadcastReceiver);

    }

    @Override
    protected void onResume() {
        super.onResume();
//        Log.d("=====>", "ChatActivity onResume");
//        Constants.isChatActivity = true;
        //通知用户重新进入ChatActivity
        application.setChatActivity(true);

    }

    @Override
    protected void onPause() {
        super.onPause();
//        Log.d("=====>", "ChatActivity onPause");
//        Constants.isChatActivity = false;
        //通知用户已经离开ChatActivity
        application.setChatActivity(false);
    }
}