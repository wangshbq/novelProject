package org.wsm.novelapp.utils;

import android.annotation.SuppressLint;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@SuppressLint("GetInstance")
public class AESUtil {

    public static String key = "GrJZ5nhHQDwnRr9syCuxeA==";

    public static String encrypt(String data) throws Exception {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;
        // 将 Base64 编码的密钥解码为字节数组
        byte[] decodedKey = Base64.getDecoder().decode(key);
        SecretKeySpec secretKey = new SecretKeySpec(decodedKey, "AES");

        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding"); // 指定模式和填充方式
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedData = cipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptedData); // 返回 Base64 编码的加密数据
    }

    public static String decrypt(String data) throws Exception {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;

        byte[] decodedKey = Base64.getDecoder().decode(key);
        SecretKeySpec secretKey = new SecretKeySpec(decodedKey, "AES");

        // 解码密文
        byte[] encryptedBytes = Base64.getDecoder().decode(data);

        // 创建 AES 解密器
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        // 解密
        byte[] original = cipher.doFinal(encryptedBytes);
        return new String(original, StandardCharsets.UTF_8);
    }

    public static String generateNewKey() throws Exception {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;

        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128); // 或者 192, 256 位
        SecretKey secretKey = keyGen.generateKey();
        return Base64.getEncoder().encodeToString(secretKey.getEncoded()); // 返回 Base64 编码的密钥
    }

//    public static void main(String[] args) throws Exception {
//        System.out.println(decrypt("172NIXIANG952SHI839SHA8242BISOAG1QUMowOsUr+sloBPxLZyPTC9K0P3XptgtO6POOU="));
////        toKdBZS3CP6LABH81Cl2XeJjOT7bqQNe6vkxWrdEb8M=
////        System.out.println(generateNewKey());
//    }


}
