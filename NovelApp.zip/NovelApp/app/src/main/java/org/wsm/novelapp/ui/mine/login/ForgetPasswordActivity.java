package org.wsm.novelapp.ui.mine.login;

import static org.wsm.novelapp.common.Constants.CHANGE_PASSWORD_URL;
import static org.wsm.novelapp.common.Constants.SEND_CAPTCHA_URL;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.utils.RequestUtil;

public class ForgetPasswordActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText et_reset_password_email;
    private EditText et_reset_password_new_password;
    private EditText et_reset_password_rePassword;
    private EditText et_reset_password_captcha;
    private RequestUtil defaultResponseReq;
    private Button btn_reset_password_send_captcha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        Toolbar tb_reset_password_head = findViewById(R.id.tb_reset_password_head);
        tb_reset_password_head.setNavigationOnClickListener(view -> finish());

        et_reset_password_email = findViewById(R.id.et_reset_password_email);
        et_reset_password_new_password = findViewById(R.id.et_reset_password_new_password);
        et_reset_password_rePassword = findViewById(R.id.et_reset_password_rePassword);
        et_reset_password_captcha = findViewById(R.id.et_reset_password_captcha);
        btn_reset_password_send_captcha = findViewById(R.id.btn_reset_password_send_captcha);
        btn_reset_password_send_captcha.setOnClickListener(this);
        findViewById(R.id.btn_reset_password_sure).setOnClickListener(this);

        //发送验证码 或 修改密码
        defaultResponseReq = new LoginUtils().handleDefaultResponse(this);
    }

    @Override
    public void onClick(View v) {
        String password = et_reset_password_new_password.getText().toString().trim();
        String rePassword = et_reset_password_rePassword.getText().toString().trim();


        String email = et_reset_password_email.getText().toString().trim();

        if(email.isEmpty()) {
            Toast.makeText(this, "邮箱不能为空", Toast.LENGTH_SHORT).show();
            return;
        } else if(password.isEmpty()){
            Toast.makeText(this,"密码不能为空",Toast.LENGTH_SHORT).show();
            return;
        }else if(!password.equals(rePassword)){
            Toast.makeText(this,"密码不同",Toast.LENGTH_SHORT).show();
            return;
        }


        if(!LoginUtils.emailFormVerify(email)){
            Toast.makeText(this,"邮箱格式错误",Toast.LENGTH_SHORT).show();
            return;
        }

        int id = v.getId();

        if(id == R.id.btn_reset_password_send_captcha){//发送验证码
            JSONObject jsonObject = new JSONObject();

            try {
                jsonObject.put("email",email);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            new Thread(() -> defaultResponseReq.PostRequest(jsonObject.toString(),SEND_CAPTCHA_URL)).start();

            new LoginUtils().forbidCaptchaButton(btn_reset_password_send_captcha);
        }else{//确认修改

            String captcha = et_reset_password_captcha.getText().toString().trim();
            if(captcha.isEmpty()){
                Toast.makeText(this,"验证码不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("email",email);
                jsonObject.put("password", EncryptUtils.SHA256(password));
                jsonObject.put("captcha",captcha);
            } catch (Exception e) {
                e.printStackTrace();
            }

            new Thread(() -> defaultResponseReq.PostRequest(jsonObject.toString(),CHANGE_PASSWORD_URL)).start();
        }
    }
}