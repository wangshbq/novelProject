package org.wsm.novelapp.bean;

import java.util.Date;

public class ContentManagerBean {
    //novelId
    private Integer id;
    private String title;
    private Date createTime;
    private Integer wordCount;
    private String content;
    //0未发布 1已发布 2已删除
    private Integer status;
    private String isRelease;
    //是否显示ShowCheckBox
    private boolean isShowCheckBox;
    //是否选中
    private boolean isSelected;


    public ContentManagerBean() {

    }

    public boolean isShowCheckBox() {
        return isShowCheckBox;
    }

    public void setShowCheckBox(boolean showCheckBox) {
        isShowCheckBox = showCheckBox;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getIsRelease() {
        return isRelease;
    }

    public void setIsRelease(String isRelease) {
        this.isRelease = isRelease;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getWordCount() {
        return wordCount;
    }

    public void setWordCount(Integer wordCount) {
        this.wordCount = wordCount;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ContentManagerBean{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", createTime=" + createTime +
                ", wordCount=" + wordCount +
                ", content='" + content + '\'' +
                ", status=" + status +
                '}';
    }
}
