package org.wsm.novelapp.ui.home;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.wsm.novelapp.R;
import org.wsm.novelapp.ui.mine.subscribe.ChatActivity;

public class PersonCenterActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_user_name;
    private Integer userId;
    private String userName;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_center);

        Toolbar tb_second_comment_head = findViewById(R.id.tb_person_center_head);
        tb_second_comment_head.setNavigationOnClickListener(view -> {
            finish();
        });

        findViewById(R.id.btn_chat).setOnClickListener(this);



        tv_user_name = findViewById(R.id.tv_user_name);

        Intent intent = getIntent();
        userId = intent.getIntExtra("authorUserId",0);
        userName = intent.getStringExtra("authorName");

        tv_user_name.setText(userName);


    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.btn_chat){
            Intent intent = new Intent(this, ChatActivity.class);
            intent.putExtra("userName",userName);
            intent.putExtra("userId",userId);
            startActivity(intent);
        }
    }
}