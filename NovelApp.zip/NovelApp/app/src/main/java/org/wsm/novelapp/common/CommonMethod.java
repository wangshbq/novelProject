package org.wsm.novelapp.common;

import android.app.Activity;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.utils.UrlUtils;

import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Map;

public class CommonMethod {

    private static final Type userType;
    private static final Type mapType;

    public static Gson gson;

    static {
        userType = new TypeToken<User>() {}.getType();
        mapType = new TypeToken<Map<String,String>>() {}.getType();
        gson = new Gson();
    }

    public static String chatToString(Chat chat){
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(UrlUtils.urlEncode(chat.getContent()));
        stringBuilder.append("&");
        stringBuilder.append(chat.getUserId());
        stringBuilder.append("&");
        stringBuilder.append(chat.getTargetId());
        stringBuilder.append("&");
        stringBuilder.append(chat.getSendTime().getTime());
        stringBuilder.append("&");
        stringBuilder.append(chat.getUserName());
        return stringBuilder.toString();
    }

    public static Chat stringToChat(String str){
        String[] split = str.split("&");
        if(split.length != 5) return null;

        Chat chat = new Chat();
        chat.setSend(false);
        String content = UrlUtils.urlDecode(split[0]);
        chat.setContent(content);
        chat.setUserId(Integer.parseInt(split[1]));
        chat.setTargetId(Integer.parseInt(split[2]));
        chat.setSendTime(new Timestamp(Long.parseLong(split[3])));
        chat.setUserName(split[4]);

        return chat;
    }

    public static User stringToUser(String str){
        return gson.fromJson(str, userType);
    }


    public static Map<String,String> stringToMap(String str){
        return gson.fromJson(str, mapType);
    }

    /**
     * 处理时间为适合展示的格式
     * @param time 2025-05-10 13:18:43.0
     * @return
     */
    public static String handleShowTime(String time){
        // 获取当前时间的 LocalDateTime 实例
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return "";

        LocalDateTime now = LocalDateTime.now();

        // 获取年、月、日、时、分、秒
        int year = now.getYear();
        int month = now.getMonthValue(); // 月份从 1 开始
        int day = now.getDayOfMonth();

        StringBuilder showTime = new StringBuilder();
        //2025-05-10 13:18:43.0
        String[] split = time.split(" ");

        //2025-05-10
        String[] split1 = split[0].split("-");

        //年
        if(Integer.parseInt(split1[0]) != year){
            showTime.append(split1[0]).append("-");
        }
        //月日
        if(Integer.parseInt(split1[1]) != month || Integer.parseInt(split1[2]) != day){
            showTime.append(split1[1]).append("-").append(split1[2]).append(" ");
        }

        //13:18:43.0
        String[] split2 = split[1].split(":");

        showTime.append(split2[0]).append(":").append(split2[1]);

        return showTime.toString();
    }


}
