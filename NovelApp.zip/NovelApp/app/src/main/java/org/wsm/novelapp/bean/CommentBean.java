package org.wsm.novelapp.bean;

import java.util.Date;

public class CommentBean {
    private Integer userId;
    private Integer commentId;
    private Integer novelId;
    private String userName;
    private String commentContent;
    private Date publishTime;
    private Integer thumbUpNumber;
    //对谁的回复
    private String replyUserName;
    //定位
    private String location;
    private Integer isThumbsUp;
    private Integer parentId;
    //当前评论下面二级评论数量
    private Integer secondCommentNumber;

    public CommentBean() {
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getReplyUserName() {
        return replyUserName;
    }

    public void setReplyUserName(String replyUserName) {
        this.replyUserName = replyUserName;
    }

    public Integer getSecondCommentNumber() {
        return secondCommentNumber;
    }

    public void setSecondCommentNumber(Integer secondCommentNumber) {
        this.secondCommentNumber = secondCommentNumber;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getIsThumbsUp() {
        return isThumbsUp;
    }

    public void setIsThumbsUp(Integer isThumbsUp) {
        this.isThumbsUp = isThumbsUp;
    }

    public Integer getCommentId() {
        return commentId;
    }

    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }

    public Integer getNovelId() {
        return novelId;
    }

    public void setNovelId(Integer novelId) {
        this.novelId = novelId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCommentContent() {
        return commentContent;
    }

    public void setCommentContent(String commentContent) {
        this.commentContent = commentContent;
    }

    public Date getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(Date publishTime) {
        this.publishTime = publishTime;
    }

    public Integer getThumbUpNumber() {
        return thumbUpNumber;
    }

    public void setThumbUpNumber(Integer thumbUpNumber) {
        this.thumbUpNumber = thumbUpNumber;
    }



    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "CommentBean{" +
                "commentId=" + commentId +
                ", novelId=" + novelId +
                ", userName='" + userName + '\'' +
                ", commentContent='" + commentContent + '\'' +
                ", publishTime=" + publishTime +
                ", thumbUpNumber=" + thumbUpNumber +
                ", replyUserName='" + replyUserName + '\'' +
                ", location='" + location + '\'' +
                ", isThumbsUp=" + isThumbsUp +
                ", parentId=" + parentId +
                ", secondCommentNumber=" + secondCommentNumber +
                '}';
    }
}
