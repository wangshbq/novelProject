#ifndef BASE64_H
#define BASE64_H

#include <cstdint>
#include <string>
#include <vector>

class Base64 {
public:
    // Base64 编码
    static std::string encode(const std::vector<uint8_t>& data);

    // Base64 解码
    static std::vector<uint8_t> decode(const std::string& encoded);

private:
    // Base64 字符表
    static const std::string base64Chars;

    // Base64 填充字符
    static const char base64Pad;

    // 检查字符是否是有效的 Base64 字符
    static bool isBase64(char c);
};

#endif // BASE64_H