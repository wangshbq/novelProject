package org.wsm.novelapp.ui.home;

import static android.app.Activity.RESULT_OK;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.LOAD_NOVEL_PART_URL;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.clearLoginData;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.gson.reflect.TypeToken;
import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.HomeEntryAdapter;
import org.wsm.novelapp.bean.HomeEntryBean;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.utils.RequestUtil;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class HomeFragment extends Fragment implements View.OnClickListener {

    private final List<HomeEntryBean> datas = new ArrayList<>();
    private HomeEntryAdapter homeEntryAdapter;
    private RecyclerView rv_home_entry_list;
    private RequestUtil pageReq;
    private List<Integer> ids;
    private Activity context;
    RequestUtil testReq;
    private Thread thread;
    //0随机 1最新 2评论
    private Integer sort = 0;
    private long lastLoadTime = 0; // 记录上次加载的时间
    private static final long LOAD_THRESHOLD = 1000; // 1秒内只加载一次
    private boolean isBottomRemind = false;
    private int currentPage = 0;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    @Nullable
    @SuppressLint({"MissingInflatedId", "NotifyDataSetChanged"})
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        context = requireActivity();

        // 注册 ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        //发表过评论返回之后 增加评论数量
                        String commentNumber = result.getData().getStringExtra("commentNumber");
                        Integer position = homeEntryAdapter.getPosition();
                        HomeEntryBean homeEntryBean = datas.get(position);
                        homeEntryBean.setCommentNumber(Integer.parseInt(commentNumber));
                        context.runOnUiThread(() -> homeEntryAdapter.notifyDataSetChanged());
                    }
                }
        );


        //下拉刷新控件
        SwipeRefreshLayout sr_home_entry_list = root.findViewById(R.id.sr_home_entry_list);
        //列表展示控件
        rv_home_entry_list = root.findViewById(R.id.rv_home_entry_list);

        rv_home_entry_list.setLayoutManager(new LinearLayoutManager(context,RecyclerView.VERTICAL,false));
        //适配器
        homeEntryAdapter = new HomeEntryAdapter(context, datas,activityResultLauncher);
        //控件绑定适配器
        rv_home_entry_list.setAdapter(homeEntryAdapter);

        //存储页面item的id
        ids = new ArrayList<>();
        ids.add(0);

        //下拉刷新
        sr_home_entry_list.setOnRefreshListener(() -> {
            resumeData(0);
            //停止刷新动画
            sr_home_entry_list.setRefreshing(false);
        });

        //上滑刷新
        rv_home_entry_list.addOnScrollListener(new RecyclerView.OnScrollListener(){
            @Override
            public void  onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if(dy <= 0) return;
                // 获取布局管理器
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                // 获取当前可见的 item 数量
                int visibleItemCount = Objects.requireNonNull(layoutManager).getChildCount();

                // 获取总的 item 数量
                int totalItemCount = layoutManager.getItemCount();

                // 获取第一个可见的 item 的位置
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

                if ((visibleItemCount + firstVisibleItemPosition) >= (totalItemCount - 1)) {
                    long currentTime = System.currentTimeMillis();
                    // && isScrolled.compareAndSet(true,false)
                    if(currentTime - lastLoadTime > LOAD_THRESHOLD){
                        lastLoadTime = currentTime;
                        // 加载更多数据
                        loadPage(sort);
                    }
                }
            }
        });

        //最新
        root.findViewById(R.id.tv_new).setOnClickListener(this);
        root.findViewById(R.id.tv_comment).setOnClickListener(this);
        root.findViewById(R.id.iv_search_icon).setOnClickListener(this);

        testReq = new RequestUtil(context, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {
                context.runOnUiThread(() -> Toast.makeText(context, result.getMsg(), Toast.LENGTH_SHORT).show());

                if(result.getCode() == 2){
                     clearLoginData(requireActivity());
                 }
            }
        });

        pageReq = new RequestUtil(context, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {
                if(result.getCode() != 1){//失败 或 token失效
                    context.runOnUiThread(() -> Toast.makeText(context,result.getMsg(),Toast.LENGTH_SHORT).show());
                }else if(result.getCode() == 1){//成功
                    Map<String, String> map = result.getData();
                    String novels = map.get("NovelDtos");
                    Type novelsType = new TypeToken<List<NovelDto>>() {}.getType();

                    List<NovelDto> novelList = GSON.fromJson(novels, novelsType);

                    HomeEntryBean homeEntry;
                    for(NovelDto novel: Objects.requireNonNull(novelList)){

                        homeEntry = new HomeEntryBean();
                        homeEntry.setTitle("setTitle: " + novel.getTitle());
                        homeEntry.setAuthorName("author: " + novel.getUsername());
                        homeEntry.setContent("setContent: " + novel.getContent());
                        homeEntry.setCommentNumber(novel.getCommentNumber() == null ? 0 : novel.getCommentNumber());
                        homeEntry.setPageViews(novel.getPageViews() == null ? 0 : novel.getPageViews());
                        homeEntry.setTime(novel.getCreateTime());
                        homeEntry.setNovelId(novel.getId());
                        homeEntry.setUserId(novel.getUserId());
                        datas.add(homeEntry);

                    }
                    context.runOnUiThread(() -> homeEntryAdapter.notifyDataSetChanged());

                    //如发现服务器返回数据小于8，说明已经到底，之后请求通过isBottomRemind判断无需请求
                    if (Objects.requireNonNull(novelList).size() < 8){
                        isBottomRemind = true;
                        context.runOnUiThread(() -> Toast.makeText(context,"已经到底部了",Toast.LENGTH_SHORT).show());
                    }
                }
            }
        });
        loadPage(sort);
        try {
            thread.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


        return root;

    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.tv_new){
            if(sort == 1) return;
            rv_home_entry_list.scrollToPosition(0);
            resumeData(1);

        }else if(id == R.id.tv_comment){
            if(sort == 2) return;
            rv_home_entry_list.scrollToPosition(0);
            resumeData(2);
        }else if(id == R.id.iv_search_icon){
            LinearLayoutManager layoutManager = (LinearLayoutManager)rv_home_entry_list.getLayoutManager();
            // 获取当前可见的 item 数量
            int visibleItemCount = Objects.requireNonNull(layoutManager).getChildCount();

            // 获取总的 item 数量
            int totalItemCount = layoutManager.getItemCount();

            // 获取第一个可见的 item 的位置
            int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

            Toast.makeText(getActivity(),"获取当前可见的 item 数量: " + visibleItemCount + "\n获取总的 item 数量: " + totalItemCount + "\n获取第一个可见的 item 的位置: " + firstVisibleItemPosition,Toast.LENGTH_LONG).show();
        }
    }


    public void loadPage(int sort){
        //若到底则return
        if(isBottomRemind) return;

        JSONObject jsonObject = new JSONObject();
        try {

            currentPage++;
            ids.set(0,(currentPage - 1) * 8);
            //sort 0随机  //1最新  2评论
            String idsString = ids.toString();
            jsonObject.put("ids",idsString);

            jsonObject.put("sortNumber",sort);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        thread = new Thread(() -> pageReq.PostRequest(jsonObject.toString(), LOAD_NOVEL_PART_URL));
        thread.start();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void resumeData(int sort){
        datas.clear();
        ids.clear();

        this.sort = sort;
        ids.add(0);
        isBottomRemind = false;
        currentPage = 0;
        loadPage(sort);
    }

}
