package org.wsm.novelapp.model;

import static org.wsm.novelapp.utils.RequestUtil.getToken;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import org.wsm.novelapp.bean.Chat;


public class ChatViewModel extends AndroidViewModel {

    private final MutableLiveData<String> messageLiveData = new MutableLiveData<>();

    public ChatViewModel(Application application) {
        super(application);
        nativeInit(getToken()); // 初始化 Native 层
    }

    static {
        System.loadLibrary("chatUtils");
    }

    public static native boolean initConnect();

    public native void nativeInit(String token);

    public static native void sendMessage(String userId,String message);

    public static native void stopConnect();

    public static native boolean isConnected();

    // 供 JNI 调用的方法
    public void postMessageFromNative(String message) {
        messageLiveData.postValue(message);
    }

    public MutableLiveData<String> getMessageLiveData() {
        return messageLiveData;
    }
}
