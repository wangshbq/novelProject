package org.wsm.novelapp.ui.mine.subscribe;

import static org.wsm.novelapp.common.Constants.GET_SUBSCRIBE_ALL;
import static org.wsm.novelapp.common.Constants.GSON;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.ContentManagerAdapter;
import org.wsm.novelapp.adapter.ShowSubscriberAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.ShowSubscriberBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.bean.UserDetail;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dao.UserDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ShowSubscriberActivity extends AppCompatActivity {

    private final List<ShowSubscriberBean> datas = new ArrayList<>();
    private ShowSubscriberAdapter showSubscriberAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_subscriber);

        Toolbar tb_subscriber_head = findViewById(R.id.tb_subscriber_head);
        tb_subscriber_head.setNavigationOnClickListener(view -> finish());

        //RecyclerView填充数据
        RecyclerView rv_subscriber_list = findViewById(R.id.rv_subscriber_list);
        //设置布局
        rv_subscriber_list.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,false));
        //创建适配器
        showSubscriberAdapter = new ShowSubscriberAdapter(this, datas);

        rv_subscriber_list.setAdapter(showSubscriberAdapter);

        requestSubscribeData();
    }

    private void requestSubscribeData(){
        GlobalApplication application = (GlobalApplication) getApplication();
        User user = application.getUser();
        if(user == null){
            Log.d("======user", "null");
            return;
        }
        Integer userId = application.getUser().getId();

        SharedPreferences preferences = getSharedPreferences("userData:" + userId, MODE_PRIVATE);
        String subscribeText = preferences.getString("subscribeText", "");

        String[] split = subscribeText.split(",");
        List<String> userIds = Arrays.asList(split);

        if(userIds.size() == 1 && userIds.get(0).isEmpty()) return;

        new Thread(() -> {
            JSONObject jsonObject = new JSONObject();

            try {
                jsonObject.put("userIds",userIds.toString());
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            new RequestUtil(this, new RequestUtil.ResponseListen() {
                @SuppressLint("NotifyDataSetChanged")
                @Override
                public void handleResponse(Result result) throws IOException {

                    if (result.getCode() == 1) {
                        Map<String, String> data = result.getData();
                        String users = data.get("users");

                        Type type = new TypeToken<List<User>>(){}.getType();

                        List<User> userList = GSON.fromJson(users, type);

                        if(userList != null){
                            //加入到sqllite
                            UserDao userDao = AppDatabase.getInstance(ShowSubscriberActivity.this).userDao();


                            for (User user: userList){
                                ShowSubscriberBean showSubscriberBean = new ShowSubscriberBean();
                                showSubscriberBean.setUserId(user.getId());
                                showSubscriberBean.setUserName(user.getUsername());
                                datas.add(showSubscriberBean);
                                user.setLoginUserId(userId);
                            }

                            new Thread(() -> userDao.insert(userList.toArray(new User[0]))).start();

                            runOnUiThread(() ->  showSubscriberAdapter.notifyDataSetChanged());
                        }

                    }
                }
            }).PostRequest(jsonObject.toString(),GET_SUBSCRIBE_ALL);
        }).start();

    }
}