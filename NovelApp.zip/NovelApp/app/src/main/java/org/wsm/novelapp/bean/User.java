package org.wsm.novelapp.bean;


import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity
public class User implements Serializable {

    @PrimaryKey
    private Integer id;
    private String username;
    private String password;
    private String personalSign; //个人签名
    private String gender;//性别
    private String province;//省份
    private String city;//市
    private String personalIntroduce;//个人介绍
    private String authorities;//权限
    private String image;//头像
    private Boolean enabled;
    private String email;
    private Integer loginUserId;//当前存储在sqllite的这条数据是属于谁的

//    @Ignore
    public User(){

    }



    public User(User user) {
        this.id = user.id;
        this.username = user.username;
        this.password = user.password;
        this.personalSign = user.personalSign;
        this.gender = user.gender;
        this.province = user.province;
        this.city = user.city;
        this.personalIntroduce = user.personalIntroduce;
        this.authorities = user.authorities;
        this.image = user.image;
        this.enabled = user.enabled;
        this.email = user.email;
        this.loginUserId = user.loginUserId;
    }

    public Integer getLoginUserId() {
        return loginUserId;
    }

    public void setLoginUserId(Integer loginUserId) {
        this.loginUserId = loginUserId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPersonalSign() {
        return personalSign;
    }

    public void setPersonalSign(String personalSign) {
        this.personalSign = personalSign;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPersonalIntroduce() {
        return personalIntroduce;
    }

    public void setPersonalIntroduce(String personalIntroduce) {
        this.personalIntroduce = personalIntroduce;
    }

    public String getAuthorities() {
        return authorities;
    }

    public void setAuthorities(String authorities) {
        this.authorities = authorities;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", personalSign='" + personalSign + '\'' +
                ", gender='" + gender + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", personalIntroduce='" + personalIntroduce + '\'' +
                ", authorities='" + authorities + '\'' +
                ", image='" + image + '\'' +
                ", enabled=" + enabled +
                ", email='" + email + '\'' +
                '}';
    }
}
