package org.wsm.novelapp.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.dto.NovelDto;

import java.util.List;

@Dao
public interface ChatDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Chat... chats);

    @Query("SELECT * FROM chat " +
            "where (isSend = 1 and userId = :userId and targetId = :targetId) or " +
            "(isSend = 0 and targetId = :userId and userId = :targetId) " +
            "ORDER BY sendTime DESC limit :page,16")
    List<Chat> queryPart(int page,int userId,int targetId);
}
