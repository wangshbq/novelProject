package org.wsm.novelapp.ui.mine.create;

import static org.wsm.novelapp.common.Constants.DELETE_SELECTION;
import static org.wsm.novelapp.common.Constants.GET_HISTORY_NOVEL;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.utils.RequestUtil.TOKEN;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.ContentManagerAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.ContentManagerBean;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dao.NovelDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.dto.NovelDto;
import org.wsm.novelapp.nativ.TokenGen;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;


public class ContentManagerActivity extends AppCompatActivity implements View.OnClickListener {

    private NovelDao novelDao;
    //打开草稿的时候展示的当前页
    int currentPage = 1;
    //判断是否草稿还有数据
    boolean isDraftData = true;
    public ArrayList<ContentManagerBean> datas = new ArrayList<>();
    private ContentManagerAdapter contentManagerAdapter;
    private long lastLoadTime = 0; // 记录上次加载的时间
    private static final long LOAD_THRESHOLD = 200; // 200毫秒内只加载一次

    private ActivityResultLauncher<Intent> activityResultLauncher;
    private SwipeRefreshLayout sr_content_list;
    private TextView tv_content_all;
    private TextView tv_content_publish;
    private TextView tv_content_non_publish;
    //0全部  1已发布  2未发布
    private int showContentSign = 0;
    private RecyclerView rv_content_list;
    private Button btn_sure_delete;
    private Button btn_all_select;
    //是否是点击了管理可以删除的状态
    private boolean isManager = false;
    private TextView tv_content_manager;
    //全选或全取消
    private boolean selectAll = false;
    private int userId;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_manager);

        Toolbar tb_content_manager_head = findViewById(R.id.tb_content_manager_head);
        tb_content_manager_head.setNavigationOnClickListener(view -> finish());

        AppDatabase instance = AppDatabase.getInstance(this);
        novelDao = instance.novelDao();

        rv_content_list = findViewById(R.id.rv_content_list);
        sr_content_list = findViewById(R.id.sr_content_list);
        //全部
        tv_content_all = findViewById(R.id.tv_content_all);
        //已发布
        tv_content_publish = findViewById(R.id.tv_content_publish);
        //未发布
        tv_content_non_publish = findViewById(R.id.tv_content_non_publish);
        //删除按钮
        btn_sure_delete = findViewById(R.id.btn_sure_delete);
        //全选
        btn_all_select = findViewById(R.id.btn_all_select);

        tv_content_all.setOnClickListener(this);
        tv_content_publish.setOnClickListener(this);
        tv_content_non_publish.setOnClickListener(this);
        tv_content_manager = findViewById(R.id.tv_content_manager);
        tv_content_manager.setOnClickListener(this);
        btn_all_select.setOnClickListener(this);
        btn_sure_delete.setOnClickListener(this);
        //下拉刷新
        sr_content_list.setOnRefreshListener(this::refreshData);

        // 注册 ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    refreshData();
                }
            }
        );

        //RecyclerView填充数据
        RecyclerView rv_content_list = findViewById(R.id.rv_content_list);
        //设置布局
        rv_content_list.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,false));
        //创建适配器
        contentManagerAdapter = new ContentManagerAdapter(this, datas,activityResultLauncher,isManager);

        rv_content_list.setAdapter(contentManagerAdapter);

        //上滑刷新
        rv_content_list.addOnScrollListener(new RecyclerView.OnScrollListener(){
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void  onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if(dy <= 0) return;
                // 获取布局管理器
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                // 获取当前可见的 item 数量
                int visibleItemCount = Objects.requireNonNull(layoutManager).getChildCount();

                // 获取总的 item 数量
                int totalItemCount = layoutManager.getItemCount();

                // 获取第一个可见的 item 的位置
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

                if ((visibleItemCount + firstVisibleItemPosition) >= (totalItemCount - 1)) {
                    long currentTime = System.currentTimeMillis();
                    // && isScrolled.compareAndSet(true,false)
                    if(currentTime - lastLoadTime > LOAD_THRESHOLD){
                        lastLoadTime = currentTime;
                        // 加载更多数据
                        if(isDraftData){
                            // 使用 RecyclerView.post 延迟执行
                            recyclerView.post(() -> {
                                getContentData();
                            });
                        }
                    }
                }
            }
        });

        GlobalApplication application = (GlobalApplication) getApplication();
        userId = application.getUser().getId();

        getContentData();
    }
    @SuppressLint("CommitPrefEdits")
    public void getContentData(){

        SharedPreferences preferences = getSharedPreferences("novelConfig:" + userId, MODE_PRIVATE);

        if(showContentSign == 0){//全部
            String string = preferences.getString("isRequest", "");

            //只有第一次安装软件从服务器拿数据，之后的查询都从手机内加载数据
            if(string.isEmpty()){//第一次请求服务器拿数据
                getNovelByServer();

            }else if(!string.equals("0")){//已经从服务器取过数据，但可能取不全
                //已从服务器拿到了多少页的数据在sqllite
                int serverPage = Integer.parseInt(string);

                if(currentPage <= serverPage){//直接从sqllite取数据
                    getNovelBySqlLite();

                }else{//从服务器取数据
                    getNovelByServer();
                }
            }else{//从手机内取数据
                getNovelBySqlLite();
            }
        }else if(showContentSign == 1){//已发布
            String string = preferences.getString("isRequestRelease", "");

            preGetContentReleaseData(string);

        }else{//未发布
            String string = preferences.getString("isRequestNonRelease", "");
            preGetContentReleaseData(string);
        }

    }

    private void preGetContentReleaseData(String isRequestRelease){
        if(isRequestRelease.isEmpty()){//第一次请求服务器拿数据
            getReleaseNovelByServer();
        }else if(!isRequestRelease.equals("0")){//已经从服务器取过数据，但可能取不全
            //已从服务器拿到了多少页的数据在sqllite
            int serverPage = Integer.parseInt(isRequestRelease);

            if(currentPage <= serverPage){//直接从sqllite取数据
                getNovelBySqlLite();

            }else{//从服务器取数据
                getReleaseNovelByServer();
            }
        }else{//从手机内取数据
            getNovelBySqlLite();
        }
    }

    private void getReleaseNovelByServer(){
        SharedPreferences preferences = getSharedPreferences("novelConfig:" + userId, MODE_PRIVATE);
        SharedPreferences.Editor edit = preferences.edit();
        RequestUtil requestUtil = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() == 1){
                    Map<String, String> data = result.getData();
                    String novelDtos = data.get("novelDtos");
                    Type type = new TypeToken<List<NovelDto>>() {}.getType();
                    //获取novel数据
                    List<NovelDto> novelList = GSON.fromJson(novelDtos, type);

                    if(Objects.requireNonNull(novelList).size() < 8){
                        //0全部  1已发布  2未发布
                        if(showContentSign == 1){
                            edit.putString("isRequestRelease","0");
                        }else if(showContentSign == 2){
                            edit.putString("isRequestNonRelease","0");
                        }

                    }else{
                        if(showContentSign == 1){
                            edit.putString("isRequestRelease",currentPage + "");
                        }else if(showContentSign == 2){
                            edit.putString("isRequestNonRelease",currentPage + "");
                        }
                    }
                    edit.apply();
                    //将服务器请求的数据插入sqllite
                    new Thread(() -> novelDao.insert(novelList.toArray(new NovelDto[0]))).start();

                    handleGetNovelDto(novelList);

                } else {
                    runOnUiThread(() -> Toast.makeText(ContentManagerActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }
            }
        });

        Map<String, String> params = new HashMap<>();
        params.put("currentPage",currentPage + "");
        params.put("status",showContentSign + "");
        requestUtil.GetRequest(params,GET_HISTORY_NOVEL);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void handleGetNovelDto(List<NovelDto> novelDtos){
        if(novelDtos.size() < 8) isDraftData = false;

        for (NovelDto novelDto: novelDtos){
            ContentManagerBean contentManagerBean = new ContentManagerBean();
            String content = novelDto.getContent();
            int length = content.length();

            if(length >= 20){
                contentManagerBean.setContent(content.substring(0,19));
            }else{
                contentManagerBean.setContent(content);
            }
            Integer status = novelDto.getStatus();
            contentManagerBean.setTitle(novelDto.getTitle());
            contentManagerBean.setCreateTime(novelDto.getCreateTime());
            contentManagerBean.setWordCount(length);
            contentManagerBean.setId(novelDto.getId());
            contentManagerBean.setStatus(status);
            contentManagerBean.setSelected(selectAll);
            contentManagerBean.setShowCheckBox(isManager);

            if(status == 0){//未发布
                contentManagerBean.setIsRelease("未发布");
            }else{
                contentManagerBean.setIsRelease("已发布");
            }
            datas.add(contentManagerBean);

        }
        currentPage++;
        runOnUiThread(() -> contentManagerAdapter.notifyDataSetChanged());
    }


    private void getNovelByServer(){
        SharedPreferences preferences = getSharedPreferences("novelConfig:" + userId, MODE_PRIVATE);
        SharedPreferences.Editor edit = preferences.edit();
        RequestUtil requestUtil = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if (result.getCode() == 1) {
                    Map<String, String> data = result.getData();
                    String novelDtos = data.get("novelDtos");
                    Type type = new TypeToken<List<NovelDto>>() {}.getType();
                    //获取novel数据
                    List<NovelDto> novelList = GSON.fromJson(novelDtos, type);

                    if(Objects.requireNonNull(novelList).size() < 8){
                        edit.putString("isRequest","0");
                        edit.putString("isRequestRelease","0");
                        edit.putString("isRequestNonRelease","0");
                    }else{
                        edit.putString("isRequest",currentPage + "");
                    }
                    edit.apply();
                    //将服务器请求的数据插入sqllite
                    new Thread(() -> novelDao.insert(novelList.toArray(new NovelDto[0]))).start();

                    handleGetNovelDto(novelList);

                } else {
                    runOnUiThread(() -> Toast.makeText(ContentManagerActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }
            }
        });

        Map<String, String> params = new HashMap<>();
        params.put("currentPage",currentPage + "");
        params.put("status",showContentSign + "");
        requestUtil.GetRequest(params,GET_HISTORY_NOVEL);
    }

    private void getNovelBySqlLite(){
        AtomicReference<List<NovelDto>> novelDtos = new AtomicReference<>();
        Thread thread = new Thread(() -> {
//            GlobalApplication application = (GlobalApplication) getApplication();
//            Integer id = application.getUser().getId();
            Map<String, String> map = TokenGen.decodeBase64(TOKEN);
            int userId = Integer.parseInt(map.get("userId"));
            //0全部  1已发布  2未发布
            if(showContentSign == 0){
                novelDtos.set(novelDao.queryEight(userId,(currentPage - 1) * 8));
            }else if(showContentSign == 1){
                novelDtos.set(novelDao.queryByStatus(1,userId,(currentPage - 1) * 8));
            }else if(showContentSign == 2){
                novelDtos.set(novelDao.queryByStatus(0,userId,(currentPage - 1) * 8));
            }

        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        handleGetNovelDto(novelDtos.get());
    }

    /**
     * 下拉刷新
     */
    private void refreshData(){
        preRefreshData();
        getContentData();
        sr_content_list.setRefreshing(false);
    }

    private void preRefreshData(){
        datas.clear();
        currentPage = 1;
        isDraftData = true;
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onClick(View v) {
        int id = v.getId();
        int color = ContextCompat.getColor(this, R.color.black);

        if(id == R.id.tv_content_all && showContentSign != 0){//全部
            resumeDeleteMode();
            resumeShowContentSign();
            showContentSign = 0;
            tv_content_all.setTextColor(color);
            rv_content_list.scrollToPosition(0); // 滚动到最顶部
            preRefreshData();

            getContentData();

        }else if(id == R.id.tv_content_publish && showContentSign != 1){//已发布
            resumeDeleteMode();
            resumeShowContentSign();
            showContentSign = 1;
            tv_content_publish.setTextColor(color);
            rv_content_list.scrollToPosition(0); // 滚动到最顶部
            preRefreshData();
            getContentData();

        }else if(id == R.id.tv_content_non_publish && showContentSign != 2){//未发布
            resumeDeleteMode();
            resumeShowContentSign();
            showContentSign = 2;
            tv_content_non_publish.setTextColor(color);
            rv_content_list.scrollToPosition(0); // 滚动到最顶部
            preRefreshData();

            getContentData();

        }else if(id == R.id.tv_content_manager){//管理
            if(isManager){//关闭可以选中删除的状态

                resumeDeleteMode();
            }else{
                tv_content_manager.setText("取消");
                btn_sure_delete.setVisibility(View.VISIBLE);
                btn_all_select.setVisibility(View.VISIBLE);
                for (ContentManagerBean contentManagerBean: datas){
                    contentManagerBean.setShowCheckBox(true);
                }
                contentManagerAdapter.notifyDataSetChanged();
                changeIsManger(!isManager);
            }


        }else if(id == R.id.btn_sure_delete){//删除按钮
            List<Integer> ids = new ArrayList<>();

            for (ContentManagerBean contentManagerBean: datas){
                if(contentManagerBean.isSelected()){
                    if(contentManagerBean.getStatus() == 1){//已发布
                        Toast.makeText(this,"只有未发布才可删除",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    ids.add(contentManagerBean.getId());
                }
            }


            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setTitle("删除");
            builder.setMessage("确定删除?");


            builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    new Thread(() -> {

                        new RequestUtil(ContentManagerActivity.this, new RequestUtil.ResponseListen() {
                            @Override
                            public void handleResponse(Result result) throws IOException {

                                runOnUiThread(() -> Toast.makeText(ContentManagerActivity.this,result.getMsg(),Toast.LENGTH_SHORT).show());
                                if(result.getCode() == 1){
                                    runOnUiThread(() -> {
                                        resumeDeleteMode();
                                        //更新数据
                                        refreshData();
                                    });

                                    //删除手机内数据
                                    novelDao.deleteByIds(ids);
                                }
                            }
                        }).PostRequest(ids.toString(),DELETE_SELECTION);

                    }).start();

                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();

        }else if(id == R.id.btn_all_select){//全选按钮
            selectAll = !selectAll;
            if(selectAll){
                btn_all_select.setText("取消");
            }else{
                btn_all_select.setText("全选");
            }
            for (ContentManagerBean contentManagerBean: datas){
                contentManagerBean.setSelected(selectAll);
            }
            contentManagerAdapter.notifyDataSetChanged();
        }
    }

    /**
     * 将全部  发布  未发布 标签恢复灰色
     */
    private void resumeShowContentSign(){
        int color = ContextCompat.getColor(this, R.color.middle_gray);
        if(showContentSign == 0)
            tv_content_all.setTextColor(color);
        else if(showContentSign == 1)
            tv_content_publish.setTextColor(color);
        else
            tv_content_non_publish.setTextColor(color);
    }

    /**
     * 解除删除状态
     */
    @SuppressLint("NotifyDataSetChanged")
    private void resumeDeleteMode(){
        tv_content_manager.setText("管理");
        btn_sure_delete.setVisibility(View.GONE);
        btn_all_select.setVisibility(View.GONE);
        for (ContentManagerBean contentManagerBean: datas){
            contentManagerBean.setShowCheckBox(false);
        }
        changeIsManger(false);
        if(selectAll){
            selectAll = false;
            btn_all_select.setText("全部");
        }

        contentManagerAdapter.notifyDataSetChanged();
    }


    public void changeIsManger(boolean b){
        isManager = b;
        contentManagerAdapter.setIsManager(b);
    }
}