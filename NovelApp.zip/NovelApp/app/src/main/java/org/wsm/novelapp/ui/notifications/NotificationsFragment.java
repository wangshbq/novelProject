package org.wsm.novelapp.ui.notifications;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.HomeEntryAdapter;
import org.wsm.novelapp.adapter.NotificationAdapter;
import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.HomeEntryBean;

import java.util.ArrayList;
import java.util.List;

public class NotificationsFragment extends Fragment {

    private final List<Chat> datas = new ArrayList<>();
    private RecyclerView rv_notification_list;
    private NotificationAdapter notificationAdapter;

    @Nullable
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);

        //下拉刷新控件
        SwipeRefreshLayout sr_notification_list = root.findViewById(R.id.sr_notification_list);

        //列表展示控件
        rv_notification_list = root.findViewById(R.id.rv_notification_list);

        rv_notification_list.setLayoutManager(new LinearLayoutManager(requireActivity(), RecyclerView.VERTICAL,false));
        //适配器
        notificationAdapter = new NotificationAdapter(requireActivity(), datas);
        //控件绑定适配器
        rv_notification_list.setAdapter(notificationAdapter);


        return root;
    }

}
