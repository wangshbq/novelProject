package org.wsm.novelapp.ui.mine.login;

import static org.wsm.novelapp.common.Constants.LOGIN_URL;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.emailFormVerify;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.getEnhancedFingerprint;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.model.ChatViewModel;
import org.wsm.novelapp.nativ.EncryptUtils;
import org.wsm.novelapp.utils.RequestUtil;
import java.io.IOException;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {


    private EditText et_email, et_password;
    private RequestUtil loginRequest;
    private String email;
    private String password;
    //如果保存的密码登录为true 否则为false
    private boolean isSavePassword = false;
    private CheckBox cb_save_password;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private View btn_login;

    @SuppressLint({"MissingInflatedId", "CommitPrefEdits"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //退出箭头按钮
        Toolbar tb_login_head = findViewById(R.id.tb_login_head);
        tb_login_head.setNavigationOnClickListener(view -> finish());

        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);

        //记住密码？
        cb_save_password = findViewById(R.id.cb_save_password);

        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
        findViewById(R.id.btn_register).setOnClickListener(this);
        findViewById(R.id.btn_send_email_login).setOnClickListener(this);
        findViewById(R.id.tv_forget_password).setOnClickListener(this);

        //请求类
        loginRequest = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() == 1){
                    LoginUtils.handleLoginSucResp(LoginActivity.this,result);
                    //设置socket
//                    Intent serviceIntent = new Intent(LoginActivity.this, ChatService.class);
//
//                    serviceIntent.setAction("connectAndListen");
//
//                    LoginActivity.this.startService(serviceIntent);

                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("logout", getString(R.string.quit));
                    setResult(RESULT_OK, resultIntent);
                    LoginUtils.remindAndFinish(LoginActivity.this, result.getMsg());

                }else{
                    runOnUiThread(() -> Toast.makeText(LoginActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }

            }
        });

        // 注册 ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("logout", getString(R.string.quit));
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    }
                }
        );
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.btn_login){

            String email = et_email.getText().toString().trim();
            String password = et_password.getText().toString().trim();

            if(email.isEmpty() || password.isEmpty()){
                Toast.makeText(this,"不能为空",Toast.LENGTH_SHORT).show();
                return;
            }
            if(!emailFormVerify(email)){
                Toast.makeText(this,"邮箱格式错误",Toast.LENGTH_SHORT).show();
                return;
            }

            String jsonString = "";
            try {
                //密码加密
                password = EncryptUtils.SHA256(password);
                //构造请求体
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("email", email);
                jsonObject.put("password", password);
                jsonObject.put("deviceId",getEnhancedFingerprint(this));
                boolean loginStatus = cb_save_password.isChecked();
                jsonObject.put("appSaveTokenStatus",loginStatus ? 1 : 0);
                jsonString = jsonObject.toString();

                LoginUtils.isSavePassword = loginStatus;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            String finalJsonString = jsonString;

            new Thread(() -> loginRequest.PostRequest(finalJsonString,LOGIN_URL)).start();

        }else if(id == R.id.btn_register){

            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);

            startActivity(intent);

        }else if(id == R.id.btn_send_email_login){//邮箱登录

            Intent intent = new Intent(LoginActivity.this, CaptchaLoginActivity.class);

            activityResultLauncher.launch(intent);

        }else if(id == R.id.tv_forget_password){
            Intent intent = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
            startActivity(intent);
        }
    }

}