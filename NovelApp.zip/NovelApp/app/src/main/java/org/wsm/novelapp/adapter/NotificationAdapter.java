package org.wsm.novelapp.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.wsm.novelapp.R;
import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.HomeEntryBean;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.CustomViewHolder> implements View.OnClickListener {

    private final Context context;
    private final List<Chat> datas;

    public NotificationAdapter(Context context,List<Chat> datas){
        this.context = context;
        this.datas = datas;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    @Override
    public void onClick(View v) {

    }
    public static class CustomViewHolder extends RecyclerView.ViewHolder{



        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
//            tv_title = itemView.findViewById(R.id.tv_title);
//            tv_content = itemView.findViewById(R.id.tv_content);
//            tv_author = itemView.findViewById(R.id.tv_author);
//            tv_comment_number = itemView.findViewById(R.id.tv_comment_number);
//            tv_page_views_number = itemView.findViewById(R.id.tv_page_views_number);
//            tv_time = itemView.findViewById(R.id.tv_time);
//            ll_home_entry = itemView.findViewById(R.id.ll_home_entry);

        }
    }



}
