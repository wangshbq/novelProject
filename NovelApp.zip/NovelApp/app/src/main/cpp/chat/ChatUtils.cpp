
//
// Created by 86157 on 2025/6/2.
//
#include <jni.h>
#include <android/log.h>
#include "./include/Client.h"
#define TAG "===========> "
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG,__VA_ARGS__);

//extern "C"
//JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
//    LOGD("JNI_OnLoad  1111111111111111111111")
//    JNIEnv* env;
//    LOGD("JNI_OnLoad  222222222222222222222")
//    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
//        LOGD("JNI_OnLoad  333333333333333333333333")
//        return JNI_ERR;
//    }
//    LOGD("JNI_OnLoad  4444444444444444444")
//    return JNI_VERSION_1_6;
//}
//
extern "C"
JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM* vm, void* reserved) {
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) {
        LOGD("========JNI_OnUnload释放资源=======");
//        if(ChatClient::chatObj != nullptr) env->DeleteGlobalRef(ChatClient::chatObj);

        if(ChatClient::viewModelInstance != nullptr) env->DeleteGlobalRef(ChatClient::viewModelInstance);

        if(ChatClient::g_vm != nullptr) ChatClient::g_vm->DetachCurrentThread();

        if(ChatClient::chatClient != nullptr) ChatClient::chatClient.reset();
    }
}

/**
 * 初始化java的方法
 */
extern "C"
JNIEXPORT void JNICALL
Java_org_wsm_novelapp_model_ChatViewModel_nativeInit(JNIEnv *env, jobject thiz,jstring token) {
    // TODO: implement nativeInit()
    env->GetJavaVM(&ChatClient::g_vm); // 保存 JVM

    const char* token_ptr = env->GetStringUTFChars(token, nullptr);

    ChatClient::token = std::string(token_ptr);

    env->ReleaseStringUTFChars(token,token_ptr);
    //viewModel 对象
    ChatClient::viewModelInstance = env->NewGlobalRef(thiz); // 保存 ViewModel 实例

//    jclass chatClass = env->FindClass("org/wsm/novelapp/bean/Chat");
//
//    jmethodID chatConstructor = env->GetMethodID(chatClass, "<init>", "()V");
//    //chat 对象
//    jobject  localChatObj = env->NewObject(chatClass, chatConstructor);
//
//    ChatClient::chatObj = env->NewGlobalRef(localChatObj);
//
//    env->DeleteLocalRef(localChatObj);

//    chatClass = env->GetObjectClass(ChatClient::chatObj);
//    //chat 方法
//    ChatClient::setContent = env->GetMethodID(chatClass, "setContent", "(Ljava/lang/String;)V");
//
//    ChatClient::setUserId = env->GetMethodID(chatClass, "setUserId", "(I)V");
//
//    env->DeleteLocalRef(chatClass);
    // 获取 postMessageFromNative 方法
    jclass viewModelClass = env->GetObjectClass(ChatClient::viewModelInstance);
//    viewModel 方法
    ChatClient::postMethod = env->GetMethodID(
            viewModelClass,
            "postMessageFromNative",
            "(Ljava/lang/String;)V"
    );
    env->DeleteLocalRef(viewModelClass);
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_org_wsm_novelapp_model_ChatViewModel_initConnect(JNIEnv *env, jclass clazz){
    // TODO: implement initConnect()
    LOGD("========initConnect=========")
    try {
        if (ChatClient::chatClient == nullptr) {
            ChatClient::chatClient = std::make_shared<ChatClient>(std::string("192.168.76.11"), 5000);
//            ChatClient::chatClient = std::make_shared<ChatClient>(std::string("8.138.83.162"), 5000);

            signal(SIGPIPE, SIG_IGN);
            ChatClient::thread_running = true;

            if (!ChatClient::chatClient->init(10)) {
                return JNI_FALSE;
            }

            if (!ChatClient::chatClient->connectToServer()) {
                return JNI_FALSE;
            }

            ChatClient::chatClient->run();
        }
    }catch (const std::exception& e){
        LOGD("Exception: %s", e.what());
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

/**
 * 发送消息给指定的用户
 */
extern "C"
JNIEXPORT void JNICALL
Java_org_wsm_novelapp_model_ChatViewModel_sendMessage(JNIEnv *env, jclass clazz, jstring user_id,
                                                      jstring message) {
    // TODO: implement sendMessage()
    const char* c_user_id_ptr = env->GetStringUTFChars(user_id, nullptr);

    if (c_user_id_ptr == nullptr) {
        return;
    }

    const char* c_message_ptr = env->GetStringUTFChars(message, nullptr);

    if (c_message_ptr == nullptr) {
        env->ReleaseStringUTFChars(user_id, c_user_id_ptr);
        return;
    }

    std::string c_user_id(c_user_id_ptr);
    std::string c_message(c_message_ptr);

    ChatClient::chatClient->enqueueMessage(c_user_id, c_message);

    env->ReleaseStringUTFChars(user_id, c_user_id_ptr);
    env->ReleaseStringUTFChars(message, c_message_ptr);
}
extern "C"
JNIEXPORT void JNICALL
Java_org_wsm_novelapp_model_ChatViewModel_stopConnect(JNIEnv *env, jclass clazz) {
    // TODO: implement stopConnect()

    if(!ChatClient::thread_running) return;

    ChatClient::thread_running = false;

    // 发送唤醒信号
    if(ChatClient::client_socket_ != -1) {
        uint64_t value = 1;
        write(ChatClient::client_socket_, &value, sizeof(value));
    }

}
extern "C"
JNIEXPORT jboolean JNICALL
Java_org_wsm_novelapp_model_ChatViewModel_isConnected(JNIEnv *env, jclass clazz) {
    // TODO: implement isConnect()
    if(ChatClient::thread_running){
        return JNI_TRUE;
    }else{
        return JNI_FALSE;
    }
}