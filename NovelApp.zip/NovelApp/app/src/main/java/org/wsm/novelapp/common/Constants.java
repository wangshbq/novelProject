package org.wsm.novelapp.common;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Date;

public class Constants {
//    public static final String URL = "https://www.whoiswsm.com";
//    public static final String LOGIN_URL = URL + "/user/login";

    private static final String IP_PORT = "192.168.79.11:5100";
    public static final String URL = "http://" + IP_PORT;

    public final static String WS_URL = "ws://" + IP_PORT + "/websocket";


    public static final String LOGIN_URL = URL + "/user/login";
    public static final String SEND_CAPTCHA_URL = URL + "/user/sendEmail";
    public static final String REGISTER_URL = URL + "/user/register";
    public static final String LOGOUT_URL = URL + "/user/logout";
    public static final String CAPTCHA_LOGIN_URL = URL + "/user/captchaLogin";
    public static final String CHANGE_PASSWORD_URL = URL + "/user/changePassword";
    //用户首次打开app 用token 登录
    public static final String GET_USER_URL = URL + "/user/getUser";
    //获得用户关注信息
    public static final String GET_SUBSCRIBE = URL + "/user/getSubscribe";
    public static final String GET_SUBSCRIBE_ALL = URL + "/user/getSubscribeAll";
    public static final String FOLLOW = URL + "/user/follow";
    public static final String GET_USER_BY_ID = URL + "/user/getUserById";
    public static final String LOAD_NOVEL_PART_URL = URL + "/novel/loadNovelPart";

    public static final String GET_HISTORY_NOVEL = URL + "/novel/getHisNovel";
    //保存并发布
    public static final String SAVE_NOVEL = URL + "/novel/saveNovel";

    public static final String SAVE_DRAFT = URL + "/novel/saveDraft";

    public static final String EDIT_NOVEL = URL + "/novel/editNovel";
    //未发布修改为发布
    public static final String RELEASE_NOVEL = URL + "/novel/releaseNovel";

    public static final String DELIST_NOVEL = URL + "/novel/delistNovel";

    public static final String DELETE_SELECTION = URL + "/novel/deleteSelection";

    public static final String VISIT_NOVEL = URL + "/novel/novelByIdPageViewincr";

    public static final String THUMBS_UP_CLICK = URL + "/novel/thumbsupClick";

    public static final String GET_COMMENT_A = URL + "/comment/getComment";

    public static final String INSERT_COMMENT_A = URL + "/comment/insertComment";

    public static final String COMMENT_THUMBS_UP = URL + "/comment/commentThumbsUp";

    public static final String GET_SECOND_COMMENTS = URL + "/comment/getSecondComments";
    //是否在ChatActivity
    public static boolean isChatActivity = false;

    public static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(Date.class, new DateTypeAdapter())
            .create();

    public static final String[] anonymousAccessEndpoints =
            {LOGIN_URL, SEND_CAPTCHA_URL,REGISTER_URL,
            CAPTCHA_LOGIN_URL,CHANGE_PASSWORD_URL,GET_USER_URL};
}
