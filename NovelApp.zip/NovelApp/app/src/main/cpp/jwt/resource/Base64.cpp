#include "Base64.h"
#include <stdexcept>

// Base64 字符表
const std::string Base64::base64Chars =
"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/";
// Base64 填充字符
const char Base64::base64Pad = '=';

std::string Base64::encode(const std::vector<uint8_t>& data) {
    std::string encoded;
    int i = 0;
    int j = 0;
    uint8_t charArray3[3];
    uint8_t charArray4[4];

    for (const uint8_t& byte : data) {
        charArray3[i++] = byte;
        if (i == 3) {
            charArray4[0] = (charArray3[0] & 0xfc) >> 2;
            charArray4[1] = ((charArray3[0] & 0x03) << 4) + ((charArray3[1] & 0xf0) >> 4);
            charArray4[2] = ((charArray3[1] & 0x0f) << 2) + ((charArray3[2] & 0xc0) >> 6);
            charArray4[3] = charArray3[2] & 0x3f;

            for (i = 0; i < 4; i++) {
                encoded += base64Chars[charArray4[i]];
            }
            i = 0;
        }
    }

    if (i > 0) {
        for (j = i; j < 3; j++) {
            charArray3[j] = 0;
        }

        charArray4[0] = (charArray3[0] & 0xfc) >> 2;
        charArray4[1] = ((charArray3[0] & 0x03) << 4) + ((charArray3[1] & 0xf0) >> 4);
        charArray4[2] = ((charArray3[1] & 0x0f) << 2) + ((charArray3[2] & 0xc0) >> 6);
        charArray4[3] = charArray3[2] & 0x3f;

        for (j = 0; j < i + 1; j++) {
            encoded += base64Chars[charArray4[j]];
        }

        while (i++ < 3) {
            encoded += base64Pad;
        }
    }

    return encoded;
}

std::vector<uint8_t> Base64::decode(const std::string& encoded) {
    std::vector<uint8_t> decoded;
    int i = 0;
    int j = 0;
    int inLen = encoded.size();
    uint8_t charArray3[3];
    uint8_t charArray4[4];

    for (int k = 0; k < inLen; k++) {
        if (encoded[k] == base64Pad) break;

        charArray4[i++] = encoded[k];
        if (i == 4) {
            for (i = 0; i < 4; i++) {
                charArray4[i] = base64Chars.find(charArray4[i]);
            }

            charArray3[0] = (charArray4[0] << 2) + ((charArray4[1] & 0x30) >> 4);
            charArray3[1] = ((charArray4[1] & 0x0f) << 4) + ((charArray4[2] & 0x3c) >> 2);
            charArray3[2] = ((charArray4[2] & 0x03) << 6) + charArray4[3];

            for (i = 0; i < 3; i++) {
                decoded.push_back(charArray3[i]);
            }
            i = 0;
        }
    }

    if (i > 0) {
        for (j = i; j < 4; j++) {
            charArray4[j] = 0;
        }

        for (j = 0; j < 4; j++) {
            charArray4[j] = base64Chars.find(charArray4[j]);
        }

        charArray3[0] = (charArray4[0] << 2) + ((charArray4[1] & 0x30) >> 4);
        charArray3[1] = ((charArray4[1] & 0x0f) << 4) + ((charArray4[2] & 0x3c) >> 2);
        charArray3[2] = ((charArray4[2] & 0x03) << 6) + charArray4[3];

        for (j = 0; j < i - 1; j++) {
            decoded.push_back(charArray3[j]);
        }
    }

    return decoded;
}

bool Base64::isBase64(char c) {
    return (isalnum(c) || (c == '+') || (c == '/'));
}



