package org.wsm.novelapp.common;

import android.annotation.SuppressLint;
import android.util.Log;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import java.lang.reflect.Type;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.Date;

@SuppressLint("SimpleDateFormat")
class DateTypeAdapter implements JsonSerializer<Date>, JsonDeserializer<Date> {

    private static DateTimeFormatter formatter;
    private static final DateFormat formatter2;
    static{
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O){
            formatter = new DateTimeFormatterBuilder()
                    .appendPattern("yyyy-MM-dd HH:mm:ss.SSS")
                    .appendFraction(ChronoField.MILLI_OF_SECOND, 0, 3, true)  // 毫秒部分（1~3位）

//                    .optionalStart()
//                    .appendFraction(ChronoField.MILLI_OF_SECOND, 1, 3, true)
//                    .optionalEnd()
                    .toFormatter();
        }

        formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    }

    @Override
    public JsonElement serialize(Date date, Type typeOfSrc, JsonSerializationContext context) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;

        // 将Date转换为Java 8时间类型
        Instant instant = date.toInstant();
        ZonedDateTime zonedDateTime = instant.atZone(ZoneId.systemDefault());
        String formatted = zonedDateTime.format(formatter);

        return new JsonPrimitive(formatted);

    }

    @SuppressLint("SimpleDateFormat")
    @Override
    public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        try {
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;

            String asString = json.getAsString();
            Log.d("============asString", asString);
            if(asString.length() == 13){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                // 将时间戳字符串转换为 long
                long timestamp = Long.parseLong(asString);
                // 创建 Date 对象
                Date date = new Date(timestamp);

                return sdf.parse(sdf.format(date));
            }else{
//                Log.d("===>time", asString);
//                LocalDateTime localDateTime = LocalDateTime.parse(asString,formatter);
//                Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
//                System.out.println("Parsed Date: " + date);//Parsed Date: Wed Sep 24 15:19:13 GMT+08:00 2025


                return formatter2.parse(asString);
            }


        } catch (ParseException e) {
            throw new JsonParseException("Failed to parse date: " + json.getAsString(), e);
        }
    }


}