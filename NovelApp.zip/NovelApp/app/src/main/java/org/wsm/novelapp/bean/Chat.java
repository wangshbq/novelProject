package org.wsm.novelapp.bean;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.sql.Timestamp;

@Entity
public class Chat {
    @PrimaryKey
    private Integer id;
    private String content;
    private int userId;
    private Integer targetId;
    private String userName;
    private Timestamp sendTime;
    private Boolean isSend;//判断此条数据是主动发送消息还是接收消息

    public Chat(){}

    public Chat(Chat chat) {
        this.id = chat.id;
        this.content = chat.content;
        this.userId = chat.userId;
        this.targetId = chat.targetId;
        this.userName = chat.userName;
        this.sendTime = chat.sendTime;
        this.isSend = chat.isSend;
    }

    public Boolean getSend() {
        return isSend;
    }

    public void setSend(Boolean send) {
        isSend = send;
    }



    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Integer getTargetId() {
        return targetId;
    }

    public void setTargetId(Integer targetId) {
        this.targetId = targetId;
    }

    public Timestamp getSendTime() {
        return sendTime;
    }

    public void setSendTime(Timestamp sendTime) {
        this.sendTime = sendTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", userId=" + userId +
                ", targetId=" + targetId +
                ", userName='" + userName + '\'' +
                ", sendTime='" + sendTime + '\'' +
                ", isSend=" + isSend +
                '}';
    }
}
