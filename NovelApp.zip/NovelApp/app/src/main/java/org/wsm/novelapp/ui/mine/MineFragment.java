package org.wsm.novelapp.ui.mine;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static org.wsm.novelapp.common.Constants.GET_SUBSCRIBE;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.LOGOUT_URL;
import static org.wsm.novelapp.service.SocketService.CLOSE_CONNECTION;
import static org.wsm.novelapp.service.SocketService.NOTIFICATION;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.clearLoginData;
import static org.wsm.novelapp.utils.RequestUtil.REFRESH;
import static org.wsm.novelapp.utils.RequestUtil.TOKEN;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.reflect.TypeToken;

import org.wsm.novelapp.MainActivity;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.bean.UserDetail;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.mine.create.CreateCenterActivity;
import org.wsm.novelapp.ui.mine.login.LoginActivity;
import org.wsm.novelapp.R;
import org.wsm.novelapp.ui.mine.subscribe.ShowSubscriberActivity;
import org.wsm.novelapp.utils.RequestUtil;
import org.wsm.novelapp.service.SocketService;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Map;

public class MineFragment extends Fragment implements View.OnClickListener {
    private TextView tv_logout;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private TextView tv_subscribe_number;
    @Override
    public void onHiddenChanged(boolean isHidden) {
        super.onHiddenChanged(isHidden);
        if (!isHidden) {
            logShow();
            //显示用户关注数量
            showSubscribe();
        }
    }

    @Nullable
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_mine, container, false);

        //   登录/注册  或  退出登录
        tv_logout = root.findViewById(R.id.tv_logout);
        //退出登录
        tv_logout.setOnClickListener(this);
        //创作中心
        root.findViewById(R.id.tv_create_center).setOnClickListener(this);

        tv_subscribe_number = root.findViewById(R.id.tv_subscribe_number);
        root.findViewById(R.id.ll_subscribe).setOnClickListener(this);
//        Glide.with(this)
//                .load("https://example.com/image.jpg")
//                .into(imageView);


        // 注册 ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        String updatedText = result.getData().getStringExtra("logout");
                        Log.d("==========>updatedText", updatedText == null ? "null" : updatedText);
                        if (tv_logout != null) {
                            tv_logout.setText(updatedText);
                            //更新用户关注数量
                            showSubscribe();
                        }
                    }
                }
        );

        //判断是否登录
        logShow();
        //显示用户关注数量
        showSubscribe();

        return root;
    }

    private void showSubscribe(){
        Log.d("========.showSubscribe", "showSubscribe");
        GlobalApplication application = (GlobalApplication)requireActivity().getApplication();

        User user = application.getUser();

        if(user == null) return;

        int userId = user.getId();

        Log.d("========.userId", userId + "");
        SharedPreferences preferences = requireActivity().getSharedPreferences("userData:" + userId, MODE_PRIVATE);

        int subscribeNumber = preferences.getInt("subscribeNumber",-1);

        Log.d("========.subscribeNumber", subscribeNumber + "");
        //如果为空请求服务器
        if(subscribeNumber == -1){
            new Thread(() -> {

                new RequestUtil(requireActivity(), new RequestUtil.ResponseListen() {
                    @SuppressLint({"CommitPrefEdits"})
                    @Override
                    public void handleResponse(Result result) throws IOException {
                        if(result.getCode() == 1){

                            Map<String, String> data = result.getData();

                            String subscribe = data.get("subscribe");

                            Type resultType = new TypeToken<UserDetail>() {}.getType();

                            UserDetail userDetail = GSON.fromJson(subscribe, resultType);
                            SharedPreferences.Editor edit = preferences.edit();
                            int subscribeNumber;
                            //设置关注数量以及关注的userId到手机内
                            if(userDetail != null){

                                String subscribeText = userDetail.getSubscribe();

                                if(!subscribeText.isEmpty()){

                                    String[] split = subscribeText.split(",");
                                    Log.d("========请求成功计算出的值 subscribeNumber", split.length + "");
                                    subscribeNumber = split.length;
                                } else {
                                    subscribeNumber = 0;
                                }

                                edit.putInt("subscribeNumber",subscribeNumber);
                                edit.putString("subscribeText",subscribeText);

                                requireActivity().runOnUiThread(() ->
                                        tv_subscribe_number.setText(String.valueOf(subscribeNumber)));
                            }else{//没有关注任何人
                                edit.putInt("subscribeNumber",0);
                                edit.putString("subscribeText","");
                            }
                            edit.apply();

                        }else{
                            Toast.makeText(requireActivity(),result.getMsg(),Toast.LENGTH_SHORT).show();
                        }
                    }
                }).GetRequest(null,GET_SUBSCRIBE);

            }).start();

        }else{//手机内部有数据
            tv_subscribe_number.setText(String.valueOf(subscribeNumber));
        }
    }

    private void logShow(){
        if(TOKEN.isEmpty()){
            tv_logout.setText(R.string.login_or_register);
        }else{
            tv_logout.setText(R.string.quit);
        }
    }

    @SuppressLint("CommitPrefEdits")
    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.tv_logout){

            if(TOKEN.isEmpty()){//用户未登录  跳转登录注册页面
                // 启动 SourceActivity
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                activityResultLauncher.launch(intent);
            }else{
                showBottomSheetDialog();
            }
        }else if(id == R.id.tv_create_center){
            if(TOKEN.isEmpty()){
                Toast.makeText(getActivity(),"请先登录",Toast.LENGTH_SHORT).show();
            }else{
                Intent intent = new Intent(getActivity(), CreateCenterActivity.class);
                activityResultLauncher.launch(intent);
            }
        }else if(id == R.id.ll_subscribe){//点击关注
            if(TOKEN.isEmpty()){
                Toast.makeText(getActivity(),"请先登录",Toast.LENGTH_SHORT).show();
            }else{
                Intent intent = new Intent(getActivity(), ShowSubscriberActivity.class);
                activityResultLauncher.launch(intent);
            }
        }
    }
    @SuppressLint({"MissingInflatedId","InflateParams"})
    private void showBottomSheetDialog() {
        // 创建 BottomSheetDialog
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(requireActivity());
        View view = getLayoutInflater().inflate(R.layout.bottom_dialog_mine_sheet, null);
        bottomSheetDialog.setContentView(view);

        // 退出登录
        view.findViewById(R.id.btn_quit_login).setOnClickListener(v -> {

            bottomSheetDialog.dismiss();

            Thread thread = new Thread(() -> {
                new RequestUtil(getActivity(), new RequestUtil.ResponseListen() {
                    @SuppressLint("WrongConstant")
                    @Override
                    public void handleResponse(Result result) throws IOException {
                        if(result.getCode() == 1){
//                            Intent serviceIntent = new Intent(requireActivity(), SocketService.class);
//                            requireActivity().stopService(serviceIntent);

                            //关闭socket连接
//                            webSocket.cancel();

                            Intent socketServiceIntent = new Intent(requireActivity(), SocketService.class);
                            socketServiceIntent.putExtra("action",CLOSE_CONNECTION);
                            requireActivity().startService(socketServiceIntent);

//                            webSocket.close(1000, "User initiated closure");
//                            serviceIntent.setAction("STOP");
//                            requireActivity().startService(serviceIntent);
                        }
                    }
                }).PostRequest("", LOGOUT_URL);
            });

            thread.start();

            try {
                thread.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            tv_logout.setText(R.string.login_or_register);
            clearLoginData(requireActivity());
            Intent intent = new Intent(requireActivity(), LoginActivity.class);
            activityResultLauncher.launch(intent);
            TOKEN = "";
            REFRESH = "";
//            SocketService.isSocket = false;
//            startActivity(intent);

//            requireActivity().finish();
        });

        //退出app
        view.findViewById(R.id.btn_quit_app).setOnClickListener(v -> {
            bottomSheetDialog.dismiss();
            // 关闭整个应用
            if (getActivity() != null) {
                ((MainActivity) getActivity()).exitApp();
            }
        });

        // 显示弹窗
        bottomSheetDialog.show();
    }

}
