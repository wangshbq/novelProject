//
// Created by 86157 on 2025/6/2.
//


#pragma once
#ifndef NOVELLA_CLIENT_H
#define NOVELLA_CLIENT_H
#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/epoll.h>
#include <cerrno>
#include <csignal>
#include <sys/timerfd.h>
#include <thread>
#include <jni.h>
#include "./HandleMessage.h"
#define MAX_EVENTS 10
#define BUFFER_SIZE 1024
class ChatClient{
public:
    ChatClient(std::string host, int port);
    ~ChatClient();

    bool init(int user_id);
    bool connectToServer();
    void run();

    void enqueueMessage(const std::string& receive_user_id,const std::string& msg);
    // 返回true表示连接可能存活
    bool isSocketAlive(int fd);

    static std::atomic<bool> thread_running;

    static JavaVM* g_vm;  // 必须定义！
//    static jclass chatClass;
//    static jmethodID chatConstructor;
    static jmethodID postMethod;
    static std::shared_ptr<ChatClient> chatClient;
//    static jclass viewModelClass;
//    static JNIEnv* env;
    static jobject viewModelInstance;
    static jobject chatObj;
    static jmethodID setContent;
    static std::string token;
    static int client_socket_;
    static jmethodID setUserId;
private:
    std::string host_;
    int port_;
    int epoll_fd_;

    int timer_fd_;
    bool connected_;
    int user_id_{};
    HandleMessage handleMessage_;
    std::vector<char> write_buffer_;
    void handleConnect();
    void sendToken();
    void handleRead();
    void handleWrite();
    void modifyEpollEvents(uint32_t events);
    void closeClient();
};


#endif //NOVELLA_CLIENT_H
