package org.wsm.novelapp.adapter;

import static org.wsm.novelapp.common.CommonMethod.handleShowTime;
import static org.wsm.novelapp.common.Constants.DELIST_NOVEL;
import static org.wsm.novelapp.common.Constants.RELEASE_NOVEL;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.ContentManagerBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dao.NovelDao;
import org.wsm.novelapp.database.AppDatabase;
import org.wsm.novelapp.ui.mine.create.WriteNovelActivity;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ContentManagerAdapter extends RecyclerView.Adapter<ContentManagerAdapter.CustomViewHolder> implements View.OnClickListener {

    private Context context;
    private List<ContentManagerBean> datas;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private boolean isManager;

    public ContentManagerAdapter(Context context, List<ContentManagerBean> datas,ActivityResultLauncher<Intent> activityResultLauncher,boolean isManager) {
        this.datas = datas;
        this.context = context;
        this.activityResultLauncher = activityResultLauncher;
        this.isManager = isManager;
    }

    // 更新 boolean 值的方法
    public void setIsManager(boolean value) {
        isManager = value;
    }
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.item_content_show, parent, false);

        inflate.findViewById(R.id.tv_content_edit).setOnClickListener(this);
        inflate.findViewById(R.id.tv_content_release).setOnClickListener(this);

        return new ContentManagerAdapter.CustomViewHolder(inflate);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        ContentManagerBean homeEntryBean = datas.get(position);

        holder.tv_title.setText(homeEntryBean.getTitle());
        holder.tv_content.setText(homeEntryBean.getContent());

        holder.tv_time.setText(handleShowTime(homeEntryBean.getCreateTime().toString()));

        holder.tv_word_count.setText(homeEntryBean.getWordCount() + "");
        holder.cb_select_delete.setVisibility(homeEntryBean.isShowCheckBox() ? View.VISIBLE : View.GONE);
        holder.cb_select_delete.setChecked(homeEntryBean.isSelected());

        holder.cb_select_delete.setOnCheckedChangeListener((buttonView, isChecked) -> {
            homeEntryBean.setSelected(isChecked); // 更新数据模型的选中状态
        });

        //0未发布 1已发布 2已删除
        if(homeEntryBean.getStatus() == 0){
            holder.tv_content_release.setText("未发布");
            int color = ContextCompat.getColor(context, R.color.red);
            holder.tv_content_release.setTextColor(color);
        }else if(homeEntryBean.getStatus() == 1){
            holder.tv_content_release.setText("已发布");
            int color = ContextCompat.getColor(context, R.color.fluorescent_green);
            holder.tv_content_release.setTextColor(color);
        }

        // 设置点击监听器并保存位置
        holder.itemView.findViewById(R.id.tv_content_edit).setTag(position);
        holder.itemView.findViewById(R.id.tv_content_release).setTag(position);
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public void onClick(View v) {
        if(isManager) return;
        int id = v.getId();
        if(id == R.id.tv_content_edit){//编辑
            int position = (int)v.getTag();
            ContentManagerBean contentManagerBean = datas.get(position);

            Intent intent = new Intent(context, WriteNovelActivity.class);
            intent.putExtra("intentFrom", "ContentManagerActivity");
            intent.putExtra("novelId",contentManagerBean.getId());
            intent.putExtra("status",contentManagerBean.getStatus());
            activityResultLauncher.launch(intent);
        }else{//发布 或 下架
            int position = (int)v.getTag();
            ContentManagerBean contentManagerBean = datas.get(position);
            //0未发布 1已发布 2已删除
            Integer status = contentManagerBean.getStatus();
            Integer novelId = contentManagerBean.getId();
            if(status == 0){
                showDialog(1,novelId,(TextView)v,contentManagerBean);
            }else{
                showDialog(0,novelId,(TextView)v,contentManagerBean);
            }
        }
    }
    public void showDialog(int status,int id,TextView textView,ContentManagerBean contentManagerBean) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle("提示");

        if(status == 0){
            builder.setMessage("下架后评论、点赞等信息清除,确定下架?");
        }else{
            builder.setMessage("确定发布?");
        }


        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                GlobalApplication application = (GlobalApplication) ((Activity) context).getApplication();
                User user = application.getUser();
                new Thread(() -> {

                    ArrayList<Integer> ids = new ArrayList<>();
                    ids.add(id);
                    RequestUtil requestUtil = new RequestUtil((Activity) context, new RequestUtil.ResponseListen() {
                        @Override
                        public void handleResponse(Result result) throws IOException {

                            ((Activity) context).runOnUiThread(() -> Toast.makeText(context, result.getMsg(), Toast.LENGTH_SHORT).show());

                            if (result.getCode() == 1) {
                                AppDatabase instance = AppDatabase.getInstance(context);
                                NovelDao novelDao = instance.novelDao();
                                novelDao.updateStatus(status, id, user.getId());
                                if(status == 0){
                                    ((Activity) context).runOnUiThread(() -> {
                                        textView.setText("未发布");
                                        int color = ContextCompat.getColor(context, R.color.red);
                                        textView.setTextColor(color);
                                    });

                                }else{
                                    ((Activity) context).runOnUiThread(() -> {
                                        textView.setText("已发布");
                                        int color = ContextCompat.getColor(context, R.color.fluorescent_green);
                                        textView.setTextColor(color);
                                    });

                                }
                                contentManagerBean.setStatus(status);
                            }
                        }
                    });

                    if(status == 0){
                        requestUtil.PostRequest(ids.toString(),DELIST_NOVEL);
                    }else{
                        requestUtil.PostRequest(ids.toString(),RELEASE_NOVEL);
                    }


                }).start();

            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public static class CustomViewHolder extends RecyclerView.ViewHolder{

        TextView tv_content;
        TextView tv_title;
        TextView tv_time;
        TextView tv_word_count;
        TextView tv_content_release;
        CheckBox cb_select_delete;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_draft_show_title);
            tv_content = itemView.findViewById(R.id.tv_draft_show_content);
            tv_time = itemView.findViewById(R.id.tv_draft_show_time);
            tv_word_count = itemView.findViewById(R.id.tv_draft_word_count);
            tv_content_release = itemView.findViewById(R.id.tv_content_release);
            cb_select_delete = itemView.findViewById(R.id.cb_select_delete);
        }
    }
}
