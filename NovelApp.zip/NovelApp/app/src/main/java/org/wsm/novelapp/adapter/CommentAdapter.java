package org.wsm.novelapp.adapter;

import static android.content.Context.INPUT_METHOD_SERVICE;
import static org.wsm.novelapp.common.CommonMethod.handleShowTime;
import static org.wsm.novelapp.common.Constants.COMMENT_THUMBS_UP;
import static org.wsm.novelapp.common.Constants.INSERT_COMMENT_A;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.CommentBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.home.PersonCenterActivity;
import org.wsm.novelapp.ui.home.SecondCommentActivity;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> implements View.OnClickListener {

    private Context context;
    private List<CommentBean> datas;
    //键盘输入的内容
    private String inputComment = "";
    //销毁输入评论的弹出框时 是否要清除inputComment
    private boolean isClearInputComment = false;
    private EditText et_input_comment_dialog;
    private BottomSheetDialog bottomSheetDialog;
    private RequestUtil sendComment;
    private String novelId;
    private Integer secPosition = 0;
    private ActivityResultLauncher<Intent> activityResultLauncher;

    public Integer getSecPosition() {
        return secPosition;
    }

    public void setSecPosition(Integer secPosition) {
        this.secPosition = secPosition;
    }

    public CommentAdapter(Context context,ActivityResultLauncher<Intent> activityResultLauncher, List<CommentBean> datas, RequestUtil sendComment, String novelId){
        this.context = context;
        this.datas = datas;
        this.sendComment = sendComment;
        this.novelId = novelId;
        this.activityResultLauncher = activityResultLauncher;
    }

    public List<CommentBean> getDatas(){
        return datas;
    }
    @Override
    public int getItemViewType(int position) {
        Log.d("====>", "getItemViewType: ");
        return datas.get(position).getSecondCommentNumber();
    }

    @SuppressLint("MissingInflatedId")
    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Log.d("===>", "onCreateViewHolder: ");
        View inflate = LayoutInflater.from(context).inflate(R.layout.item_comment, parent, false);
        //点击回复评论
        inflate.findViewById(R.id.iv_reply_comment_icon).setOnClickListener(this);
        //点赞
        inflate.findViewById(R.id.iv_comment_thumb_icon).setOnClickListener(this);
        //跳转个人中心
        inflate.findViewById(R.id.iv_header_image).setOnClickListener(this);
        inflate.findViewById(R.id.tv_comment_user_name).setOnClickListener(this);
        if(viewType >= 1){
            inflate.findViewById(R.id.iv_reply_comment_icon1).setOnClickListener(this);
            inflate.findViewById(R.id.iv_comment_thumb_icon1).setOnClickListener(this);
            inflate.findViewById(R.id.iv_header_image1).setOnClickListener(this);
            inflate.findViewById(R.id.tv_comment_user_name1).setOnClickListener(this);
        }

        if(viewType >= 2){
            inflate.findViewById(R.id.iv_reply_comment_icon2).setOnClickListener(this);
            inflate.findViewById(R.id.iv_comment_thumb_icon2).setOnClickListener(this);
            inflate.findViewById(R.id.iv_header_image2).setOnClickListener(this);
            inflate.findViewById(R.id.tv_comment_user_name2).setOnClickListener(this);
        }

        if(viewType >= 3){
            inflate.findViewById(R.id.ll_comment_more_comment).setOnClickListener(this);
        }

        if(viewType == 0){
            return new CommentAdapter.CommentViewHolder(inflate);
        }else if(viewType == 1){
            return new CommentAdapter.CommentViewHolder1(inflate);
        }else if(viewType == 2){
            return new CommentAdapter.CommentViewHolder2(inflate);
        }else {
            return new CommentAdapter.MoreComment(inflate);
        }

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
        Log.d("===>", "onBindViewHolder: ");
        CommentBean commentBean = datas.get(position);
        Log.d("===>commentBean", commentBean.toString());
        //设置用户名
        holder.tv_comment_user_name.setText(commentBean.getUserName());
        //设置评论内容
        holder.tv_comment_content.setText(commentBean.getCommentContent());
        //设置点赞数
        holder.tv_comment_thumb_up.setText(commentBean.getThumbUpNumber() + "");

        //处理发布时间
        String time = commentBean.getPublishTime().toString();
        //设置评论时间
        holder.tv_comment_time.setText(handleShowTime(time));

        Integer isThumbsUp = commentBean.getIsThumbsUp();

        //判断当前用户是否对评论点赞
        if(isThumbsUp == null || isThumbsUp == 0)
            holder.iv_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_border_35);
        else
            holder.iv_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_35);

        holder.iv_comment_thumb_icon.setTag(String.valueOf(position));

        holder.iv_reply_comment_icon.setTag(String.valueOf(commentBean.getCommentId()));

        holder.tv_comment_user_name.setTag(String.valueOf(position));

        holder.iv_header_image.setTag(String.valueOf(position));

        Integer isSecComment = commentBean.getSecondCommentNumber();

        if(isSecComment != 0){

            Integer commentId = commentBean.getCommentId();
            //存储当前评论下面二级评论在datas的位置
            ArrayList<Integer> secondCommentPosition = getSecondCommentId(commentId);

            if(isSecComment >= 1){
                CommentViewHolder1 holder1 = (CommentViewHolder1) holder;
                holder1.ll_second_comment1.setVisibility(View.VISIBLE);
                Integer index = secondCommentPosition.get(0);
                CommentBean commentBean1 = datas.get(index);

                holder1.tv_comment_user_name1.setText(commentBean1.getUserName());
                holder1.tv_comment_content1.setText(commentBean1.getCommentContent());

                holder1.tv_comment_thumb_up1.setText(commentBean1.getThumbUpNumber() + "");

                holder1.tv_comment_time1.setText(handleShowTime(commentBean1.getPublishTime().toString()));

                holder1.iv_comment_thumb_icon1.setTag(index + ":" + position);

                holder1.iv_reply_comment_icon1.setTag(commentBean.getCommentId() + ":" + commentBean1.getCommentId());

                holder1.tv_comment_user_name1.setTag(String.valueOf(index));

                holder1.iv_header_image1.setTag(String.valueOf(index));

                String replyUserName = commentBean1.getReplyUserName();

                if(replyUserName == null || replyUserName.isEmpty()){
                    holder1.iv_arrow_icon1.setVisibility(View.GONE);
                    holder1.tv_reply_comment_user_name1.setText("");
                } else{
                    holder1.iv_arrow_icon1.setVisibility(View.VISIBLE);
                    holder1.tv_reply_comment_user_name1.setText(replyUserName);
                }


                Integer isThumbsUp1 = commentBean1.getIsThumbsUp();

                if(isThumbsUp1 == null || isThumbsUp1 == 0)
                    holder1.iv_comment_thumb_icon1.setImageResource(R.drawable.baseline_favorite_border_35);
                else
                    holder1.iv_comment_thumb_icon1.setImageResource(R.drawable.baseline_favorite_35);

            }

            if(isSecComment >= 2){
                CommentViewHolder2 holder2 = (CommentViewHolder2) holder;
                holder2.ll_second_comment2.setVisibility(View.VISIBLE);

                Integer index = secondCommentPosition.get(1);

                CommentBean commentBean2 = datas.get(index);

                holder2.tv_comment_user_name2.setText(commentBean2.getUserName());

                holder2.tv_comment_content2.setText(commentBean2.getCommentContent());

                holder2.tv_comment_thumb_up2.setText(commentBean2.getThumbUpNumber() + "");

                holder2.tv_comment_time2.setText(handleShowTime(commentBean2.getPublishTime().toString()));

//                holder2.tv_reply_comment_user_name2.setText(commentBean2.getReplyUserName());
                //index为二级评论的位置 position为当前二级评论的一级评论位置
                holder2.iv_comment_thumb_icon2.setTag(index + ":" + position);

                holder2.iv_reply_comment_icon2.setTag(commentBean.getCommentId() + ":" + commentBean2.getCommentId());

                holder2.tv_comment_user_name2.setTag(String.valueOf(index));

                holder2.iv_header_image2.setTag(String.valueOf(index));

                String replyUserName = commentBean2.getReplyUserName();

                if(replyUserName == null || replyUserName.isEmpty()){
                    holder2.iv_arrow_icon2.setVisibility(View.GONE);
                    holder2.tv_reply_comment_user_name2.setText("");
                }else{
                    holder2.iv_arrow_icon2.setVisibility(View.VISIBLE);
                    holder2.tv_reply_comment_user_name2.setText(replyUserName);
                }

                Integer isThumbsUp1 = commentBean2.getIsThumbsUp();

                if(isThumbsUp1 == null || isThumbsUp1 == 0)
                    holder2.iv_comment_thumb_icon2.setImageResource(R.drawable.baseline_favorite_border_35);
                else
                    holder2.iv_comment_thumb_icon2.setImageResource(R.drawable.baseline_favorite_35);
            }

            if(isSecComment >= 3){
                MoreComment moreComment = (MoreComment) holder;
                moreComment.ll_comment_more_comment.setVisibility(View.VISIBLE);
                moreComment.tv_more_comment_number.setText(isSecComment + "");

                moreComment.ll_comment_more_comment.setTag(position);
            }
        }
    }

    private ArrayList<Integer> getSecondCommentId(Integer commentId){
        ArrayList<Integer> integers = new ArrayList<>();
        for (int i = secPosition;i < datas.size();i++){
            CommentBean commentBean = datas.get(i);
            //当前commentBean是parentId的二级评论
            if(commentBean.getParentId().equals(commentId)){//找到当前commentId下的二级评论
                integers.add(i);
            }
        }
        return integers;
    }

    @Override
    public int getItemCount() {
        return secPosition;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.iv_reply_comment_icon || id == R.id.iv_reply_comment_icon1 || id == R.id.iv_reply_comment_icon2){//点击回复评论里的评论
            String commentId = (String) v.getTag();
            handleBottomSheetDialog(commentId);
        }else if(id == R.id.iv_comment_thumb_icon || id == R.id.iv_comment_thumb_icon1 || id == R.id.iv_comment_thumb_icon2){//点赞
            String[] tag = ((String) v.getTag()).split(":");

            int position = Integer.parseInt(tag[0]);

            CommentBean commentBean = datas.get(position);
            Integer novelId = commentBean.getNovelId();
            Integer commentId = commentBean.getCommentId();
            Integer parentId = commentBean.getParentId();

            if(commentBean.getIsThumbsUp() == 1) return;
            new Thread(() -> {

                Map<String, String> map = new HashMap<>();
                map.put("novelId",novelId + "");
                map.put("commentId",commentId + "");
                map.put("parentId",parentId + "");
                new RequestUtil((Activity) context, new RequestUtil.ResponseListen() {
                    @SuppressLint("NotifyDataSetChanged")
                    @Override
                    public void handleResponse(Result result) throws IOException {
                        if(result.getCode() != 1){
                            ((Activity) context).runOnUiThread(() -> Toast.makeText(context,result.getMsg(),Toast.LENGTH_SHORT).show());
                        }else{
                            ((Activity) context).runOnUiThread(() -> {
                                commentBean.setThumbUpNumber(commentBean.getThumbUpNumber() + 1);

                                commentBean.setIsThumbsUp(1);

                                if(tag.length == 2){
                                    notifyItemChanged(Integer.parseInt(tag[1]));
                                }else{
                                    notifyItemChanged(position);
                                }
                            });
                        }
                    }
                }).GetRequest(map,COMMENT_THUMBS_UP);
            }).start();
        }else if(id == R.id.tv_publish_comment){//点击发送评论
            String content = et_input_comment_dialog.getText().toString();
            String commentId = (String) v.getTag();
            String[] commentIds = commentId.split(":");

            if(content.isEmpty()){
                ((Activity)context).runOnUiThread(() -> Toast.makeText(context,"不能为空",Toast.LENGTH_SHORT).show());
                return;
            }

            if(content.length() > 1000){
                ((Activity)context).runOnUiThread(() -> Toast.makeText(context,"字数不能超过1000",Toast.LENGTH_SHORT).show());
                return;
            }

            isClearInputComment = true;
            bottomSheetDialog.dismiss();

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("novelId",novelId);
                jsonObject.put("content",content);
                jsonObject.put("parentId",commentIds[0]);
                if(commentIds.length == 2)
                    jsonObject.put("replyCommentId",commentIds[1]);
//                else
//                    jsonObject.put("replyCommentId",commentIds[0]);

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            sendComment.PostRequest(jsonObject.toString(),INSERT_COMMENT_A);
        }else if(id == R.id.ll_comment_more_comment){//点击查看更多二级评论
            int position = Integer.parseInt(v.getTag().toString());
            CommentBean commentBean = datas.get(position);
            Intent intent = new Intent(context, SecondCommentActivity.class);
            intent.putExtra("userId",commentBean.getUserId());
            intent.putExtra("commentId",commentBean.getCommentId() + "");
            intent.putExtra("userName",commentBean.getUserName());
            intent.putExtra("novelId",commentBean.getNovelId() + "");
            intent.putExtra("content",commentBean.getCommentContent());
            intent.putExtra("publicTime",commentBean.getPublishTime().toString());
            intent.putExtra("thumbUpNumber",commentBean.getThumbUpNumber());
            intent.putExtra("isThumbUp",commentBean.getIsThumbsUp());
            intent.putExtra("secondCommentNumber",commentBean.getSecondCommentNumber());
            intent.putExtra("position",position);
            activityResultLauncher.launch(intent);
        }else if(
                id == R.id.iv_header_image || id == R.id.tv_comment_user_name ||
                id == R.id.iv_header_image1 || id == R.id.tv_comment_user_name1 ||
                id == R.id.iv_header_image2 || id == R.id.tv_comment_user_name2
        ){

            int position = Integer.parseInt(v.getTag().toString());
            CommentBean commentBean = datas.get(position);
            Intent intent = new Intent(context, PersonCenterActivity.class);
            intent.putExtra("authorUserId",commentBean.getUserId());
            intent.putExtra("authorName",commentBean.getUserName());
            context.startActivity(intent);
        }
    }

    private void handleBottomSheetDialog(String position){
        // 创建 BottomSheetDialog
        bottomSheetDialog = new BottomSheetDialog(context);
        View bottom_dialog_input_comment = ((Activity)context).getLayoutInflater().inflate(R.layout.bottom_dialog_input_comment, null);
        bottomSheetDialog.setContentView(bottom_dialog_input_comment);

        bottomSheetDialog.show();
        //用户输入评论框
        et_input_comment_dialog = bottom_dialog_input_comment.findViewById(R.id.et_input_comment_dialog);

        //点击发布的按钮
        TextView tv_publish_comment = bottom_dialog_input_comment.findViewById(R.id.tv_publish_comment);
        tv_publish_comment.setTag(position);
        tv_publish_comment.setOnClickListener(this);
        // 设置销毁监听器
        bottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if(isClearInputComment){
                    inputComment = "";
                    isClearInputComment = false;
                }else{
                    inputComment = et_input_comment_dialog.getText().toString();
                }
            }
        });

        //弹出键盘
        et_input_comment_dialog.post(() -> {
            et_input_comment_dialog.requestFocus();
            et_input_comment_dialog.setText(inputComment);

            InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);

            if (imm != null)
                imm.showSoftInput(et_input_comment_dialog, InputMethodManager.SHOW_IMPLICIT);

        });

    }



    public static class CommentViewHolder extends RecyclerView.ViewHolder{

        TextView tv_comment_user_name;
        TextView tv_comment_content;
        TextView tv_comment_time;
        TextView tv_comment_thumb_up;
        ImageView iv_comment_thumb_icon;
        ImageView iv_reply_comment_icon;
        ImageView iv_header_image;

        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_comment_user_name = itemView.findViewById(R.id.tv_comment_user_name);
            tv_comment_content = itemView.findViewById(R.id.tv_comment_content);
            tv_comment_time = itemView.findViewById(R.id.tv_comment_time);
            tv_comment_thumb_up = itemView.findViewById(R.id.tv_comment_thumb_up);
            iv_comment_thumb_icon = itemView.findViewById(R.id.iv_comment_thumb_icon);
            iv_reply_comment_icon = itemView.findViewById(R.id.iv_reply_comment_icon);
            iv_header_image = itemView.findViewById(R.id.iv_header_image);
        }
    }

    public static class CommentViewHolder1 extends CommentViewHolder{

        TextView tv_comment_user_name1;
        TextView tv_comment_content1;
        TextView tv_comment_time1;
        TextView tv_comment_thumb_up1;
        TextView tv_reply_comment_user_name1;
        ImageView iv_comment_thumb_icon1;
        ImageView iv_reply_comment_icon1;
        LinearLayout ll_second_comment1;
        ImageView iv_arrow_icon1;
        ImageView iv_header_image1;
        public CommentViewHolder1(@NonNull View itemView) {
            super(itemView);
            tv_comment_user_name1 = itemView.findViewById(R.id.tv_comment_user_name1);
            tv_comment_content1 = itemView.findViewById(R.id.tv_comment_content1);
            tv_comment_time1 = itemView.findViewById(R.id.tv_comment_time1);
            tv_comment_thumb_up1 = itemView.findViewById(R.id.tv_comment_thumb_up1);
            iv_comment_thumb_icon1 = itemView.findViewById(R.id.iv_comment_thumb_icon1);
            iv_reply_comment_icon1 = itemView.findViewById(R.id.iv_reply_comment_icon1);
            ll_second_comment1 = itemView.findViewById(R.id.ll_second_comment1);
            tv_reply_comment_user_name1 = itemView.findViewById(R.id.tv_reply_comment_user_name1);
            iv_arrow_icon1 = itemView.findViewById(R.id.iv_arrow_icon1);
            iv_header_image1 = itemView.findViewById(R.id.iv_header_image1);
        }
    }

    public static class CommentViewHolder2 extends CommentViewHolder1{

        TextView tv_comment_user_name2;
        TextView tv_comment_content2;
        TextView tv_comment_time2;
        TextView tv_comment_thumb_up2;
        TextView tv_reply_comment_user_name2;
        ImageView iv_comment_thumb_icon2;
        ImageView iv_reply_comment_icon2;
        LinearLayout ll_second_comment2;
        ImageView iv_arrow_icon2;
        ImageView iv_header_image2;
        public CommentViewHolder2(@NonNull View itemView) {
            super(itemView);
            tv_comment_user_name2 = itemView.findViewById(R.id.tv_comment_user_name2);
            tv_comment_content2 = itemView.findViewById(R.id.tv_comment_content2);
            tv_comment_time2 = itemView.findViewById(R.id.tv_comment_time2);
            tv_comment_thumb_up2 = itemView.findViewById(R.id.tv_comment_thumb_up2);
            iv_comment_thumb_icon2 = itemView.findViewById(R.id.iv_comment_thumb_icon2);
            iv_reply_comment_icon2 = itemView.findViewById(R.id.iv_reply_comment_icon2);
            ll_second_comment2 = itemView.findViewById(R.id.ll_second_comment2);
            tv_reply_comment_user_name2 = itemView.findViewById(R.id.tv_reply_comment_user_name2);
            iv_arrow_icon2 = itemView.findViewById(R.id.iv_arrow_icon2);
            iv_header_image2 = itemView.findViewById(R.id.iv_header_image2);
        }
    }


    public static class MoreComment extends CommentViewHolder2{

        TextView tv_more_comment_number;
        LinearLayout ll_comment_more_comment;
        public MoreComment(@NonNull View itemView) {
            super(itemView);

            ll_comment_more_comment = itemView.findViewById(R.id.ll_comment_more_comment);
            tv_more_comment_number = itemView.findViewById(R.id.tv_more_comment_number);
        }
    }

}
