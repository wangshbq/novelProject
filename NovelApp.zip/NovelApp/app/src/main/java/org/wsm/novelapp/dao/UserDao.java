package org.wsm.novelapp.dao;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.User;

import java.util.List;

@Dao
public interface UserDao {

    @Query("SELECT *  FROM user WHERE id = :targetUserId AND loginUserId = :currentUserId")
    User getUserById(Integer currentUserId,Integer targetUserId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(User... users);
}
