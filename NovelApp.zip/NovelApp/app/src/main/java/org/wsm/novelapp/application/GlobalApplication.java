package org.wsm.novelapp.application;

import android.annotation.SuppressLint;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.IntentFilter;
import android.os.Build;
import android.util.Log;

import androidx.lifecycle.Observer;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.broadcast.ChatInsertReceiver;
import org.wsm.novelapp.model.ChatViewModel;

import java.util.concurrent.atomic.AtomicBoolean;

public class GlobalApplication extends Application{

    private User user;
    private static GlobalApplication instance;
    //接收socket的消息 加入到sqllite并且通知用户
    private ChatInsertReceiver chatInsertReceiver;
    //用户当前是否在ChatActivity
    private final AtomicBoolean isChatActivity = new AtomicBoolean(false);
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("=========GlobalApplication", "GlobalApplication: ");
        instance = this;
        //创建通知 用户可在前台接收聊天提示
        createNotification();

        //创建广播接收器 此广播作用是收到聊天消息，将消息插入sqllite并通知用户
        registerBroadcast();
    }

    private void createNotification(){
        //创建通知渠道
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "default_channel",
                    "重要通知",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("应用基础通知");

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    private void registerBroadcast(){
        chatInsertReceiver = new ChatInsertReceiver();
        IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction("chat_broadcast_receiver");

        registerReceiver(chatInsertReceiver,intentFilter);
    }


    public static synchronized GlobalApplication getInstance() {
        return instance;
    }
    public void setUser(User user){
        this.user = user;
    }

    public User getUser(){

        return user;
    }

    public boolean isChatActivity() {
        return isChatActivity.get();
    }

    public void setChatActivity(boolean chatActivity) {
        isChatActivity.set(chatActivity);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        // 应用销毁时移除观察者（按需调用）
        Log.d("=====onTerminate", "销毁onTerminate");
//        if (messageObserver != null && chatViewModel != null) {
//            chatViewModel.getMessageLiveData().removeObserver(messageObserver);
//        }
    }



}