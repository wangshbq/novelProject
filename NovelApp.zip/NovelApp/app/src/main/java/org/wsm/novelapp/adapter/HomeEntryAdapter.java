package org.wsm.novelapp.adapter;

import static org.wsm.novelapp.common.CommonMethod.handleShowTime;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.VISIT_NOVEL;
import static org.wsm.novelapp.utils.RequestUtil.REFRESH;
import static org.wsm.novelapp.utils.RequestUtil.TOKEN;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.wsm.novelapp.R;
import org.wsm.novelapp.bean.HomeEntryBean;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.home.ShowNovelActivity;
import org.wsm.novelapp.utils.RequestUtil;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeEntryAdapter extends RecyclerView.Adapter<HomeEntryAdapter.CustomViewHolder> implements View.OnClickListener {

    private final Context context;
    private final List<HomeEntryBean> datas;
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private Integer position;

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public HomeEntryAdapter(Context context, List<HomeEntryBean> datas, ActivityResultLauncher<Intent> activityResultLauncher) {
        this.datas = datas;
        this.context = context;
        this.activityResultLauncher = activityResultLauncher;
    }

    @SuppressLint("MissingInflatedId")
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.item_home_entry, parent, false);

        inflate.findViewById(R.id.ll_home_entry).setOnClickListener(this);

        return new CustomViewHolder(inflate);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        HomeEntryBean homeEntryBean = datas.get(position);

        holder.tv_title.setText(homeEntryBean.getTitle());
        holder.tv_content.setText(homeEntryBean.getContent());
        holder.tv_author.setText(homeEntryBean.getAuthorName());

        holder.tv_comment_number.setText(homeEntryBean.getCommentNumber().toString());
        holder.tv_page_views_number.setText(homeEntryBean.getPageViews().toString());
        Date time = homeEntryBean.getTime();
        if(time != null) holder.tv_time.setText(handleShowTime(time.toString()));

        holder.ll_home_entry.setTag(position);

    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        if(id == R.id.ll_home_entry){
            //判断是否登录
            if(TOKEN.isEmpty() || REFRESH.isEmpty()){
                ((Activity) context).runOnUiThread(() -> Toast.makeText(context,"请登录", Toast.LENGTH_SHORT).show());
                return;
            }

            //请求服务器获取小说内容
            int position = (int)v.getTag();
            HomeEntryBean homeEntryBean = datas.get(position);

            RequestUtil requestUtil = new RequestUtil((Activity) context, new RequestUtil.ResponseListen() {
                @Override
                public void handleResponse(Result result) throws IOException {

                    if(result.getCode() != 1){
                        ((Activity) context).runOnUiThread(() -> Toast.makeText(context, result.getMsg(), Toast.LENGTH_SHORT).show());
                    }else{
                        Map<String, String> map = result.getData();
                        String novels = map.get("novelDto");

                        Intent intent = new Intent(context, ShowNovelActivity.class);
                        intent.putExtra("novels", novels);
                        intent.putExtra("commentNumber", homeEntryBean.getCommentNumber());
                        intent.putExtra("authorName",homeEntryBean.getAuthorName());

                        intent.putExtra("userId",homeEntryBean.getUserId());
                        setPosition(position);
                        activityResultLauncher.launch(intent);
//                        context.startActivity(intent);
                    }
                }
            });

            Map<String, String> map = new HashMap<>();
            map.put("novelId",homeEntryBean.getNovelId() + "");
            requestUtil.GetRequest(map,VISIT_NOVEL);

        }
    }

    public static class CustomViewHolder extends RecyclerView.ViewHolder{

        TextView tv_content;
        TextView tv_title;
        TextView tv_author;
        TextView tv_comment_number;
        TextView tv_page_views_number;
        TextView tv_time;
        LinearLayout ll_home_entry;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_content = itemView.findViewById(R.id.tv_content);
            tv_author = itemView.findViewById(R.id.tv_author);
            tv_comment_number = itemView.findViewById(R.id.tv_comment_number);
            tv_page_views_number = itemView.findViewById(R.id.tv_page_views_number);
            tv_time = itemView.findViewById(R.id.tv_time);
            ll_home_entry = itemView.findViewById(R.id.ll_home_entry);

        }
    }
}
