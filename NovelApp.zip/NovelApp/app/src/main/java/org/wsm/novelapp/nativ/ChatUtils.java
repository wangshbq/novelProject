package org.wsm.novelapp.nativ;

import android.os.Looper;
import android.util.Log;

public class ChatUtils {
//    private static volatile boolean isLibraryLoaded = false;
//    private static final Object loadLock = new Object();
//
//    static {
//        System.loadLibrary("chatUtils");
//    }
//    public static native boolean initConnect();
    // 提供显式主线程加载方法
//    public static void ensureLoadInMainThread() {
//
//        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
//            Log.d("======>ensureLoadInMainThread", "ensureLoadInMainThread");
//            loadLibrarySafely();
//        } else {
//            Log.w("ChatUtils", "Warning: Library should be loaded in main thread!");
//        }
//    }

//    private static void loadLibrarySafely() {
//        synchronized (loadLock) {
//            if (!isLibraryLoaded) {
//                Log.d("======>loadLibrary", "loadLibrary");
//                System.loadLibrary("chatUtils");
//                isLibraryLoaded = true;
//            }
//        }
//    }




}
