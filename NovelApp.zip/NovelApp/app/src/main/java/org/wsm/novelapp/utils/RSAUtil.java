package org.wsm.novelapp.utils;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.math.BigInteger;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSAUtil {

    public static String publicKeyBase64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAolHu2HQTf68pihhM0ntsJREB6ZhhaGBpdjxOMGTBX5fMRVEskyvlrbStsV6Ab3s93fJDDB3x+p/HXOualHhBmZbg+7n8GxQTXdttuuAUaLKbSNlDGIjg4oXw6dQYdYygy2GmQaQkz1hxcD8V7VbcvRut0voQW2YfL8IAITNUUWBwD3H7U9d6PYt4Z9E7KjmxDZJafkkkqy8BpRWyF5ujS9wxPpuLrQS5OQAH7Lt5t6doJ6f/88sTjxfV0j+PklMyEDRwI7gdYxCpHwl3++E78ZUCjBhCRcg2Wu7pPFdqhm71ImB+5A4kPWgd2h6j0WXwRO9qeEf4briJL/L7muT8JwIDAQAB";
    public static String privateKeyBase64 = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCiUe7YdBN/rymKGEzSe2wlEQHpmGFoYGl2PE4wZMFfl8xFUSyTK+WttK2xXoBvez3d8kMMHfH6n8dc65qUeEGZluD7ufwbFBNd22264BRosptI2UMYiODihfDp1Bh1jKDLYaZBpCTPWHFwPxXtVty9G63S+hBbZh8vwgAhM1RRYHAPcftT13o9i3hn0TsqObENklp+SSSrLwGlFbIXm6NL3DE+m4utBLk5AAfsu3m3p2gnp//zyxOPF9XSP4+SUzIQNHAjuB1jEKkfCXf74TvxlQKMGEJFyDZa7uk8V2qGbvUiYH7kDiQ9aB3aHqPRZfBE72p4R/huuIkv8vua5PwnAgMBAAECggEAE0OqFyJflg3R3kPYCjr/sL59/Z1KIjsfCRtLJE8w7Al2AtwJcEYLcjw5SQ2wLIrx4r932Z5MM7R20r5bkDddgb74YKfIFeaiDceXFFC3210nNNQkNGs6VWgUGYxEgt73zmt+cdfrTnhuriWukoZ2mDMKxDlNa6uJE//wSABxh168DynshYuWrgMWBFXwneJ4vw0iKrIxYCVlnlMja8RKR2hQTUFJU3Bfa/YJr/ezk76NCWjl+4U8RFO0O+WN4lLJdG94Ns/yujFzvCOt/43kL/PiN5sryaXlV5MW1hKxm/oml8kXnHLoaN7vWyOtMsYXJknpUmdk0FphUhbYIAhUMQKBgQC4xE22ZevVQ0lWH5/RWS/2Ht8FWRJr0pTer2IgkWKShBjeQUgucSTQVkhvWFPF7Gk3bFgiFZzJ+ed3atkOy9aKmE8Rat5AXRmvj1d0ofzL6mIDQdoRB/A6aelq4m2MIKb2e6Yylurol16YCvcf+k233F9ErX0LGEcKcUvVcYGPQwKBgQDg5jrbsKHYZr+ZP/dSpr3Prvv3Faq00cvoxzPwWcylwY5HBfZl1VOazd4umTsFXxXg83bbJ7wmpKi/UF43URiKAOquOz+UrNRaNVWnWcOqF6dOsZxpCSB+GSlbB6VJrEodhq40r0SlC121ItoXeYMw9SJLsq0y/ZqU6bK6Piy3TQKBgDusOqUD+cygtJi6EfWc5l6IzeJ+R/LGygm5fumhysIjI5z0XImTRR58H1zGnBe6KKkbtsMbU83vhhANVBjxQFL2qeKoLyt+ZgNLOiWTA4AgLJN8ux7w/2b+OcKpalPtX78PZDfGgguoh4Z3VCThxCPzallV5qKkrpzyxlkjFYLdAoGBAI4aq2IZL4qPEc2Bj4LX/ON3i5nKRPzP+2nwRK8/7oFl1cKmz9P0gUk1f4guJg70z9w9ugIsD0TTkhSgcYe+ZCT/A0poAXqt4dfGD4MYwvt8yqh8rXno3HEQ8QKlyBjPFl2ltflwLY2jquhDR07B5tVObwcptSqc98nUCKyJkLOZAoGAOYo4A3aWcJwrBtm1I3pgFGQojT1DTjfoc9Wh7HoXGSUv/b2o6tsa5qLYx7zOt3nCFaHXjmB4U6eu0GWHjw8rmI8illKzeAWC5b82HGj8Awk99EjP9waJDozUa5dIOwIZUxCqXzQhrtwrb6/nUQ5+ZBIhncxy3tAvbCDtWZJTw0I=";
    private static final int MAX_DECRYPT_BLOCK = 256; // 对于 2048 位密钥
    public static String[] createRSA(){
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;
        try {
            // 创建 RSA 密钥对生成器
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(2048); // 设置密钥长度

            // 生成密钥对
            KeyPair keyPair = keyPairGenerator.generateKeyPair();
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            // 将私钥转换为 Base64
            String privateKeyBase64 = Base64.getEncoder().encodeToString(privateKey.getEncoded());
            String publicKeyBase64 = Base64.getEncoder().encodeToString(publicKey.getEncoded());

            String strs[] = {privateKeyBase64,publicKeyBase64};

            return strs;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String encode(String originalMessage) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;
        // 解码 Base64 公钥
        byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyBase64);

        // 构建公钥对象
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);

        // 使用公钥加密
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(1, publicKey);
        byte[] encryptedMessage = cipher.doFinal(originalMessage.getBytes());

        // 打印加密后的消息的 Base64 编码
        String encryptedBase64 = Base64.getEncoder().encodeToString(encryptedMessage);

        return encryptedBase64;
    }

    public static String decode(String message) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return null;
        // 解码 Base64 私钥
        byte[] privateKeyBytes = Base64.getDecoder().decode(privateKeyBase64);

        // 构建私钥对象
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

        // 解码加密消息
        byte[] encryptedMessage = Base64.getDecoder().decode(message);

        // 创建 Cipher 实例，确保使用相同的填充方式
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(2, privateKey);

        // 分块解密
        byte[] decryptedMessage = new byte[0];
        int offset = 0;
        while (offset < encryptedMessage.length) {
            int remaining = encryptedMessage.length - offset;
            int blockSize = Math.min(remaining, MAX_DECRYPT_BLOCK);
            byte[] block = cipher.doFinal(encryptedMessage, offset, blockSize);
            decryptedMessage = concatenateArrays(decryptedMessage, block);
            offset += blockSize;
        }

        // 返回解密后的消息
        return new String(decryptedMessage);
    }
    // 合并字节数组的辅助方法
    private static byte[] concatenateArrays(byte[] array1, byte[] array2) {
        byte[] result = new byte[array1.length + array2.length];
        System.arraycopy(array1, 0, result, 0, array1.length);
        System.arraycopy(array2, 0, result, array1.length, array2.length);
        return result;
    }



}
