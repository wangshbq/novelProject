package org.wsm.novelapp.ui.home;

import static org.wsm.novelapp.common.CommonMethod.handleShowTime;
import static org.wsm.novelapp.common.Constants.COMMENT_THUMBS_UP;
import static org.wsm.novelapp.common.Constants.GET_SECOND_COMMENTS;
import static org.wsm.novelapp.common.Constants.GSON;
import static org.wsm.novelapp.common.Constants.INSERT_COMMENT_A;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.R;
import org.wsm.novelapp.adapter.CommentAdapter;
import org.wsm.novelapp.adapter.SecondCommentAdapter;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.CommentBean;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.dto.CommentDto;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class SecondCommentActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_second_comment_user_name;
    private TextView tv_second_comment_content;
    private TextView tv_second_comment_time;
    private ImageView iv_second_comment_thumb_icon;
    private TextView tv_second_comment_thumb_up;
    private TextView tv_second_comment_number;
    private RecyclerView rv_second_comment_list;
    //当前一级评论id
    private String firstComment;
    //当前一级评论用户名
    private String userName;
    //当前所在的小说id
    private String novelId;
    //此二级评论在服务器的所有数量
    private Integer secondCommentNumber;
    private Integer currentPage = 0;
    private RequestUtil getSecondComment;
    private List<CommentBean> datas = new ArrayList<>();
    private SecondCommentAdapter secondCommentAdapter;

    private long lastLoadTime = 0; // 记录上次加载的时间
    private static final long LOAD_THRESHOLD = 1000; // 1秒内只加载一次

    private boolean isBottomRemind = false;
    private int isThumbUp;
    private int thumbUpNumber;
    //此评论在datas的位置
    private int position;
    private TextView et_input_second_comment;
    private BottomSheetDialog bottomSheetDialog;
    private EditText et_input_comment_dialog;
    private boolean isClearInputComment = false;
    private String inputComment = "";
    private RequestUtil sendComment;
    //当前加载的所有评论id
    private final List<Integer> currentCommentIds = new ArrayList<>();
    //当前一级评论的用户id
    private Integer userId;

    @SuppressLint({"SetTextI18n", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_comment);

        Toolbar tb_second_comment_head = findViewById(R.id.tb_second_comment_head);
        tb_second_comment_head.setNavigationOnClickListener(view -> {
            setIncreaseComment();
            finish();
        });

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                setIncreaseComment();
                finish();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);

        //当前一级评论id
        Intent intent = getIntent();
        firstComment = intent.getStringExtra("commentId");
        userName = intent.getStringExtra("userName");
        novelId = intent.getStringExtra("novelId");

        String content = intent.getStringExtra("content");
        String publicTime = intent.getStringExtra("publicTime");
        userId = intent.getIntExtra("userId", 0);
        thumbUpNumber = intent.getIntExtra("thumbUpNumber", 0);
        isThumbUp = intent.getIntExtra("isThumbUp", 0);
        position = intent.getIntExtra("position", 0);
        secondCommentNumber = intent.getIntExtra("secondCommentNumber", 0);

        tv_second_comment_user_name = findViewById(R.id.tv_second_comment_user_name);
        tv_second_comment_content = findViewById(R.id.tv_second_comment_content);
        tv_second_comment_time = findViewById(R.id.tv_second_comment_time);
        iv_second_comment_thumb_icon = findViewById(R.id.iv_second_comment_thumb_icon);
        tv_second_comment_thumb_up = findViewById(R.id.tv_second_comment_thumb_up);
        tv_second_comment_number = findViewById(R.id.tv_second_comment_number);
        et_input_second_comment = findViewById(R.id.et_input_second_comment);

        tv_second_comment_user_name.setText(userName);
        tv_second_comment_content.setText(content);
        tv_second_comment_time.setText(handleShowTime(publicTime));
        tv_second_comment_thumb_up.setText(thumbUpNumber + "");
        tv_second_comment_number.setText(secondCommentNumber + "");

        if(isThumbUp == 0)
            iv_second_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_border_35);
        else
            iv_second_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_35);

        iv_second_comment_thumb_icon.setOnClickListener(this);
        et_input_second_comment.setOnClickListener(this);

        //跳转到对方个人中心
        findViewById(R.id.iv_head_image).setOnClickListener(this);
        findViewById(R.id.tv_second_comment_user_name).setOnClickListener(this);


        SwipeRefreshLayout sr_second_comment_list = findViewById(R.id.sr_second_comment_list);

        //下拉刷新
        sr_second_comment_list.setOnRefreshListener(() -> {
            resumeData();
            //停止刷新动画
            sr_second_comment_list.setRefreshing(false);
        });

        rv_second_comment_list = findViewById(R.id.rv_second_comment_list);
        rv_second_comment_list.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL,false));

        //请求获取二级评论
        getSecondComment = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void handleResponse(Result result) throws IOException {
                if(result.getCode() == 1){

                    Map<String, String> data = result.getData();
                    String secondComments = data.get("secondComments");

                    Type type = new TypeToken<List<CommentDto>>() {}.getType();

                    List<CommentDto> commentDtos = GSON.fromJson(secondComments, type);

                    if(commentDtos != null){
                        for(CommentDto commentDto: commentDtos){

                            currentCommentIds.add(commentDto.getId());

                            CommentBean commentBean = new CommentBean();

                            commentBean.setNovelId(Integer.parseInt(novelId));

                            commentBean.setCommentId(commentDto.getId());

                            commentBean.setCommentContent(commentDto.getContent());

                            commentBean.setThumbUpNumber(commentDto.getThumbsUp());

                            commentBean.setUserName(commentDto.getUsername());

                            commentBean.setPublishTime(commentDto.getCommentTime());

                            commentBean.setIsThumbsUp(commentDto.getIsThumbsUp());

                            Integer parentId = commentDto.getParentId();

                            commentBean.setParentId(parentId);

                            Integer replyCommentId = commentDto.getReplyCommentId();

                            if(replyCommentId.equals(parentId)){
                                commentBean.setReplyUserName(userName);
                            }else{
                                for (CommentBean commentBean1: datas){
                                    if(commentBean1.getCommentId().equals(replyCommentId)){
                                        commentBean.setReplyUserName(commentBean1.getUserName());
                                        break;
                                    }
                                }
                            }
                            datas.add(commentBean);
                        }


                        if(commentDtos.size() < 8) isBottomRemind = true;

                        runOnUiThread(() -> {

                            secondCommentAdapter.notifyDataSetChanged();

                            if(isBottomRemind)
                                Toast.makeText(SecondCommentActivity.this,"已经到底了~",Toast.LENGTH_SHORT).show();
                        });
                    }
                }
            }
        });

        //发送评论的请求
        sendComment = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
            @Override
            public void handleResponse(Result result) throws IOException {

                if (result.getCode() == 1) {


                    if(bottomSheetDialog != null) bottomSheetDialog.dismiss();

                    Map<String, String> data = result.getData();
                    String commentDtoStr = data.get("commentDto");
                    Type commentDtoType = new TypeToken<CommentDto>() {}.getType();

                    CommentDto commentDto = GSON.fromJson(commentDtoStr, commentDtoType);
                    GlobalApplication application = (GlobalApplication) getApplication();
                    User user = application.getUser();
                    if (commentDto != null) {
                        //新发了一条评论
                        secondCommentNumber++;
                        currentCommentIds.add(commentDto.getId());
                        CommentBean commentBean = new CommentBean();
                        commentBean.setCommentContent(commentDto.getContent());
                        commentBean.setUserName(user.getUsername());
                        Integer thumbsUp = commentDto.getThumbsUp();
                        commentBean.setThumbUpNumber(thumbsUp == null ? 0 : thumbsUp);

                        commentBean.setPublishTime(commentDto.getCommentTime());

                        commentBean.setNovelId(Integer.parseInt(novelId));

                        commentBean.setCommentId(commentDto.getId());

                        commentBean.setIsThumbsUp(0);

                        Integer parentId = commentDto.getParentId();
                        commentBean.setParentId(parentId);
                        commentBean.setSecondCommentNumber(0);

                        Integer replyCommentId = commentDto.getReplyCommentId();

                        if(replyCommentId != null){
                            if(replyCommentId.equals(parentId)){
                                commentBean.setReplyUserName(userName);
                            }else{
                                for (CommentBean commentBean1: datas){
                                    if(commentBean1.getCommentId().equals(replyCommentId)){
                                        commentBean.setReplyUserName(commentBean1.getUserName());
                                        break;
                                    }
                                }
                            }
                        }


                        datas.add(commentBean);
                    }

                    runOnUiThread(() -> {
                        Toast.makeText(SecondCommentActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show();
                        tv_second_comment_number.setText(secondCommentNumber + "");
//                        commentAdapter.notifyDataSetChanged();
                    });
                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(SecondCommentActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });

        //适配器
        secondCommentAdapter = new SecondCommentAdapter(this,datas,sendComment);
        //控件绑定适配器
        rv_second_comment_list.setAdapter(secondCommentAdapter);

        //上滑刷新
        rv_second_comment_list.addOnScrollListener(new RecyclerView.OnScrollListener(){
            @Override
            public void  onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if(dy <= 0) return;
                // 获取布局管理器
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();

                // 获取当前可见的 item 数量
                int visibleItemCount = Objects.requireNonNull(layoutManager).getChildCount();

                // 获取总的 item 数量
                int totalItemCount = layoutManager.getItemCount();

                // 获取第一个可见的 item 的位置
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();

                if ((visibleItemCount + firstVisibleItemPosition) >= (totalItemCount - 1)) {
                    long currentTime = System.currentTimeMillis();
                    // && isScrolled.compareAndSet(true,false)
                    if(currentTime - lastLoadTime > LOAD_THRESHOLD){
                        lastLoadTime = currentTime;
                        // 加载更多数据
                        requestComment();
                    }
                }
            }
        });


        requestComment();
    }

    private void requestComment(){
        //若到底则return
        if(isBottomRemind) return;

        currentPage++;

        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("firstCommentId",firstComment);
//            jsonObject.put("start",((currentPage - 1) * 8) + "");
            jsonObject.put("novelId",novelId);
            jsonObject.put("start",((currentPage - 1) * 8) + "");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        new Thread(() -> getSecondComment.PostRequest(jsonObject.toString(),GET_SECOND_COMMENTS)).start();
    }

    private void resumeData(){
        currentPage = 0;
        isBottomRemind = false;
        datas.clear();
        currentCommentIds.clear();
        requestComment();

    }

    private void setIncreaseComment(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra("isThumbUp", isThumbUp);
        resultIntent.putExtra("thumbUpNumber",thumbUpNumber);
        resultIntent.putExtra("position",position);
        resultIntent.putExtra("secondCommentNumber",secondCommentNumber);
        setResult(RESULT_OK, resultIntent);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        //对一级评论点赞
        if(id == R.id.iv_second_comment_thumb_icon && isThumbUp == 0){

            Map<String, String> map = new HashMap<>();

            map.put("novelId",novelId);
            map.put("commentId",firstComment);
            map.put("parentId","0");
            new Thread(() -> {
                new RequestUtil(this, new RequestUtil.ResponseListen() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void handleResponse(Result result) throws IOException {

                        if(result.getCode() == 1){
                            isThumbUp = 1;
                            iv_second_comment_thumb_icon.setImageResource(R.drawable.baseline_favorite_35);
                            thumbUpNumber++;
                            runOnUiThread(() -> tv_second_comment_thumb_up.setText(thumbUpNumber + ""));
                        }
                    }
                }).GetRequest(map,COMMENT_THUMBS_UP);
            }).start();

        }else if(id == R.id.et_input_second_comment){
            handleBottomSheetDialog();
        }else if(id == R.id.tv_publish_comment){
            String content = et_input_comment_dialog.getText().toString();

            if(content.isEmpty()){
                Toast.makeText(this,"内容不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            if(content.length() > 1000){
                Toast.makeText(this,"字数不能超过1000",Toast.LENGTH_SHORT).show();
                return;
            }

            isClearInputComment = true;

            JSONObject jsonObject = new JSONObject();

            try {
                jsonObject.put("novelId",novelId);
                jsonObject.put("content",content);
                jsonObject.put("parentId",firstComment);

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            new Thread(() -> sendComment.PostRequest(jsonObject.toString(),INSERT_COMMENT_A)).start();

        }else if(id == R.id.tv_second_comment_user_name || id == R.id.iv_head_image){

            Intent intent = new Intent(this, PersonCenterActivity.class);
            intent.putExtra("authorUserId",userId);
            intent.putExtra("authorName",userName);
            startActivity(intent);
        }
    }

    private void handleBottomSheetDialog(){
        // 创建 BottomSheetDialog
        bottomSheetDialog = new BottomSheetDialog(this);
        View bottom_dialog_input_comment = getLayoutInflater().inflate(R.layout.bottom_dialog_input_comment, null);
        bottomSheetDialog.setContentView(bottom_dialog_input_comment);
        et_input_second_comment.setVisibility(View.GONE);
        bottomSheetDialog.show();
        //用户输入评论框
        et_input_comment_dialog = bottom_dialog_input_comment.findViewById(R.id.et_input_comment_dialog);
        //点击发布的按钮
        TextView tv_publish_comment = bottom_dialog_input_comment.findViewById(R.id.tv_publish_comment);
        tv_publish_comment.setOnClickListener(this);

        // 设置销毁监听器
        bottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                //显示点击评论按钮
                et_input_second_comment.setVisibility(View.VISIBLE);
                if(isClearInputComment){//发送评论时的销毁
                    inputComment = "";
                    isClearInputComment = false;
                }else{//用户自己销毁 例如按返回键
                    inputComment = et_input_comment_dialog.getText().toString();
                }
            }
        });

        //弹出键盘
        et_input_comment_dialog.post(() -> {
            //设置选中焦点
            et_input_comment_dialog.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            et_input_comment_dialog.setText(inputComment);
            if (imm != null) {
                imm.showSoftInput(et_input_comment_dialog, InputMethodManager.SHOW_IMPLICIT);
            }
        });

    }
}