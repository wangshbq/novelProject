package org.wsm.novelapp.nativ;


public class EncryptUtils {

    static {
//        System.out.println("Library path1: " + System.getProperty("java.library.path"));
        System.loadLibrary("encrypt");
    }

    public static native String AESEncode(String plainText);

    public static native String AESDecode(String cipherText);

    public static native String SHA256(String plainText);


}
