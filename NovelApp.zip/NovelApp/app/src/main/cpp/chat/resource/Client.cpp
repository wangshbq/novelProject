//#include <jni.h>
#include "../include/Client.h"
#include <android/log.h>

#include <utility>
#define TAG "===========> "
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG,__VA_ARGS__);



//jmethodID ChatClient::chatConstructor = nullptr;

std::shared_ptr<ChatClient> ChatClient::chatClient = nullptr;

//JNIEnv* ChatClient::env = nullptr;

jobject ChatClient::viewModelInstance = nullptr;
jobject ChatClient::chatObj = nullptr;
JavaVM* ChatClient::g_vm = nullptr;  // 必须定义！
//jclass ChatClient::viewModelClass = nullptr;
//jclass ChatClient::chatClass = nullptr;
jmethodID ChatClient::postMethod = nullptr;
jmethodID ChatClient::setContent = nullptr;
jmethodID ChatClient::setUserId = nullptr;
std::string ChatClient::token;

std::atomic<bool> ChatClient::thread_running = false;
int ChatClient::client_socket_ = -1;

ChatClient::ChatClient(std::string  host, int port)
            : host_(std::move(host)), port_(port), epoll_fd_(-1),
              timer_fd_(-1), connected_(false) {}

ChatClient::~ChatClient() {
    if (client_socket_ != -1) close(client_socket_);
    if (epoll_fd_ != -1) close(epoll_fd_);
    if (timer_fd_ != -1) close(timer_fd_);
}

bool ChatClient::init(int user_id){
    user_id_ = user_id;
    // 创建socket
    client_socket_ = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket_ == -1) {
        perror("socket creation failed");
        return false;
    }

    // 设置非阻塞
    int flags = fcntl(client_socket_, F_GETFL, 0);
    if (fcntl(client_socket_, F_SETFL, flags | O_NONBLOCK) == -1) {
        perror("fcntl failed");
        return false;
    }

    // 创建epoll实例
    epoll_fd_ = epoll_create1(0);
    if (epoll_fd_ == -1) {
        perror("epoll_create1 failed");
        return false;
    }
    return true;
}

bool ChatClient::connectToServer() {
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_);

    if (inet_pton(AF_INET, host_.c_str(), &server_addr.sin_addr) <= 0) {
        perror("inet_pton failed");
        return false;
    }

    int ret = connect(client_socket_, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if (ret < 0) {
        if (errno != EINPROGRESS) {
            perror("connect failed");
            return false;
        }
    }

    // 添加socket到epoll监控
    struct epoll_event event;
    //连接完成后会触发写事件
    event.events = EPOLLOUT | EPOLLET | EPOLLRDHUP;
    event.data.fd = client_socket_;
    if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, client_socket_, &event) == -1) {
        perror("epoll_ctl failed");
        return false;
    }


    return true;
}

void ChatClient::run() {
    struct epoll_event events[MAX_EVENTS];
    while (thread_running) {
        LOGD("===============epoll_wait1===================")
        int num_events = epoll_wait(epoll_fd_, events, MAX_EVENTS, -1);
        LOGD("===============epoll_wait2===================")
        if(!thread_running){
            LOGD("===============thread_running false===================")
            closeClient();
            break;
        }
        if (num_events == -1) {
            perror("epoll_wait failed");
            break;
        }

        for(int i = 0; i < num_events; ++i){
            if(events[i].data.fd == client_socket_){
                if(events[i].events & EPOLLOUT){
                    // 处理连接完成或可写事件
                    if(!connected_){
                        LOGD("========触发连接事件==============")
                        handleConnect();
                    }else{
                        LOGD("========触发写事件==============")
                        handleWrite();
                    }
                }

                if(events[i].events & EPOLLIN){
                    LOGD("========触发读事件==============")
                    // 处理可读事件
                    handleRead();
                }

                if(events[i].events & (EPOLLERR | EPOLLHUP)){
                    // 错误或挂起
                    LOGD("==============Socket error or hangup================")
                    closeClient();
                    return;
                }
            }
        }
    }
}

void ChatClient::sendToken(){
    std::string token_message;

    std::map<std::string,std::string> map;
    map["token"] = token;
    LOGD("========toekn: %s",map["token"].data())

    handleMessage_.buildMessage(map,token_message);

    write_buffer_.insert(write_buffer_.end(), token_message.begin(), token_message.end());

    // 关键：添加EPOLLOUT监控
    struct epoll_event event;
    event.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;  // 保持原有事件并添加OUT
    event.data.fd = client_socket_;
    if (epoll_ctl(epoll_fd_, EPOLL_CTL_MOD, client_socket_, &event) == -1) {
        perror("epoll_ctl mod failed");
        closeClient();
        return;
    }
}

/**
 * 发送消息
 * @param receive_user_id 接收者的userId
 * @param msg 消息内容
 */
void ChatClient::enqueueMessage(const std::string& receive_user_id,const std::string& msg) {
    std::string message;

    std::map<std::string,std::string> map;
    map["to"] = receive_user_id;
    map["from"] = std::to_string(user_id_);
    map["content"] = msg;

    handleMessage_.buildMessage(map,message);

    write_buffer_.insert(write_buffer_.end(), message.begin(), message.end());

    // 关键：添加EPOLLOUT监控
    struct epoll_event event;
    event.events = EPOLLIN | EPOLLOUT | EPOLLET | EPOLLRDHUP;  // 保持原有事件并添加OUT
    event.data.fd = client_socket_;
    if (epoll_ctl(epoll_fd_, EPOLL_CTL_MOD, client_socket_, &event) == -1) {
        perror("epoll_ctl mod failed");
        closeClient();
        return;
    }
}

/**
 * 处理连接事件
 */
void ChatClient::handleConnect(){
    int error = 0;
    socklen_t len = sizeof(error);
    //检查是否连接成功
    if(getsockopt(client_socket_, SOL_SOCKET, SO_ERROR, &error, &len) < 0){
        perror("getsockopt failed");
        closeClient();
        return;
    }

    if(error != 0){
        std::cerr << "Connection failed: " << strerror(error) << std::endl;
        closeClient();
        return;
    }

    sendToken();

    connected_ = true;
    std::cout << "Connected to server successfully" << std::endl;

}

/**
 * 处理可读事件
 */
void ChatClient::handleRead(){
    LOGD("===============触发读事件===================")
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;
    std::string content;
    // 边缘触发必须循环读取直到EAGAIN
    while (true) {
        bytes_read = recv(client_socket_, buffer, BUFFER_SIZE, 0);
        if(bytes_read > 0){
            // 处理接收到的数据
            std::string message(buffer,bytes_read);
            content += message;
            std::map<std::string,std::string> map;
            handleMessage_.parseMessage(message,map);

            std::cout << "发送者Id: " << map["send_user_id"] << " content: " << map["content"] << std::endl;

        }else if(bytes_read == 0){
            // 对端关闭连接
            std::cout << "Server closed connection" << std::endl;
            closeClient();
            return;
        }else{
            if(errno == EAGAIN || errno == EWOULDBLOCK){
                LOGD("===============handleRead  EAGAIN===================")

                std::map<std::string,std::string> map;
                handleMessage_.parseMessage(content,map);

                JNIEnv *env;
                g_vm->AttachCurrentThread(&env, nullptr);

                jstring jContent = env->NewStringUTF(map["content"].c_str());
//                env->CallVoidMethod(chatObj, setContent, jContent);
//
//                int user_id = std::stoi(map["send_user_id"]);
//                LOGD("===============user_id: %d",user_id)
//                env->CallVoidMethod(chatObj,setUserId,user_id);
//                LOGD("===============CallVoidMethod")

                env->CallVoidMethod(viewModelInstance, postMethod, jContent);

                env->DeleteLocalRef(jContent);
                return;
            }else{
                // 其他错误
                perror("recv failed");
                closeClient();
                return;
            }
        }
    }
}

/**
 * 写事件
 */
void ChatClient::handleWrite() {
    std::cout << "============handleWrite==============" << std::endl;
    if (write_buffer_.empty()) {
        modifyEpollEvents(EPOLLIN | EPOLLET | EPOLLRDHUP);
        return;
    }

    std::cout << "============准备发送数据给服务器: " << write_buffer_.data() << std::endl;
    // 边缘触发必须循环写入直到EAGAIN或缓冲区空
    while (!write_buffer_.empty()) {
        ssize_t bytes_sent = send(client_socket_, write_buffer_.data(), write_buffer_.size(), MSG_NOSIGNAL);
        if (bytes_sent > 0) {
            write_buffer_.erase(write_buffer_.begin(), write_buffer_.begin() + bytes_sent);
        } else {
            if (errno == EAGAIN || errno == EWOULDBLOCK) {
                std::cout << "============EAGAIN==============" << std::endl;
                modifyEpollEvents(EPOLLIN | EPOLLET | EPOLLRDHUP);
                // 资源暂时不可用，保留剩余数据下次发送
                break;
            } else {
                // 其他错误
                perror("send failed");
                closeClient();
                return;
            }
        }
    }
    modifyEpollEvents(EPOLLIN | EPOLLET | EPOLLRDHUP);

}

void ChatClient::modifyEpollEvents(uint32_t events) {
    struct epoll_event event{};
    event.events = events;
    event.data.fd = client_socket_;
    if (epoll_ctl(epoll_fd_, EPOLL_CTL_MOD, client_socket_, &event) == -1) {
        perror("epoll_ctl mod failed");
        closeClient();
    }

}

void ChatClient::closeClient(){
    LOGD("===============closeClient===================");
    close(client_socket_);
    client_socket_ = -1;
    connected_ = false;
    chatClient = nullptr;
    if(epoll_fd_ != -1) close(epoll_fd_);
    epoll_fd_ = -1;
    thread_running = false;

}
