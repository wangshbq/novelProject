package org.wsm.novelapp;

import static org.wsm.novelapp.common.CommonMethod.stringToUser;
import static org.wsm.novelapp.common.Constants.GET_USER_URL;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.clearLoginData;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.isSavePassword;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.ui.mine.MineFragment;
import org.wsm.novelapp.ui.home.HomeFragment;
import org.wsm.novelapp.ui.notifications.NotificationsFragment;
import org.wsm.novelapp.utils.RequestUtil;
import org.wsm.novelapp.service.SocketService;

import android.Manifest;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;

/**
 * 切换出去socket断开后离开进入界面发送消息可能出问题
 * 多次点击界面进入新的界面
 */
public class MainActivity extends AppCompatActivity {

    private HomeFragment homeFragment;
    private MineFragment mineFragment;
    private NotificationsFragment notificationsFragment;
    private RequestUtil loginRequest;
    private final Context context = this;
    private ActivityResultLauncher<String> stringActivityResultLauncher;
    private static final int REQUEST_CODE_NOTIFICATION_PERMISSION = 1001;
    private Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handler =  new Handler(Objects.requireNonNull(Looper.myLooper())){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what == 0){
                    //销毁
                    handler.removeCallbacksAndMessages(null);
                }else{
                    //连接
//                    SocketUtil.connect();
                    Intent serviceIntent = new Intent(context, SocketService.class);
                    serviceIntent.setFlags(0);//0表示连接
                    context.startService(serviceIntent);
                }
            }
        };
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        selectedFragment(0);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navigation_home) {
                    selectedFragment(0);
                }else if(itemId == R.id.navigation_notifications){
                    selectedFragment(1);
                }else{
                    selectedFragment(2);
                }
                return true;
            }
        });
        //若保存密码则自动登录
        Log.d("===========checkAutoLogin", "检查登录");
        checkAutoLogin();

        // 初始化权限请求回调
        stringActivityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(MainActivity.this, "通知权限已允许", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "通知权限被拒绝", Toast.LENGTH_SHORT).show();
                        // 可以在这里引导用户去设置页手动开启
                    }
                }
        );

        SharedPreferences preferences = getSharedPreferences("config", MODE_PRIVATE);
        //是否有通知过用户要添加通知权限
        boolean alertAddPermission = preferences.getBoolean("alertNotificationPermission", false);

        if(!alertAddPermission){//没有通知过就通知一下
            preferences.edit().putBoolean("alertNotificationPermission",true).apply();
            // 检查并请求通知权限
            checkAndRequestNotificationPermission();
        }
    }

    private void checkAndRequestNotificationPermission() {
        // 只有 Android 13+ 需要请求权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            String permission = Manifest.permission.POST_NOTIFICATIONS;

            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {

                // 检查是否需要显示解释
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                    showPermissionRationaleDialog(permission);
                } else {
                    // 直接请求权限
                    stringActivityResultLauncher.launch(permission);
                }
            }
        }else if (areNotificationsDisabledByRom()) { // 如果是 Android 9-12，检查是否被厂商限制
            new AlertDialog.Builder(this)
                    .setTitle("通知被关闭")
                    .setMessage("请在系统设置中允许通知权限，以免错过重要消息")
                    .setPositiveButton("去设置", (d, w) -> openAppNotificationSettings())
                    .setNegativeButton("暂不", null)
                    .show();
        }
    }

    /**
     * 检查是否被厂商限制通知（适用于 Android 9-12）
     */
    private boolean areNotificationsDisabledByRom() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return false; // Android 13+ 使用标准权限检查
        }

        // 检查是否被 MIUI/EMUI 等 ROM 限制
        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        return !manager.areNotificationsEnabled();
    }


    /**
     * 跳转到应用通知设置页（所有 Android 版本通用）
     */
    private void openAppNotificationSettings() {
        Intent intent = new Intent();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");
            intent.putExtra("app_package", getPackageName());
            intent.putExtra("app_uid", getApplicationInfo().uid);
        }

        startActivity(intent);
    }

    private void showPermissionRationaleDialog(String permission) {
        new AlertDialog.Builder(this)
                .setTitle("需要通知权限")
                .setMessage("是否允许发送通知?")
                .setPositiveButton("允许", (dialog, which) -> {
                    stringActivityResultLauncher.launch(permission);
                })
                .setNegativeButton("拒绝", null)
                .show();
    }

    private void selectedFragment(int position){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        hideFragment(fragmentTransaction);

        if (position == 0) {
            if(homeFragment == null){
                homeFragment = new HomeFragment();

                Fragment existingFragment = getSupportFragmentManager().findFragmentByTag("homeFragment");
                if (existingFragment != null) {
                    // 如果已存在，先移除
                    fragmentTransaction.remove(existingFragment);
                }

                fragmentTransaction.add(R.id.fl_content,homeFragment,"homeFragment");
            }else{
                fragmentTransaction.show(homeFragment);
            }

        }else if(position == 1){

            if(notificationsFragment == null){
                notificationsFragment = new NotificationsFragment();

                Fragment existingFragment = getSupportFragmentManager().findFragmentByTag("notificationsFragment");
                if (existingFragment != null) {
                    // 如果已存在，先移除
                    fragmentTransaction.remove(existingFragment);
                }

                fragmentTransaction.add(R.id.fl_content,notificationsFragment,"notificationsFragment");
            }else{
                fragmentTransaction.show(notificationsFragment);
            }
        }else{

            if(mineFragment == null){
                mineFragment = new MineFragment();

                Fragment existingFragment = getSupportFragmentManager().findFragmentByTag("mineFragment");
                if (existingFragment != null) {
                    // 如果已存在，先移除
                    fragmentTransaction.remove(existingFragment);
                }

                fragmentTransaction.add(R.id.fl_content,mineFragment,"mineFragment");
            }else{
                fragmentTransaction.show(mineFragment);
            }
        }
        fragmentTransaction.commit();
    }

    private void hideFragment(FragmentTransaction fragmentTransaction){

        if(homeFragment != null) fragmentTransaction.hide(homeFragment);

        if(mineFragment != null) fragmentTransaction.hide(mineFragment);

        if(notificationsFragment != null) fragmentTransaction.hide(notificationsFragment);

    }

    /**
     * 检查是否需要自动登录  若保存了密码则尝试自动去登录
     */
    public void checkAutoLogin(){
        SharedPreferences preferences = getSharedPreferences("config", MODE_PRIVATE);
        int currentUserId = preferences.getInt("currentUserId", 0);

        SharedPreferences preferences2 = getSharedPreferences("config:" + currentUserId, MODE_PRIVATE);

        RequestUtil.TOKEN = preferences2.getString("accessToken", "");
        RequestUtil.REFRESH = preferences2.getString("refreshToken","");

        if(RequestUtil.TOKEN.isEmpty() && RequestUtil.REFRESH.isEmpty()) return;

        isSavePassword = true;

        new Thread(() -> new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() == 0){ //错误
                    Log.d("=======result.getCode()", result.getCode() + "");
                    Message message = handler.obtainMessage();
                    message.what = 0;
                    handler.sendMessage(message);
                    runOnUiThread(() -> Toast.makeText(context,result.getMsg(),Toast.LENGTH_SHORT).show());

                }else if(result.getCode() == 1){//成功
                    Log.d("=======result.getCode()", result.getCode() + "");
                    //进入界面之后有必要连接socket
//                    isSocket = true;
                    GlobalApplication application = (GlobalApplication) getApplication();
//                    //设置socket
                    Intent serviceIntent = new Intent(context, SocketService.class);
                    serviceIntent.putExtra("action",0);
                    context.startService(serviceIntent);

                    Map<String,String> map = result.getData();

                    User user = stringToUser(Objects.requireNonNull(map.get("user")));

                    application.setUser(user);

                    Message message = handler.obtainMessage();
                    message.what = 1;
                    handler.sendMessage(message);
                }else if(result.getCode() == 2){//token失效
                    Log.d("=======result.getCode()", result.getCode() + "");
                    Message message = handler.obtainMessage();
                    message.what = 0;
                    handler.sendMessage(message);
                    clearLoginData(context);

                    runOnUiThread(() -> Toast.makeText(context,result.getMsg(),Toast.LENGTH_SHORT).show());
                }
            }
        }).PostRequest("",GET_USER_URL)).start();

    }

    public void exitApp() {
        // 关闭所有 Activity
        finishAffinity();
        // 终止进程
        System.exit(0);
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("=====>", "MainActivity onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("=====>", "MainActivity onStop");
//
//        // 防止内存泄漏的完整清理流程
//        FragmentManager fragmentManager = getSupportFragmentManager();
//
//        // 1. 执行所有待处理事务
//        fragmentManager.executePendingTransactions();
//
//        // 2. 获取所有Fragment并移除
//        List<Fragment> fragments = fragmentManager.getFragments();
//        if (!fragments.isEmpty()) {
//            FragmentTransaction transaction = fragmentManager.beginTransaction();
//            for (Fragment fragment : fragments) {
//                if (fragment != null && fragment.isAdded()) {
//                    transaction.remove(fragment);
//                }
//            }
//            try {
//                transaction.commitNowAllowingStateLoss();
//            } catch (IllegalStateException e) {
//                // 处理可能的状态异常
//            }
//        }
//
//        // 3. 清空回退栈
//        fragmentManager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.d("=====>", "MainActivity onDestroy");


    }
}