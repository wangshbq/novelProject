#ifndef AES_H
#define AES_H

#include <vector>
#include <string>

class AES {
public:
    AES(const std::vector<unsigned char>& key);
    std::vector<unsigned char> encrypt(const std::vector<unsigned char>& plaintext, const std::vector<unsigned char>& iv);
    std::vector<unsigned char> decrypt(const std::vector<unsigned char>& ciphertext, const std::vector<unsigned char>& iv);

private:
    std::vector<unsigned char> key;
    std::vector<std::vector<unsigned char>> keySchedule;

    void keyExpansion();
    void addRoundKey(std::vector<std::vector<unsigned char>>& state, int round);
    void subBytes(std::vector<std::vector<unsigned char>>& state);
    void shiftRows(std::vector<std::vector<unsigned char>>& state);
    void mixColumns(std::vector<std::vector<unsigned char>>& state);
    void invSubBytes(std::vector<std::vector<unsigned char>>& state);
    void invShiftRows(std::vector<std::vector<unsigned char>>& state);
    void invMixColumns(std::vector<std::vector<unsigned char>>& state);
    std::vector<std::vector<unsigned char>> cipher(const std::vector<std::vector<unsigned char>>& input);
    std::vector<std::vector<unsigned char>> invCipher(const std::vector<std::vector<unsigned char>>& input);
    std::vector<std::vector<unsigned char>> blockToState(const std::vector<unsigned char>& block);
    std::vector<unsigned char> stateToBlock(const std::vector<std::vector<unsigned char>>& state);
    std::vector<unsigned char> xorBlocks(const std::vector<unsigned char>& block1, const std::vector<unsigned char>& block2);
    std::vector<unsigned char> iso10126Padding(const std::vector<unsigned char>& data);
    std::vector<unsigned char> iso10126Unpadding(const std::vector<unsigned char>& data);

    unsigned char mul(unsigned char a, unsigned char b);
};

#endif // AES_H