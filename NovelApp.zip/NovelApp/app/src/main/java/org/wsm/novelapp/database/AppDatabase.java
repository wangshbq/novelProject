package org.wsm.novelapp.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import org.wsm.novelapp.bean.Chat;
import org.wsm.novelapp.bean.User;
import org.wsm.novelapp.common.TimestampConverter;
import org.wsm.novelapp.dao.ChatDao;
import org.wsm.novelapp.dao.NovelDao;
import org.wsm.novelapp.dao.UserDao;
import org.wsm.novelapp.dto.NovelDto;

@Database(entities = {NovelDto.class, Chat.class, User.class},version = 2,exportSchema = false)
@TypeConverters({TimestampConverter.class})
public abstract class AppDatabase extends RoomDatabase {
    // 单例模式获取数据库实例
    private static volatile AppDatabase databaseInstance;

    public abstract NovelDao novelDao();

    public abstract ChatDao chatDao();

    public abstract UserDao userDao();

    public static synchronized AppDatabase getInstance(Context context) {

        if (databaseInstance == null) {
            databaseInstance = Room.databaseBuilder(context, AppDatabase.class, "appDatabase")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return databaseInstance;
    }

}
