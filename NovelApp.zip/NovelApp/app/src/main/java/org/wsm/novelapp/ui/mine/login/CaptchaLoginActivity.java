package org.wsm.novelapp.ui.mine.login;

import static org.wsm.novelapp.common.Constants.CAPTCHA_LOGIN_URL;
import static org.wsm.novelapp.common.Constants.SEND_CAPTCHA_URL;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.emailFormVerify;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.getEnhancedFingerprint;
import static org.wsm.novelapp.ui.mine.login.LoginUtils.isSavePassword;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONException;
import org.json.JSONObject;
import org.wsm.novelapp.MainActivity;
import org.wsm.novelapp.R;
import org.wsm.novelapp.application.GlobalApplication;
import org.wsm.novelapp.common.Result;
import org.wsm.novelapp.model.ChatViewModel;
import org.wsm.novelapp.utils.RequestUtil;

import java.io.IOException;

public class CaptchaLoginActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText et_captcha_login_email;
    private EditText et_captcha_login_captcha;
    private RequestUtil loginReq;
    private CheckBox cb_captcha_login_save_password;
    private RequestUtil defaultResponseReq;
    private Button btn_captcha_login_send_captcha;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_captcha_login);

        et_captcha_login_email = findViewById(R.id.et_captcha_login_email);
        et_captcha_login_captcha = findViewById(R.id.et_captcha_login_captcha);
        cb_captcha_login_save_password = findViewById(R.id.cb_captcha_login_save_password);
        btn_captcha_login_send_captcha = findViewById(R.id.btn_captcha_login_send_captcha);

        findViewById(R.id.btn_captcha_login).setOnClickListener(this);
        findViewById(R.id.btn_captcha_login_send_captcha).setOnClickListener(this);

        Toolbar tb_login_head = findViewById(R.id.tb_captcha_login_head);
        tb_login_head.setNavigationOnClickListener(view -> finish());
        //发送验证码
        defaultResponseReq = new LoginUtils().handleDefaultResponse(this);

        loginReq = new RequestUtil(this, new RequestUtil.ResponseListen() {
            @Override
            public void handleResponse(Result result) throws IOException {

                if(result.getCode() == 1){
                    LoginUtils.handleLoginSucResp(CaptchaLoginActivity.this,result);
                    //设置socket
//                    Intent serviceIntent = new Intent(CaptchaLoginActivity.this, ChatService.class);
//                    serviceIntent.setAction("connectAndListen");
//                    CaptchaLoginActivity.this.startService(serviceIntent);

                    LoginUtils.remindAndFinish(CaptchaLoginActivity.this, result.getMsg());
                }else{
                    runOnUiThread(() -> Toast.makeText(CaptchaLoginActivity.this, result.getMsg(), Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        //验证邮箱
        String email = et_captcha_login_email.getText().toString().trim();
        if(!emailFormVerify(email)){
            Toast.makeText(this,"邮箱格式错误",Toast.LENGTH_SHORT).show();
            return;
        }

        int id = v.getId();

        if(id == R.id.btn_captcha_login){//登录
            String captcha = et_captcha_login_captcha.getText().toString().trim();
            if(captcha.isEmpty()){
                Toast.makeText(this,"验证码不能为空",Toast.LENGTH_SHORT).show();
                return;
            }

            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("email",email);
                jsonObject.put("captcha",captcha);
                jsonObject.put("deviceId",getEnhancedFingerprint(this));
                boolean loginStatus = cb_captcha_login_save_password.isChecked();
                jsonObject.put("appSaveTokenStatus",loginStatus ? 1 : 0);
                isSavePassword = loginStatus;
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            new Thread(() -> loginReq.PostRequest(jsonObject.toString(),CAPTCHA_LOGIN_URL)).start();

        }else{//发送验证码
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("email",email);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
            new Thread(() -> defaultResponseReq.PostRequest(jsonObject.toString(),SEND_CAPTCHA_URL)).start();

            //暂时禁用发送验证码的按钮
            new LoginUtils().forbidCaptchaButton(btn_captcha_login_send_captcha);
        }
    }



}