package org.wsm.novelapp.dto;


import androidx.room.Entity;
import androidx.room.Ignore;

import org.wsm.novelapp.bean.Novel;

import java.io.Serializable;


@Entity
public class NovelDto extends Novel implements Serializable {

    private Integer thumbsUp;

    private Integer collect;

    private Integer pageViews;//浏览量

    private Integer commentNumber;
    private String username;

    private Integer isThumbsUp;
    private Integer isSubscribe;

    private Integer loginUserId;//当前存储在sqllite的这条数据是属于谁的

    @Ignore
    public NovelDto(){

    }



    public NovelDto(Integer thumbsUp, Integer collect, Integer pageViews, Integer commentNumber, String username, Integer isThumbsUp) {
        this.thumbsUp = thumbsUp;
        this.collect = collect;
        this.pageViews = pageViews;
        this.commentNumber = commentNumber;
        this.username = username;
        this.isThumbsUp = isThumbsUp;
    }

    public Integer getLoginUserId() {
        return loginUserId;
    }

    public void setLoginUserId(Integer loginUserId) {
        this.loginUserId = loginUserId;
    }

    public Integer getIsSubscribe() {
        return isSubscribe;
    }

    public void setIsSubscribe(Integer isSubscribe) {
        this.isSubscribe = isSubscribe;
    }

    public Integer getThumbsUp() {
        return thumbsUp;
    }

    public void setThumbsUp(Integer thumbsUp) {
        this.thumbsUp = thumbsUp;
    }

    public Integer getCollect() {
        return collect;
    }

    public void setCollect(Integer collect) {
        this.collect = collect;
    }

    public Integer getPageViews() {
        return pageViews;
    }

    public void setPageViews(Integer pageViews) {
        this.pageViews = pageViews;
    }

    public Integer getCommentNumber() {
        return commentNumber;
    }

    public void setCommentNumber(Integer commentNumber) {
        this.commentNumber = commentNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getIsThumbsUp() {
        return isThumbsUp;
    }

    public void setIsThumbsUp(Integer isThumbsUp) {
        this.isThumbsUp = isThumbsUp;
    }

    @Override
    public String toString() {
        return "NovelDto{" +
                "thumbsUp=" + thumbsUp +
                ", collect=" + collect +
                ", pageViews=" + pageViews +
                ", commentNumber=" + commentNumber +
                ", username='" + username + '\'' +
                ", isThumbsUp=" + isThumbsUp +
                '}';
    }
}
