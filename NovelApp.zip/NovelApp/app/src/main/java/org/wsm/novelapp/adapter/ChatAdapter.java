package org.wsm.novelapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.wsm.novelapp.R;
import org.wsm.novelapp.bean.Chat;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder>  {
    private Context context;
    private List<Chat> datas;

    public ChatAdapter(Context context, List<Chat> datas) {
        this.context = context;
        this.datas = datas;
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate;
        if(viewType == 0)
            inflate = LayoutInflater.from(context).inflate(R.layout.item_chat_receive_message, parent, false);
        else
            inflate = LayoutInflater.from(context).inflate(R.layout.item_chat_send_message, parent, false);

        return new ChatViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Chat chat = datas.get(position);

        holder.tv_chat_content.setText(chat.getContent());
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public int getItemViewType(int position) {
        if(datas.get(position).getSend())
            return 1;
        else
            return 0;

    }

    public static class ChatViewHolder extends RecyclerView.ViewHolder{
        //        ImageView iv_subscriber_chat_icon;
        TextView tv_chat_content;
        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_chat_content = itemView.findViewById(R.id.tv_chat_content);
        }
    }
}
