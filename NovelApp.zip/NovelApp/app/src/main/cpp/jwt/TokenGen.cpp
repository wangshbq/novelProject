
//
// Created by 86157 on 2025/4/14.
//
#include <jni.h>
#include <map>
#include "JwtUtils.h"
#include <iostream>
#include <android/log.h>
#define TAG "===========> "
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG,__VA_ARGS__);

extern "C"
JNIEXPORT jobject JNICALL
Java_org_wsm_novelapp_nativ_TokenGen_getExpiration(JNIEnv *env, jclass clazz, jstring token) {
    // TODO: implement getExpiration()
    const char* ctoken = env->GetStringUTFChars(token, nullptr);

    std::string str_token(ctoken);
    size_t pos = str_token.find('|');

    std::string claim;
    if (pos != std::string::npos) {
        std::vector<uint8_t> decode_base64 = Base64::decode(str_token.substr(0, pos));
        claim = urlDecode(std::string(decode_base64.begin(),decode_base64.end()));
    }
//    LOGD("+++++++++++++++++++++++++++++++++++++++++++++")
//    LOGD("%s",claim.c_str())

//    std::vector<uint8_t> decode = Base64::decode(claim);
//    std::string decode_str(decode.begin(),decode.end());
    std::map<std::string, std::string> map = parseClaims(claim);
//    LOGD("%s",map["expiration"].c_str())
    uint64_t ts = std::stoull(map["expiration"]);

    jclass dateClass = env->FindClass("java/util/Date");

    jmethodID dateConstructor = env->GetMethodID(dateClass, "<init>", "(J)V");

    auto jts = static_cast<jlong>(ts);
//"zxHWAxjHDgLVBJ0XnZq0nZK1mtC0nZC0jNvZzxjjzd0ZnG==|U8WDnz8QjC9N4MBvdiCuCU+lZZ5ae6nQlqRzHe2xci4="
//    "refreshToken": "2Rj/3Y3uQtZMuGgyLL47/hpqdmdmNmTGjKs3dpjyBtwmLQeIT7juI5l6Qz8CsgObjnzdJIFBAojtmrq2FJOU4I97ADwFAtFAowzKwYaW9xcOMVK9npDNu40Wviit0bXXhKAHol9Sl5VVYTzoikF0DW==|n9Ds6SpeM5mcR4jCa5kRPH8KhiJGLwiqsHykLUhEyAS="
    jobject date = env->NewObject(dateClass, dateConstructor, jts);

    return date;
}
extern "C"
JNIEXPORT jobject JNICALL
Java_org_wsm_novelapp_nativ_TokenGen_decodeBase64(JNIEnv *env, jclass clazz, jstring token) {
    // TODO: implement decodeBase64()
    const char* c_token = env->GetStringUTFChars(token, nullptr);

    std::map<std::string, std::string> claims = decode_base64(c_token);

    // 获取 Java 的 HashMap 类
    jclass hashMapClass = env->FindClass("java/util/HashMap");

    // 获取 HashMap 的构造函数
    jmethodID hashMapConstructor = env->GetMethodID(hashMapClass, "<init>", "()V");

    // 创建 Java 的 HashMap 对象
    jobject javaMap = env->NewObject(hashMapClass, hashMapConstructor);

    // 获取 HashMap 的 put 方法
    jmethodID putMethod = env->GetMethodID(hashMapClass, "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");

    // 遍历 C++ 的 std::map，将键值对插入到 Java 的 HashMap 中
    for (const auto& entry : claims) {
        jstring key = env->NewStringUTF(entry.first.c_str());
        jstring value = env->NewStringUTF(entry.second.c_str());

        // 调用 HashMap 的 put 方法
        env->CallObjectMethod(javaMap, putMethod, key, value);

        // 释放局部引用
        env->DeleteLocalRef(key);
        env->DeleteLocalRef(value);
    }

    env->ReleaseStringUTFChars(token,c_token);

    return javaMap;
}
