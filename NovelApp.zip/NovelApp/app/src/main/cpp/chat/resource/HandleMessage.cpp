//
// Created by 86157 on 2025/5/28.
//
// URL 解码函数

#include "../include/HandleMessage.h"

// URL 编码函数
std::string HandleMessage::urlEncode(const std::string& str){
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;
    for (char c : str) {
        if (isalnum(c)) {//数字字母下划线不用处理
            escaped << c;
        } else {
            escaped << '%' << std::setw(2) << static_cast<int>(static_cast<unsigned char>(c));
        }
    }
    return escaped.str();
}

std::string HandleMessage::urlDecode(const std::string& str){
    std::ostringstream unescaped;
    for (size_t i = 0; i < str.size(); ++i) {
        if (str[i] == '%' && i + 2 < str.size()) {
            int hexValue;
            std::istringstream hexStream(str.substr(i + 1, 2));
            if (hexStream >> std::hex >> hexValue) {
                unescaped << static_cast<char>(hexValue);
                i += 2;
            } else {
                unescaped << str[i];
            }
        }else {
            unescaped << str[i];
        }
    }
    return unescaped.str();
}

// 解析 claims
void HandleMessage::parseMessage(const std::string& claimsString,std::map<std::string, std::string>& map){
    std::istringstream iss(claimsString);
    std::string token;
    while(std::getline(iss, token, '&')){
        size_t pos = token.find('=');
        if(pos != std::string::npos){
            std::string key = urlDecode(token.substr(0, pos));
            std::string value = urlDecode(token.substr(pos + 1));
            map[key] = value;
        }
    }
}

void HandleMessage::buildMessage(const std::map<std::string,std::string>& map,std::string& message){
    for(const auto& pair: map){
        message += urlEncode(pair.first) + "=" + urlEncode(pair.second) + "&";
    }
    message.pop_back();
}

