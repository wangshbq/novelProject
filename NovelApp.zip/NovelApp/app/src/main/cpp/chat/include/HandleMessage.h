//
// Created by 86157 on 2025/5/28.
//
#pragma once
#ifndef CHATPROJECT_HANDLEMESSAGE_H
#define CHATPROJECT_HANDLEMESSAGE_H
#include <string>
#include <map>
#include <iomanip>
#include <iostream>
#include <sstream>
class HandleMessage{

public:

    void parseMessage(const std::string& claimsString,std::map<std::string, std::string>& map);
    void buildMessage(const std::map<std::string,std::string>& map,std::string& message);

private:

    std::string urlEncode(const std::string& str);

    std::string urlDecode(const std::string& str);
};


#endif //CHATPROJECT_HANDLEMESSAGE_H
