package org.wsm.novelapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.wsm.novelapp.R;

import java.util.List;

public class ShowNovelAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements View.OnClickListener {

    private static final int TYPE_TITLE = 0;
    private static final int TYPE_ITEM = 1;
    private List<String> datas;
    private Context context;

    public ShowNovelAdapter(Context context,List<String> datas){
        this.context = context;
        this.datas = datas;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_TITLE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_novel_title, parent, false);
            return new TitleViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_show_novel_content, parent, false);
            return new ContentViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String content = datas.get(position);
        if (holder instanceof TitleViewHolder titleViewHolder) {
            titleViewHolder.tv_title.setText(content);
        } else {
            ContentViewHolder contentViewHolder = (ContentViewHolder) holder;
            contentViewHolder.tv_content.setText(content);
        }
    }
    @Override
    public int getItemViewType(int position) {
        return position == 0 ? TYPE_TITLE : TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    @Override
    public void onClick(View v) {

    }
    public static class ContentViewHolder extends RecyclerView.ViewHolder{
        TextView tv_content;

        public ContentViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_content = itemView.findViewById(R.id.tv_content);
        }
    }

    public static class TitleViewHolder extends RecyclerView.ViewHolder{
        TextView tv_title;

        public TitleViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);

        }
    }
}
