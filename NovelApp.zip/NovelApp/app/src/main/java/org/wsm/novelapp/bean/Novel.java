package org.wsm.novelapp.bean;


import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import org.wsm.novelapp.common.TimestampConverter;

import java.io.Serializable;
import java.sql.Timestamp;

public class Novel implements Serializable {
    @PrimaryKey
    private Integer id;
    private String title;
    private String content;
    private Integer userId;
    /**
     * 序列化和反序列化时间
     */
//    @JsonSerialize(using = CustomTimestampSerializer.class)
//    @JsonDeserialize(using = CustomTimestampDeserializer.class)
//    @TypeConverters(TimestampConverter.class)
    private Timestamp createTime;
//    @TypeConverters(TimestampConverter.class)
    private Timestamp removeTime;
    //0未发布 1已发布 2已删除
    private Integer status;

    private String signs;


    @Ignore
    public Novel(){

    }



    public Novel(Integer id, String title, String content, Integer userId, Timestamp createTime, Timestamp removeTime, Integer status, String signs) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.userId = userId;
        this.createTime = createTime;
        this.removeTime = removeTime;
        this.status = status;
        this.signs = signs;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getRemoveTime() {
        return removeTime;
    }

    public void setRemoveTime(Timestamp removeTime) {
        this.removeTime = removeTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getSigns() {
        return signs;
    }

    public void setSigns(String signs) {
        this.signs = signs;
    }

    @Override
    public String toString() {
        return "Novel{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", userId=" + userId +
                ", createTime=" + createTime +
                ", removeTime=" + removeTime +
                ", status=" + status +
                ", signs='" + signs + '\'' +
                '}';
    }
}
